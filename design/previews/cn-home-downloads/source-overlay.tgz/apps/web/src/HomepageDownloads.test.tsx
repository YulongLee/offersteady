import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { HomepageDownloads } from "./HomepageDownloads";
import { syntheticState } from "./test-state";

function manifest() {
  const result = { ...syntheticState.releaseManifest, entries: syntheticState.releaseManifest.entries.filter(entry => entry.platform === "macos") };
  result.entries.push({ ...result.entries[0]!, id: "synthetic-win", platform: "windows", architecture: "x64", downloadUrl: "/downloads/synthetic-windows.exe" });
  return result;
}
describe("domestic homepage download controls", () => {
  it("links directly to domestic manifest installers with a compact Mac chooser", () => {
    const releases = manifest(); render(<HomepageDownloads manifest={releases} />);
    expect(screen.getByRole("link", { name: "Windows" })).toHaveAttribute("href", "/downloads/synthetic-windows.exe");
    expect(screen.getByRole("link", { name: "Windows" })).toHaveAttribute("download");
    const summary = screen.getByText("macOS");
    expect(summary.parentElement).not.toHaveAttribute("open");
    fireEvent.click(summary);
    expect(summary.parentElement).toHaveAttribute("open");
    expect(screen.getByRole("link", { name: "Apple Silicon" })).toHaveAttribute("href", releases.entries[0]!.downloadUrl);
    expect(screen.getByRole("link", { name: "Intel" })).toHaveAttribute("href", releases.entries[1]!.downloadUrl);
    fireEvent.keyDown(summary, { key: "Escape" });
    expect(summary.parentElement).not.toHaveAttribute("open"); expect(summary).toHaveFocus();
  });
  it.each(["empty", "withdrawn", "unsigned", "missing-url", "invalid-hash"])("does not expose unavailable installers: %s", state => {
    const releases = manifest();
    if (state === "empty") releases.entries = [];
    else releases.entries = releases.entries.map(entry => ({ ...entry, ...(state === "withdrawn" ? { distributionStatus: "withdrawn" as const } : state === "unsigned" ? { signingStatus: "local-development" as const, distributionStatus: "internal" as const } : state === "missing-url" ? { downloadUrl: "" } : { sha256: "bad" }) }));
    render(<HomepageDownloads manifest={releases} />);
    expect(screen.getByRole("button", { name: "Windows 暂不可用" })).toBeDisabled();
    expect(screen.getByRole("button", { name: "macOS 暂不可用" })).toBeDisabled();
    expect(document.querySelectorAll("a")).toHaveLength(0);
  });
});
