## 1. Baseline and scope
- [x] 1.1 Review domestic baseline, partner/video requirements and pricing source; record isolated presentation scope.

## 2. Implementation
- [x] 2.1 Implement concise Chinese journey, real catalogue pricing and retained domestic links/media.
- [x] 2.2 Align static homepage and add regression tests for missing/unpublished catalogue and partner behavior.

## 3. Acceptance
- [x] 3.1 Run tests, typecheck/build/static checks and responsive visual acceptance. Existing SEO redirect/bundle-budget failures remain documented, not waived.
- [x] 3.2 Record screenshots, exact baseline worktree and deployment handoff; do not deploy.

## 4. Owner-authorized deployment follow-up (2026-09-07)
The owner subsequently authorized domestic deployment only when idle. The earlier local-only scope remains the development-phase record.
- [x] 4.1 Confirm matching production baseline and zero active use, preserve rollback, deploy only Web with a second idle gate.
- [x] 4.2 Verify production HTTP, responsive homepage and unchanged core containers; record release evidence.

## 5. Owner-requested download refinement (rollback cancelled)
- [x] 5.1 Replace hero resource text with compact domestic Windows/Mac download controls using existing release rules.
- [x] 5.2 Verify direct links, unavailable states, keyboard/mobile chooser and regression/build; retain current production until separately deployed.
