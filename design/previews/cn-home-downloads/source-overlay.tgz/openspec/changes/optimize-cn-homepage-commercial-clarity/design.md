## Context

Use the documented domestic release worktree, not the stale main workspace App. Audience is Chinese job seekers; primary action is existing free-use/login flow. Traffic and conversion baseline are unknown. International dark/mint hierarchy is a reference, not a source of domestic prices.

## Goals / Non-Goals

Goals: concise hero, four benefits, earlier real pricing, grouped videos, optional detailed scenarios, FAQ, retained partner discovery and filings. Non-goals: deployment, pricing/settlement/auth changes, testimonials or numerical success claims.

## Decisions

- Download follow-up: a small domestic HomepageDownloads component consumes the already-loaded releaseManifest and existing downloadableRelease guard. Windows links directly to its published installer; Mac uses a native details chooser for available architectures. No international URLs, new fetches or hardcoded versions. Preserve guide access elsewhere and existing AI note; remove only redundant hero resource links. Use scoped dark outlined buttons, visible focus, 48px targets and right-aligned mobile chooser.

- Edit only LandingPage and public navigation; use a scoped cn-commercial CSS file rather than alter shared workspace styles.
- Keep the existing partner config fetch/enable guard and dashboard/nav routes unchanged.
- Show published positive-price, positive-duration time passes sorted by duration, and knowledge allowances from the existing catalogue; show rates from billing.rates. Missing catalogue shows an honest unavailable message rather than a fabricated free pass. No new fetch.
- Retain native video controls and both existing source/poster paths; no added media or autoplay.
- Retain platform list and six role cards as optional details rather than delete product information. Remove unsupported 10W+/98%/1W+/100+ metric strip.
- Static HTML retains crawlable benefits, setup, FAQ, support and filings; dynamic pricing is explicitly deferred to the live catalogue instead of baking test prices into HTML.

## Risks / Trade-offs

- Baseline mismatch → snapshot files before editing; hand off exact worktree and scoped diff for future deployment.
- Responsive overflow → check 1440, 900, 390, 320 px and expanded details.
- Removed numerical marketing claims → use product benefits, not fabricated replacements.
- Performance gain unknown → no percentages claimed; no new dependencies, requests or loading-heavy media.

## Migration Plan

Local implementation and tests only. A later explicitly authorized domestic deployment must compare the current production baseline, wait for idle state and preserve rollback.
