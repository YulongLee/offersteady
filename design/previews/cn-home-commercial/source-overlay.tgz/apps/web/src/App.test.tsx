import { fireEvent, render, screen, waitFor, within } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";

import { App, interviewContinuationRoute } from "./App";
import { interviewAppAdapter } from "./app-adapter";
import { authClient } from "./auth-client";
import { syntheticState } from "./test-state";

const clonedState = () => structuredClone(syntheticState);

const openAt = (path: string, authenticated = false) => {
  window.history.pushState({}, "", path);
  return render(<App initialAuthenticated={authenticated} initialState={clonedState()} />);
};

const openAtWithState = (path: string, state = clonedState(), authenticated = false) => {
  window.history.pushState({}, "", path);
  return render(<App initialAuthenticated={authenticated} initialState={state} />);
};

const login = async (destination = "/login") => {
  openAt(destination === "/login" ? "/app" : destination, true);
  await screen.findByRole("heading", { name: "继续这场面试" });
};

describe("OfferSteady web application", () => {
  beforeEach(() => {
    window.history.pushState({}, "", "/");
    vi.restoreAllMocks();
    vi.spyOn(interviewAppAdapter, "startInterviewSession").mockImplementation(async id => ({
      ...(syntheticState.interviews.find(item => item.id === id) ?? syntheticState.interviews[0]!),
      id,
      status: "active",
      updatedAt: "刚刚",
    }));
    vi.spyOn(interviewAppAdapter, "updateInterviewLanguage").mockImplementation(async (id, interviewLanguage) => ({
      ...(syntheticState.interviews.find(item => item.id === id) ?? syntheticState.interviews[0]!),
      id,
      interviewLanguage,
    }));
    vi.spyOn(interviewAppAdapter, "updateInterviewProgramming").mockImplementation(async (id, programmingRequired, programmingLanguage) => ({
      ...(syntheticState.interviews.find(item => item.id === id) ?? syntheticState.interviews[0]!),
      id,
      programmingRequired,
      programmingLanguage: programmingRequired ? programmingLanguage ?? "python" : null,
    }));
    vi.spyOn(interviewAppAdapter, "getActiveInterviewConflict").mockImplementation(async id => ({ currentInterviewId: id, activeInterview: null }));
    vi.spyOn(interviewAppAdapter, "supersedeActiveInterview").mockResolvedValue([]);
    vi.spyOn(interviewAppAdapter, "endInterviewSession").mockResolvedValue(undefined);
    vi.spyOn(interviewAppAdapter, "controlInterviewCapture").mockImplementation(async (_id, action) => action === "pause" ? "paused" : "capturing");
    vi.spyOn(interviewAppAdapter, "getDesktopDeviceBinding").mockResolvedValue(null);
    vi.spyOn(interviewAppAdapter, "getPreparationAudioReadiness").mockImplementation(async () => {
      const nowMs = Date.now();
      return { state: "ready", updatedAtMs: nowMs, sources: [
        { sourceKind: "microphone", state: "ready", lastSignalAtMs: nowMs, message: "麦克风声音检查通过" },
        { sourceKind: "system", state: "ready", lastSignalAtMs: nowMs, message: "电脑输出声音检查通过" },
      ] };
    });
    vi.spyOn(interviewAppAdapter, "getLastDesktopDevice").mockResolvedValue({
      deviceId: "fixture-last-device",
      displayName: "上次使用的 Mac",
      maskedManualCode: "••••56",
      capabilities: { microphone: true, systemAudio: true },
      online: true,
      lastSeenAtMs: Date.now(),
    });
    vi.spyOn(interviewAppAdapter, "bindDesktopDevice").mockImplementation(async command => ({
      bindingId: `fixture-binding-${command.manualCode}`,
      sessionId: command.interviewId,
      deviceId: `fixture-device-${command.manualCode}`,
      manualCode: command.manualCode ?? "••••56",
      displayName: "面试稳伴随程序 · Mac",
      capabilities: { microphone: true, systemAudio: true, screenCapture: true },
      status: "bound",
      boundAtMs: Date.now(),
      lastSeenAtMs: Date.now(),
    }));
    vi.spyOn(interviewAppAdapter, "submitManualAnswer").mockImplementation(async command => {
      const taskId = `answer-${command.idempotencyKey.replace(/[^a-zA-Z0-9-]/g, "-")}`;
      return {
        question: {
          id: taskId,
          askedAt: "刚刚",
          text: command.question,
          input: "manual",
          status: "confirmed",
          advice: {
            outline: [],
            detail: `这是来自后端模型链路的测试回答：${command.question}`,
            sourceTypes: ["简历", "JD", "知识库"],
            inference: "",
            uncertain: false,
            provenance: { selectionRevision: 0, usedSources: [] },
          },
        },
        task: {
          id: taskId,
          interviewId: command.interviewId,
          userId: "prototype-user",
          billingUsageId: `live-answer:${taskId}`,
          questionId: taskId,
          revision: 1,
          status: "completed",
          question: command.question,
          completedText: `这是来自后端模型链路的测试回答：${command.question}`,
          updatedAtMs: Date.now(),
        },
      };
    });
    vi.spyOn(interviewAppAdapter, "submitScreenshotAnswer").mockImplementation(async command => {
      const taskId = `screenshot-${command.interviewId}`;
      return {
        question: {
          id: taskId,
          askedAt: "刚刚",
          text: command.instruction,
          input: "screenshot",
          status: "confirmed",
          advice: {
            outline: ["识别题目", "整理思路", "生成回答"],
            detail: "请设计一个支持实时协作的 Web 系统。",
            sourceTypes: ["简历", "JD", "知识库"],
            inference: "测试环境中的远程截屏回答结果。",
            uncertain: false,
            provenance: { selectionRevision: 0, usedSources: [] },
          },
        },
        task: {
          id: taskId,
          interviewId: command.interviewId,
          userId: "prototype-user",
          billingUsageId: `screenshot-answer:${taskId}`,
          questionId: taskId,
          revision: 1,
          status: "completed",
          question: command.instruction,
          completedText: "请设计一个支持实时协作的 Web 系统。",
          updatedAtMs: Date.now(),
        },
      };
    });
  });

  it("routes each interview state through one continuation resolver", () => {
    expect(interviewContinuationRoute({ id: "a", status: "preparing" })).toBe("/app/interviews/a/prepare");
    expect(interviewContinuationRoute({ id: "a", status: "ready" })).toBe("/app/interviews/a/prepare");
    expect(interviewContinuationRoute({ id: "a", status: "active" })).toBe("/app/interviews/a/live");
    expect(interviewContinuationRoute({ id: "a", status: "paused" })).toBe("/app/interviews/a/live");
    expect(interviewContinuationRoute({ id: "a", status: "error" })).toBe("/app/interviews/a/live");
    expect(interviewContinuationRoute({ id: "a", status: "ended" })).toBe("/app/interviews/a/review");
  });

  it("leads with product value and keeps boundaries secondary", () => {
    openAt("/");
    expect(screen.getByRole("heading", { name: /让你的经历更好表达/ })).toBeInTheDocument();
    expect(screen.getByText(/结合你的简历与目标岗位/)).toBeInTheDocument();
    expect(screen.getByRole("heading", { name: "从听清问题，到讲清自己" })).toBeInTheDocument();
    expect(screen.getByRole("heading", { name: "跟上每一个问题" })).toBeInTheDocument();
    expect(screen.getByText(/AI 建议仅供参考/)).toBeInTheDocument();
    expect(screen.queryByText("CLEAR BOUNDARIES")).not.toBeInTheDocument();
  });

  it("protects interview content behind the prototype identity", async () => {
    openAt("/app/interviews/demo/live");
    expect(await screen.findByRole("heading", { name: "开始你的面试准备" })).toBeInTheDocument();
    expect(screen.queryByText("请介绍一个你负责过的、最有挑战的前端项目。")).not.toBeInTheDocument();
  });

  it("shows a user-correctable message when the SMS verification code is wrong", async () => {
    vi.spyOn(authClient, "sendSmsCode").mockResolvedValue({
      challengeId: "sms-challenge-ui-error",
      status: "sent",
      provider: "aliyun-dypnsapi",
      expiresAtMs: Date.now() + 300_000,
      cooldownSeconds: 0,
      maskedPhone: "157****8798",
    });
    vi.spyOn(authClient, "verifySmsLogin").mockRejectedValue(
      new Error("验证码不正确或已过期，请检查后重新输入。"),
    );
    openAt("/login");

    fireEvent.change(screen.getByPlaceholderText("请输入手机号"), {
      target: { value: "15773668798" },
    });
    fireEvent.click(screen.getByRole("button", { name: "获取验证码" }));
    const codeInput = await screen.findByPlaceholderText("请输入验证码");
    fireEvent.change(codeInput, { target: { value: "610368" } });
    fireEvent.click(screen.getByRole("button", { name: "登录 / 注册" }));

    expect(
      await screen.findByText("验证码不正确或已过期，请检查后重新输入。"),
    ).toBeInTheDocument();
    expect(screen.queryByText(/短信校验服务暂时不可用/)).not.toBeInTheDocument();
    expect(codeInput).toHaveValue("610368");
  });

  it("enters the app and shows an action-oriented home", async () => {
    await login();
    expect(screen.getByRole("link", { name: /新建面试/ })).toBeInTheDocument();
    expect(screen.getAllByText("高级前端工程师面试").length).toBeGreaterThan(0);
    expect(screen.getByRole("heading", { name: "继续这场面试" })).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "继续面试" })).toBeInTheDocument();
    expect(screen.queryByRole("link", { name: /预览工作台|继续准备/ })).not.toBeInTheDocument();
    expect(screen.getByRole("navigation", { name: "应用导航" })).toBeInTheDocument();
    expect(screen.getByRole("navigation", { name: "移动端应用导航" })).toBeInTheDocument();
  });

  it("exposes separate interview and written exam navigation and session lists", () => {
    const state = clonedState();
    state.interviews = [
      { id: "interview-only", title: "面试独立场次", role: "前端工程师", sessionMode: "interview", status: "preparing", updatedAt: "刚刚", readiness: 50 },
      { id: "written-only", title: "笔试独立场次", role: "算法工程师", sessionMode: "written", status: "preparing", updatedAt: "刚刚", readiness: 100 },
    ];
    const view = openAtWithState("/app", state, true);

    const desktopNavigation = screen.getByRole("navigation", { name: "应用导航" });
    expect(within(desktopNavigation).getByRole("link", { name: "面试模式" })).toHaveAttribute("href", "/app");
    expect(within(desktopNavigation).getByRole("link", { name: "笔试模式" })).toHaveAttribute("href", "/app/written-exams");
    expect(screen.getAllByText("面试独立场次").length).toBeGreaterThan(0);
    expect(screen.queryByText("笔试独立场次")).not.toBeInTheDocument();

    view.unmount();
    openAtWithState("/app/written-exams", state, true);
    expect(screen.getAllByText("笔试独立场次").length).toBeGreaterThan(0);
    expect(screen.queryByText("面试独立场次")).not.toBeInTheDocument();
    expect(screen.getByRole("link", { name: /新建笔试/ })).toHaveAttribute("href", "/app/written-exams/new");
  });

  it("links both workbench navigation surfaces to the maintained user manual", async () => {
    await login();
    const expectedUrl = "https://pwksrh0z1i6.feishu.cn/drive/folder/KFlcfWorslX2hmdyyByc2fLvngp?from=from_copylink";
    const navigations = [
      screen.getByRole("navigation", { name: "应用导航" }),
      screen.getByRole("navigation", { name: "移动端应用导航" }),
    ];

    for (const navigation of navigations) {
      const manual = within(navigation).getByRole("link", { name: "用户手册" });
      expect(manual).toHaveAttribute("href", expectedUrl);
      expect(manual).toHaveAttribute("target", "_blank");
      expect(manual).toHaveAttribute("rel", expect.stringContaining("noopener"));
      expect(manual).toHaveAttribute("rel", expect.stringContaining("noreferrer"));
      expect(within(navigation).getByRole("link", { name: /使用说明/ })).toHaveAttribute("href", "/app/guide");
    }
  });

  it("bootstraps prototype account storage for authenticated initial app sessions", async () => {
    const store = new Map<string, string>();
    Object.defineProperty(window, "localStorage", {
      configurable: true,
      value: {
        getItem: (key: string) => store.get(key) ?? null,
        setItem: (key: string, value: string) => void store.set(key, value),
        removeItem: (key: string) => void store.delete(key),
      },
    });
    authClient.clear();
    window.history.pushState({}, "", "/app");
    render(<App initialAuthenticated initialState={clonedState()} />);
    await screen.findByRole("heading", { name: "继续这场面试" });
    expect(authClient.readStoredAccount()).toMatchObject({
      id: syntheticState.account.id,
      displayName: syntheticState.account.displayName,
    });
  });

  it("validates and creates an interview draft", async () => {
    vi.spyOn(interviewAppAdapter, "createDraft").mockResolvedValue({
      id: "draft",
      title: "前端架构师终面",
      role: "前端架构师",
      status: "preparing",
      updatedAt: "刚刚",
      readiness: 0,
    });
    const firstUseState = clonedState();
    firstUseState.interviews = [];
    openAtWithState("/app/interviews/new", firstUseState, true);
    expect(screen.getByLabelText("面试名称")).toHaveValue("");
    expect(screen.getByLabelText("目标岗位")).toHaveValue("");
    expect(screen.getByLabelText("公司（可选）")).toHaveValue("");
    fireEvent.click(screen.getByRole("button", { name: /保存并准备/ }));
    expect(screen.getByRole("alert")).toHaveTextContent("请填写面试名称和目标岗位");
    fireEvent.change(screen.getByLabelText("面试名称"), { target: { value: "前端架构师终面" } });
    fireEvent.change(screen.getByLabelText("目标岗位"), { target: { value: "前端架构师" } });
    fireEvent.click(screen.getByRole("button", { name: /保存并准备/ }));
    expect(await screen.findByRole("heading", { name: "前端架构师终面" })).toBeInTheDocument();
    expect(screen.getByText("输入机器码连接本场")).toBeInTheDocument();
    fireEvent.click(await screen.findByRole("button", { name: "一键连接上次设备" }, { timeout: 3_000 }));
    await waitFor(() => expect(interviewAppAdapter.bindDesktopDevice).toHaveBeenCalledWith({
      interviewId: "draft",
      reuseLastDevice: true,
    }, expect.any(AbortSignal)));
    expect(screen.getByText("本场已连接：面试稳伴随程序 · Mac")).toBeInTheDocument();
  });

  it("prefills a new interview from the current account latest interview and keeps it editable", async () => {
    const createDraft = vi.spyOn(interviewAppAdapter, "createDraft").mockImplementation(async input => ({
      id: "prefilled-draft",
      title: input.title,
      role: input.role,
      ...(input.company ? { company: input.company } : {}),
      status: "preparing",
      updatedAt: "刚刚",
      readiness: 0,
    }));
    const state = clonedState();
    state.interviews = [
      { id: "latest", title: "算法工程师二面", role: "算法工程师", company: "示例智能", status: "ended", updatedAt: "刚刚", readiness: 100 },
      { id: "older", title: "前端工程师一面", role: "前端工程师", company: "示例科技", status: "ended", updatedAt: "昨天", readiness: 100 },
    ];
    openAtWithState("/app/interviews/new", state, true);

    expect(screen.getByLabelText("面试名称")).toHaveValue("算法工程师二面");
    expect(screen.getByLabelText("目标岗位")).toHaveValue("算法工程师");
    expect(screen.getByLabelText("公司（可选）")).toHaveValue("示例智能");
    fireEvent.change(screen.getByLabelText("面试名称"), { target: { value: "算法工程师终面" } });
    fireEvent.change(screen.getByLabelText("公司（可选）"), { target: { value: "新公司" } });
    fireEvent.click(screen.getByRole("button", { name: /保存并准备/ }));

    await waitFor(() => expect(createDraft).toHaveBeenCalledWith({
      title: "算法工程师终面",
      role: "算法工程师",
      company: "新公司",
    }, expect.any(AbortSignal)));
    expect(screen.queryByRole("radio", { name: /笔试模式/ })).not.toBeInTheDocument();
  });

  it("creates a written exam draft from the dedicated route", async () => {
    const createDraft = vi.spyOn(interviewAppAdapter, "createDraft").mockResolvedValue({
      id: "written-draft",
      title: "算法笔试",
      role: "算法工程师",
      sessionMode: "written",
      status: "preparing",
      updatedAt: "刚刚",
      readiness: 100,
    });
    const state = clonedState();
    state.interviews = [];
    openAtWithState("/app/written-exams/new", state, true);

    fireEvent.change(screen.getByLabelText("笔试名称"), { target: { value: "算法笔试" } });
    fireEvent.change(screen.getByLabelText("目标岗位"), { target: { value: "算法工程师" } });
    fireEvent.click(screen.getByRole("button", { name: /保存并准备/ }));

    await waitFor(() => expect(createDraft).toHaveBeenCalledWith(expect.objectContaining({
      title: "算法笔试",
      role: "算法工程师",
      sessionMode: "written",
    }), expect.any(AbortSignal)));
    expect(screen.queryByRole("radio", { name: /面试模式/ })).not.toBeInTheDocument();
  });

  it("keeps written exam preparation focused on companion connection and entry", async () => {
    const state = clonedState();
    state.interviews = [{
      id: "written-prepare",
      title: "算法笔试",
      role: "算法工程师",
      sessionMode: "written",
      status: "preparing",
      updatedAt: "刚刚",
      readiness: 100,
    }];

    openAtWithState("/app/interviews/written-prepare/prepare", state, true);

    expect(await screen.findByRole("heading", { name: "连接伴随助手" })).toBeInTheDocument();
    expect(screen.getByText("开始时扣除 30 积分")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /开始笔试/ })).toBeDisabled();
    expect(screen.queryByText("本场数据说明")).not.toBeInTheDocument();
    expect(screen.queryByText(/每次截屏回答/)).not.toBeInTheDocument();
    expect(screen.queryByText(/笔试模式不收音/)).not.toBeInTheDocument();
    expect(screen.queryByText("0/1")).not.toBeInTheDocument();
  });

  it("shows and dismisses a non-blocking update reminder for an already connected interview companion", async () => {
    const state = clonedState();
    state.releaseManifest = {
      ...state.releaseManifest,
      entries: state.releaseManifest.entries.map(entry => entry.id === "mac-arm64-010"
        ? { ...entry, id: "mac-arm64-1213", version: "1.2.13", downloadUrl: "/api/v1/web/downloads/desktop/mac-arm64-1213" }
        : entry),
    };
    vi.mocked(interviewAppAdapter.getDesktopDeviceBinding).mockResolvedValueOnce({
      bindingId: "existing-old-binding",
      sessionId: "demo",
      deviceId: "existing-old-device",
      manualCode: "123456",
      displayName: "面试稳伴随程序 · Mac",
      capabilities: { appVersion: "1.2.10a", platform: "macos", architecture: "arm64" },
      status: "bound",
      boundAtMs: Date.now(),
      lastSeenAtMs: Date.now(),
    });

    openAtWithState("/app/interviews/demo/prepare", state, true);

    const reminder = await screen.findByRole("region", { name: "伴随程序更新提醒" });
    expect(within(reminder).getByText("发现新版伴随程序 1.2.13")).toBeInTheDocument();
    expect(within(reminder).getByText(/当前版本 1.2.10a/)).toBeInTheDocument();
    expect(within(reminder).getByRole("link", { name: "立即下载" })).toHaveAttribute("href", "/api/v1/web/downloads/desktop/mac-arm64-1213");
    expect(await screen.findByRole("button", { name: /开始面试/ })).toBeEnabled();
    expect(interviewAppAdapter.bindDesktopDevice).not.toHaveBeenCalled();

    fireEvent.click(within(reminder).getByRole("button", { name: "继续使用" }));
    expect(screen.queryByRole("region", { name: "伴随程序更新提醒" })).not.toBeInTheDocument();
    expect(screen.getByRole("button", { name: /开始面试/ })).toBeEnabled();
    expect(interviewAppAdapter.bindDesktopDevice).not.toHaveBeenCalled();
  });

  it("offers the matching update after written-exam binding without adding a version request", async () => {
    const state = clonedState();
    state.interviews = [{
      id: "written-update",
      title: "算法笔试",
      role: "算法工程师",
      sessionMode: "written",
      status: "preparing",
      updatedAt: "刚刚",
      readiness: 100,
    }];
    state.releaseManifest = {
      ...state.releaseManifest,
      entries: state.releaseManifest.entries.map(entry => entry.id === "mac-arm64-010"
        ? { ...entry, version: "1.2.13" }
        : entry),
    };
    vi.mocked(interviewAppAdapter.bindDesktopDevice).mockResolvedValueOnce({
      bindingId: "written-old-binding",
      sessionId: "written-update",
      deviceId: "written-old-device",
      manualCode: "123456",
      displayName: "面试稳伴随程序 · Mac",
      capabilities: { appVersion: "1.2.9", platform: "darwin", architecture: "aarch64" },
      status: "bound",
      boundAtMs: Date.now(),
      lastSeenAtMs: Date.now(),
    });

    openAtWithState("/app/interviews/written-update/prepare", state, true);
    fireEvent.click(await screen.findByRole("button", { name: "连接上次设备" }));

    expect(await screen.findByRole("region", { name: "伴随程序更新提醒" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /开始笔试/ })).toBeEnabled();
    expect(interviewAppAdapter.bindDesktopDevice).toHaveBeenCalledTimes(1);
  });

  it("keeps preparation unchanged when connected device version metadata is unavailable", async () => {
    vi.mocked(interviewAppAdapter.getDesktopDeviceBinding).mockResolvedValueOnce({
      bindingId: "legacy-binding",
      sessionId: "demo",
      deviceId: "legacy-device",
      manualCode: "123456",
      displayName: "旧版伴随程序",
      capabilities: { microphone: true, systemAudio: true },
      status: "bound",
      boundAtMs: Date.now(),
      lastSeenAtMs: Date.now(),
    });

    openAtWithState("/app/interviews/demo/prepare", clonedState(), true);

    expect(await screen.findByRole("button", { name: /开始面试/ })).toBeEnabled();
    expect(screen.queryByRole("region", { name: "伴随程序更新提醒" })).not.toBeInTheDocument();
    expect(interviewAppAdapter.bindDesktopDevice).not.toHaveBeenCalled();
  });

  it("keeps an ended written exam visible and opens a written result page", async () => {
    const state = clonedState();
    const screenshotQuestion = {
      ...state.questions[0]!,
      id: "written-question",
      input: "screenshot" as const,
      text: "实现一个线程安全的 LRU 缓存",
      advice: { ...state.questions[0]!.advice, detail: "可以使用哈希表配合双向链表实现。" },
    };
    state.interviews = [{
      id: "written-ended",
      title: "算法笔试",
      role: "算法工程师",
      sessionMode: "written",
      status: "ended",
      updatedAt: "刚刚",
      readiness: 100,
    }];
    state.questions = [screenshotQuestion];
    vi.spyOn(interviewAppAdapter, "loadInterviewWorkspace").mockResolvedValueOnce({
      questions: [screenshotQuestion],
      activeAnswerTask: null,
    });

    const view = openAtWithState("/app/written-exams", state, true);
    expect(screen.getByText("算法笔试")).toBeInTheDocument();
    expect(screen.getByText(/已结束/)).toBeInTheDocument();
    fireEvent.click(screen.getByRole("link", { name: /算法笔试/ }));

    expect(await screen.findByRole("heading", { name: "本场答题记录" })).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "← 返回笔试模式" })).toHaveAttribute("href", "/app/written-exams");
    expect(screen.getByText("实现一个线程安全的 LRU 缓存")).toBeInTheDocument();
    expect(screen.getByText("可以使用哈希表配合双向链表实现。")).toBeInTheDocument();
    expect(screen.queryByText("真实对话记录")).not.toBeInTheDocument();
    expect(screen.queryByText("AI 整理摘要")).not.toBeInTheDocument();
    view.unmount();
  });

  it("does not leave the written workspace when ending fails", async () => {
    const state = clonedState();
    state.interviews = [{
      id: "written-live",
      title: "在线笔试",
      role: "后端工程师",
      sessionMode: "written",
      status: "active",
      updatedAt: "刚刚",
      readiness: 100,
    }];
    vi.spyOn(window, "confirm").mockReturnValue(true);
    vi.mocked(interviewAppAdapter.endInterviewSession).mockRejectedValueOnce(new Error("结束笔试失败，请重试。"));

    openAtWithState("/app/interviews/written-live/live", state, true);
    fireEvent.click(await screen.findByRole("button", { name: "结束笔试" }));

    expect(await screen.findByText("结束笔试失败，请重试。")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "结束笔试" })).toBeInTheDocument();
    expect(screen.queryByRole("heading", { name: "本场答题记录" })).not.toBeInTheDocument();
  });

  it("shows the backend reason when creating an interview draft fails", async () => {
    vi.spyOn(interviewAppAdapter, "createDraft").mockRejectedValueOnce(new Error("面试创建失败，请稍后重试"));
    await login();
    fireEvent.click(screen.getByRole("link", { name: /新建面试/ }));
    fireEvent.change(screen.getByLabelText("面试名称"), { target: { value: "失败草稿" } });
    fireEvent.change(screen.getByLabelText("目标岗位"), { target: { value: "高级前端工程师" } });
    fireEvent.click(screen.getByRole("button", { name: /保存并准备/ }));
    expect(await screen.findByRole("alert")).toHaveTextContent("面试创建失败，请稍后重试");
    expect(screen.getByRole("heading", { name: "创建一场面试" })).toBeInTheDocument();
  });

  it("shows at most five recent interviews and allows deleting one safely", async () => {
    const state = clonedState();
    state.interviews = [
      { id: "i-1", title: "面试 1", role: "前端", status: "active", updatedAt: "刚刚", readiness: 100 },
      { id: "i-2", title: "面试 2", role: "前端", status: "preparing", updatedAt: "刚刚", readiness: 80 },
      { id: "i-3", title: "面试 3", role: "前端", status: "ended", updatedAt: "刚刚", readiness: 100 },
      { id: "i-4", title: "面试 4", role: "前端", status: "ended", updatedAt: "刚刚", readiness: 100 },
      { id: "i-5", title: "面试 5", role: "前端", status: "ended", updatedAt: "刚刚", readiness: 100 },
      { id: "i-6", title: "面试 6", role: "前端", status: "ended", updatedAt: "刚刚", readiness: 100 },
    ];
    vi.spyOn(window, "confirm").mockReturnValue(true);
    vi.spyOn(interviewAppAdapter, "deleteInterview").mockResolvedValue(undefined);
    vi.spyOn(interviewAppAdapter, "loadState").mockResolvedValue({
      ...state,
      interviews: state.interviews.filter(item => item.id !== "i-1").slice(0, 5),
    });
    openAtWithState("/app", state, true);
    await screen.findByRole("heading", { name: "继续这场面试" });
    expect(screen.getByText("5 / 5 场")).toBeInTheDocument();
    expect(screen.queryByText("面试 6")).not.toBeInTheDocument();
    fireEvent.click(screen.getAllByRole("button", { name: "删除" })[0]!);
    await waitFor(() => expect(interviewAppAdapter.deleteInterview).toHaveBeenCalledWith("i-1", expect.any(AbortSignal)));
    await waitFor(() => expect(screen.queryByText("面试 1")).not.toBeInTheDocument());
  });

  it("enters the live workspace after materials are confirmed without a generic privacy checkbox", async () => {
    await login();
    window.history.pushState({}, "", "/app/interviews/demo/prepare");
    window.dispatchEvent(new PopStateEvent("popstate"));
    fireEvent.click(await screen.findByRole("button", { name: "一键连接上次设备" }));
    const start = await screen.findByRole("button", { name: /开始面试/ });
    await waitFor(() => expect(start).toBeEnabled());
    expect(screen.queryByRole("checkbox", { name: /数据用途/ })).not.toBeInTheDocument();
    expect(screen.getByText(/后台正在预热实时链路/)).toBeInTheDocument();
    expect(screen.getByText(/麦克风和屏幕权限只由桌面助手首次申请/)).toBeInTheDocument();
    fireEvent.click(start);
    await waitFor(() => expect(interviewAppAdapter.startInterviewSession).toHaveBeenCalledWith("demo", expect.any(AbortSignal)));
    expect((await screen.findAllByText("请介绍一个你负责过的、最有挑战的前端项目。")).length).toBeGreaterThan(0);
    expect(screen.getByText("等待开始面试")).toBeInTheDocument();
    expect(screen.getByText("这台设备 · 已连接，未采集")).toBeInTheDocument();
  });

  it("defaults preparation to Chinese and persists an English interview selection without changing readiness", async () => {
    await login();
    window.history.pushState({}, "", "/app/interviews/demo/prepare");
    window.dispatchEvent(new PopStateEvent("popstate"));

    const chinese = await screen.findByRole("radio", { name: /中文面试/ });
    const english = screen.getByRole("radio", { name: /English Interview/ });
    expect(chinese).toBeChecked();
    expect(english).not.toBeChecked();
    expect(screen.getByText("1/2")).toBeInTheDocument();

    fireEvent.click(english);
    await waitFor(() => expect(interviewAppAdapter.updateInterviewLanguage).toHaveBeenCalledWith(
      "demo", "en-US", expect.any(AbortSignal),
    ));
    await waitFor(() => expect(english).toBeChecked());
    expect(screen.getByText("1/2")).toBeInTheDocument();
  });

  it("restores the server language and keeps it selected when saving a change fails", async () => {
    const state = clonedState();
    state.interviews = state.interviews.map(item => item.id === "demo" ? { ...item, interviewLanguage: "en-US" } : item);
    vi.mocked(interviewAppAdapter.updateInterviewLanguage).mockRejectedValueOnce(new Error("面试语言保存失败，请重试。"));
    openAtWithState("/app/interviews/demo/prepare", state, true);

    const english = await screen.findByRole("radio", { name: /English Interview/ });
    const chinese = screen.getByRole("radio", { name: /中文面试/ });
    expect(english).toBeChecked();
    fireEvent.click(chinese);

    expect(await screen.findByRole("alert")).toHaveTextContent("面试语言保存失败，请重试。");
    expect(english).toBeChecked();
    expect(chinese).not.toBeChecked();
  });

  it("enables programming with Python by default and persists the selected language without changing readiness", async () => {
    await login();
    window.history.pushState({}, "", "/app/interviews/demo/prepare");
    window.dispatchEvent(new PopStateEvent("popstate"));

    const programming = await screen.findByRole("switch", { name: "" });
    expect(programming).not.toBeChecked();
    expect(screen.queryByRole("radiogroup", { name: "编程语言" })).not.toBeInTheDocument();
    fireEvent.click(programming);

    await waitFor(() => expect(interviewAppAdapter.updateInterviewProgramming).toHaveBeenCalledWith(
      "demo", true, "python", expect.any(AbortSignal),
    ));
    const python = await screen.findByRole("radio", { name: "Python" });
    expect(python).toBeChecked();
    fireEvent.click(screen.getByRole("radio", { name: "C++" }));
    await waitFor(() => expect(interviewAppAdapter.updateInterviewProgramming).toHaveBeenLastCalledWith(
      "demo", true, "cpp", expect.any(AbortSignal),
    ));
    expect(screen.getByText("1/2")).toBeInTheDocument();
    fireEvent.click(programming);
    await waitFor(() => expect(interviewAppAdapter.updateInterviewProgramming).toHaveBeenLastCalledWith(
      "demo", false, null, expect.any(AbortSignal),
    ));
    expect(screen.queryByRole("radiogroup", { name: "编程语言" })).not.toBeInTheDocument();
  });

  it("restores the saved programming language and keeps it when a save fails", async () => {
    const state = clonedState();
    state.interviews = state.interviews.map(item => item.id === "demo" ? {
      ...item, programmingRequired: true, programmingLanguage: "go",
    } : item);
    vi.mocked(interviewAppAdapter.updateInterviewProgramming).mockRejectedValueOnce(new Error("编程设置保存失败，请重试。"));
    openAtWithState("/app/interviews/demo/prepare", state, true);

    const go = await screen.findByRole("radio", { name: "Go" });
    expect(go).toBeChecked();
    fireEvent.click(screen.getByRole("radio", { name: "Java" }));
    expect(await screen.findByRole("alert")).toHaveTextContent("编程设置保存失败，请重试。");
    expect(go).toBeChecked();
  });

  it("keeps the user on preparation when backend session start fails", async () => {
    vi.spyOn(interviewAppAdapter, "startInterviewSession").mockRejectedValueOnce(new Error("后端会话启动失败，请重试"));
    await login();
    window.history.pushState({}, "", "/app/interviews/demo/prepare");
    window.dispatchEvent(new PopStateEvent("popstate"));
    fireEvent.click(await screen.findByRole("button", { name: "一键连接上次设备" }));
    const start = await screen.findByRole("button", { name: /开始面试/ });
    await waitFor(() => expect(start).toBeEnabled());
    fireEvent.click(start);
    expect(await screen.findByRole("alert")).toHaveTextContent("后端会话启动失败，请重试");
    expect(screen.getByRole("heading", { name: "高级前端工程师面试" })).toBeInTheDocument();
    expect(screen.queryByRole("heading", { name: "实时对话" })).not.toBeInTheDocument();
  });

  it("requires explicit takeover before binding a new interview to the desktop device", async () => {
    vi.mocked(interviewAppAdapter.getActiveInterviewConflict).mockResolvedValueOnce({
      currentInterviewId: "demo",
      activeInterview: { ...syntheticState.interviews[0]!, id: "previous-live", title: "上一场算法面试", status: "active" },
    });
    vi.mocked(interviewAppAdapter.supersedeActiveInterview).mockResolvedValueOnce(["previous-live"]);
    await login();
    window.history.pushState({}, "", "/app/interviews/demo/prepare");
    window.dispatchEvent(new PopStateEvent("popstate"));
    const dialog = await screen.findByRole("dialog", { name: "已有一场面试正在进行" });
    expect(within(dialog).getByText("上一场算法面试")).toBeInTheDocument();
    expect(interviewAppAdapter.bindDesktopDevice).not.toHaveBeenCalled();
    fireEvent.click(within(dialog).getByRole("button", { name: "结束上一场，准备当前面试" }));
    await waitFor(() => expect(interviewAppAdapter.supersedeActiveInterview).toHaveBeenCalledWith({
      interviewId: "demo",
      expectedPreviousInterviewId: "previous-live",
    }, expect.any(AbortSignal)));
    await waitFor(() => expect(screen.queryByRole("dialog", { name: "已有一场面试正在进行" })).not.toBeInTheDocument());
    expect(screen.getByRole("button", { name: "一键连接上次设备" })).toBeEnabled();
  });

  it("shows a manually submitted question as the latest answer", async () => {
    await login();
    window.history.pushState({}, "", "/app/interviews/demo/live");
    window.dispatchEvent(new PopStateEvent("popstate"));
    const input = await screen.findByPlaceholderText("输入面试官的问题");
    fireEvent.change(input, { target: { value: "如何设计前端监控系统？" } });
    fireEvent.click(screen.getByRole("button", { name: "快答" }));
    await waitFor(() => expect(screen.getByRole("heading", { name: "如何设计前端监控系统？" })).toBeInTheDocument());
  });

  it("shows the backend reason when manual answer is rejected by session state", async () => {
    vi.spyOn(interviewAppAdapter, "submitManualAnswer").mockRejectedValueOnce(new Error("只有进行中的面试会话才能发起实时回答。"));
    await login();
    window.history.pushState({}, "", "/app/interviews/demo/live");
    window.dispatchEvent(new PopStateEvent("popstate"));
    const input = await screen.findByPlaceholderText("输入面试官的问题");
    fireEvent.change(input, { target: { value: "为什么刚进入面试无法回答？" } });
    fireEvent.click(screen.getByRole("button", { name: "快答" }));
    expect((await screen.findAllByText("只有进行中的面试会话才能发起实时回答。")).length).toBeGreaterThan(0);
    expect(screen.queryByText("当前任务未启动，请检查积分或会员权益。")).not.toBeInTheDocument();
  });

  it("keeps the question visible when the backend reports a model runtime failure", async () => {
    vi.spyOn(interviewAppAdapter, "submitManualAnswer").mockRejectedValueOnce(new Error("当前对话模型鉴权失败，请检查服务配置。"));
    await login();
    window.history.pushState({}, "", "/app/interviews/demo/live");
    window.dispatchEvent(new PopStateEvent("popstate"));
    const input = await screen.findByPlaceholderText("输入面试官的问题");
    fireEvent.change(input, { target: { value: "模型不可用时如何保留问题？" } });
    fireEvent.click(screen.getByRole("button", { name: "快答" }));
    expect(await screen.findByRole("heading", { name: "模型不可用时如何保留问题？" })).toBeInTheDocument();
    expect((await screen.findAllByText("当前对话模型鉴权失败，请检查服务配置。")).length).toBeGreaterThan(0);
    expect(screen.getByRole("button", { name: "重试" })).toBeInTheDocument();
  });


  it("keeps screenshot input inside the live workspace", async () => {
    await login();
    window.history.pushState({}, "", "/app/interviews/demo/live");
    window.dispatchEvent(new PopStateEvent("popstate"));
    fireEvent.click(await screen.findByRole("button", { name: /截屏回答/ }));
    expect((await screen.findAllByText("请设计一个支持实时协作的 Web 系统。")).length).toBeGreaterThan(0);
    expect(screen.queryByText("上传并识别")).not.toBeInTheDocument();
  });

  it("pauses and ends a session explicitly", async () => {
    vi.spyOn(window, "confirm").mockReturnValue(true);
    const captureControl = vi.mocked(interviewAppAdapter.controlInterviewCapture);
    await login();
    window.history.pushState({}, "", "/app/interviews/demo/live");
    window.dispatchEvent(new PopStateEvent("popstate"));
    fireEvent.click(await screen.findByRole("button", { name: "开始面试" }));
    expect(screen.getByText("这台设备 · 正在收音")).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "暂停收音" }));
    expect(await screen.findByText("面试已暂停")).toBeInTheDocument();
    expect(captureControl).toHaveBeenCalledWith("demo", "pause", expect.any(AbortSignal));
    fireEvent.click(screen.getByRole("button", { name: "结束面试" }));
    expect(await screen.findByRole("heading", { name: "本场面试复盘" })).toBeInTheDocument();
  });

  it("separates generated review from original records and deletes screenshots after confirmation", async () => {
    vi.spyOn(interviewAppAdapter, "deleteScreenshot").mockResolvedValue(undefined);
    await login();
    window.history.pushState({}, "", "/app/interviews/review/review");
    window.dispatchEvent(new PopStateEvent("popstate"));
    expect(await screen.findByRole("heading", { name: "真实对话记录" })).toBeInTheDocument();
    expect(await screen.findByText("请介绍一下你如何推动跨团队协作。")).toBeInTheDocument();
    expect(await screen.findByText("我会先统一目标和交付边界，再建立固定同步机制。")).toBeInTheDocument();
    expect(screen.getByRole("heading", { name: "问题与 AI 回答建议" })).toBeInTheDocument();
    expect(screen.getByText("生成建议，不代表实际作答")).toBeInTheDocument();
    expect(screen.getByText("AI 整理摘要")).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "删除截图" }));
    await waitFor(() => expect(screen.queryByText("系统设计题（合成）.png")).not.toBeInTheDocument());
  });

  it("downloads the review locally and keeps the mobile transcript readable", async () => {
    Object.defineProperty(window, "innerWidth", { configurable: true, value: 390 });
    await login();
    window.history.pushState({}, "", "/app/interviews/review/review");
    window.dispatchEvent(new PopStateEvent("popstate"));

    const download = await screen.findByRole("button", { name: "下载 Word" });
    await waitFor(() => expect(download).toBeEnabled());
    expect(screen.getByText(/仅在你的浏览器本地生成/)).toBeInTheDocument();
    const click = vi.fn();
    const anchor = document.createElement("a");
    anchor.click = click;
    vi.spyOn(document, "createElement").mockReturnValue(anchor);
    vi.spyOn(URL, "createObjectURL").mockReturnValue("blob:review");
    vi.spyOn(URL, "revokeObjectURL").mockImplementation(() => undefined);
    fireEvent.click(download);

    await waitFor(() => expect(URL.createObjectURL).toHaveBeenCalledOnce());
    expect(click).toHaveBeenCalledOnce();
    expect(screen.getByText(/Word 已生成并开始下载/)).toBeInTheDocument();
  });

  it("offers explicit macOS architectures and a truthful Windows preview", async () => {
    vi.spyOn(window.navigator, "userAgent", "get").mockReturnValue("Mozilla/5.0 (Macintosh; Apple Silicon Mac OS X) arm64");
    vi.spyOn(window.navigator, "platform", "get").mockReturnValue("MacARM");
    await login();
    fireEvent.click(screen.getAllByRole("link", { name: /设备/ })[0]!);
    expect(await screen.findByRole("button", { name: /macOS Apple Silicon/ })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /macOS Intel/ })).toBeInTheDocument();
    expect(screen.getByText("这台 Mac")).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: /Windows 10\/11/ }));
    expect(screen.getByRole("button", { name: "暂未开放下载" })).toBeDisabled();
    expect(screen.getByText(/系统音频：不可用/)).toBeInTheDocument();
  });

  it("completes the desktop prototype journey from home through review", async () => {
    vi.spyOn(window, "confirm").mockReturnValue(true);
    window.history.pushState({}, "", "/app");
    render(<App initialAuthenticated initialState={clonedState()} />);
    fireEvent.click(await screen.findByRole("link", { name: "继续面试" }));
    fireEvent.click(await screen.findByRole("button", { name: "一键连接上次设备" }));
    const startInterview = screen.getByRole("button", { name: /开始面试/ });
    await waitFor(() => expect(startInterview).toBeEnabled());
    fireEvent.click(startInterview);
    fireEvent.click(await screen.findByRole("button", { name: "开始面试" }));
    const input = await screen.findByPlaceholderText("输入面试官的问题");
    fireEvent.change(input, { target: { value: "完整旅程测试问题" } });
    fireEvent.click(screen.getByRole("button", { name: "快答" }));
    fireEvent.click(screen.getByRole("button", { name: "结束面试" }));
    expect(await screen.findByRole("heading", { name: "本场面试复盘" })).toBeInTheDocument();
    expect(screen.getByText("完整旅程测试问题")).toBeInTheDocument();
  });

  it("uses an answer-first mobile workspace without a material drawer or desktop divider", async () => {
    Object.defineProperty(window, "innerWidth", { configurable: true, value: 390 });
    window.history.pushState({}, "", "/app/interviews/demo/live");
    render(<App initialAuthenticated initialState={clonedState()} />);
    expect(await screen.findByRole("heading", { name: "回答" })).toBeInTheDocument();
    expect(screen.queryByRole("heading", { name: "实时对话" })).not.toBeInTheDocument();
    fireEvent.click(screen.getByRole("tab", { name: /对话/ }));
    expect(screen.getByRole("heading", { name: "实时对话" })).toBeInTheDocument();
    expect(screen.queryByRole("separator")).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: /资料/ })).not.toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "开始面试" }));
    fireEvent.click(screen.getByRole("button", { name: "暂停收音" }));
    expect(await screen.findByText("收音已暂停")).toBeInTheDocument();
  });
});
