import { fireEvent, render, screen, within } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { readFileSync } from "node:fs";
import { App } from "./App";
import { syntheticState } from "./test-state";
import { interviewAppAdapter } from "./app-adapter";
import type { WebAppState } from "./domain";

function open(mutate?: (state: WebAppState) => void) {
  const state = structuredClone(syntheticState); mutate?.(state);
  return render(<App initialAuthenticated={false} initialState={state} />);
}
beforeEach(() => { window.history.replaceState({}, "", "/"); vi.spyOn(interviewAppAdapter, "getPartnerProgramConfig").mockRejectedValue(new Error("Synthetic disabled")); });

describe("domestic commercial homepage", () => {
  it("places live pricing before media and keeps existing entry points", () => {
    open();
    const ids = [...document.querySelectorAll("main > section[id]")].map(e => e.id);
    expect(ids.indexOf("pricing-value")).toBeLessThan(ids.indexOf("product-tour"));
    expect(screen.getByRole("heading", { level: 1 })).toHaveTextContent("让你的经历更好表达");
    expect(document.querySelectorAll(".cn-benefits article")).toHaveLength(4);
    expect(screen.getByRole("link", { name: "合作伙伴计划" })).toHaveAttribute("href", "/app/partner-program");
    expect(screen.getAllByRole("link", { name: /免费使用/ }).length).toBeGreaterThanOrEqual(3);
    expect(document.querySelector(".product-facts-grid")).toBeNull();
  });
  it("uses current prices, rates and allowances without mutating the catalogue", () => {
    open(state => { state.billing = { ...state.billing, rates: { ...state.billing.rates, answerPoints: 7, screenshotAnswerPoints: 18, knowledgeIndexMinimumPoints: 25 }, catalog: [{ ...state.billing.catalog.find(p => p.kind === "time_pass")!, displayName: "测试会员", priceCents: 1234, durationDays: 3, knowledgeIndexAllowance: 2 }] }; });
    const pricing = document.querySelector("#pricing-value") as HTMLElement;
    expect(pricing).toHaveTextContent("¥12.34");
    expect(pricing).toHaveTextContent("回答 7 点起 · 截图回答 18 点起");
    expect(pricing).toHaveTextContent("知识材料 25 点起");
    expect(pricing).toHaveTextContent("含 2 份知识材料额度");
    expect(within(pricing).getByRole("link", { name: "查看会员权益 →" })).toHaveAttribute("href", "/app/billing");
  });
  it.each(["missing", "unpublished", "invalid"])("does not invent a free pass for %s catalogue", kind => {
    open(state => { const p = state.billing.catalog.find(p => p.kind === "time_pass")!; state.billing = { ...state.billing, catalog: kind === "missing" ? [] : [{ ...p, published: kind !== "unpublished", priceCents: kind === "invalid" ? 0 : p.priceCents }] }; });
    expect(document.querySelectorAll(".cn-pass-card")).toHaveLength(0);
    expect(screen.getByText(/当前暂无可展示的会员套餐/)).toBeInTheDocument();
    expect(document.querySelector("#pricing-value")).not.toHaveTextContent("¥0.00");
  });
  it("retains both user-controlled films and native scenario disclosure", () => {
    open();
    const videos = [...document.querySelectorAll("video")]; expect(videos).toHaveLength(2);
    videos.forEach(v => { expect(v.muted).toBe(true); expect(v.controls).toBe(true); expect(v.playsInline).toBe(true); expect(v.preload).toBe("metadata"); expect(v.autoplay).toBe(false); });
    const summary = screen.getByText("查看岗位场景与常见使用平台");
    expect(summary.parentElement).not.toHaveAttribute("open"); fireEvent.click(summary); expect(summary.parentElement).toHaveAttribute("open");
  });
  it("keeps static copy, filings, verification and legal links without test prices", () => {
    const html = readFileSync("index.html", "utf8");
    expect(html).toContain("AI 面试助手，让你的经历更好表达。");
    ["从听清问题，到讲清自己", "从准备到连接，三步进入状态", "常见问题", "浙ICP备2026052190号-1", "浙公网安备33010602014812号", "codeva-QBTtniJaXE", "https://mianshiwen.cn/"].forEach(text => expect(html).toContain(text));
    expect(html).not.toMatch(/¥0\.00|98%|\$49\.99/);
  });
});
