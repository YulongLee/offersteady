// Local synthetic preview only; not part of production build entrypoints.
import { createRoot } from "react-dom/client";
import { App } from "../App";
import { syntheticState } from "../test-state";
import { interviewAppAdapter } from "../app-adapter";
window.history.replaceState({}, "", "/");
interviewAppAdapter.getPartnerProgramConfig = async () => ({ enabled: true, configVersion: 1, commissionRateBps: 2000, eligibleOrderDays: 90, refundHoldDays: 7, minimumPayoutCents: 10000, agreementVersion: "synthetic-preview", settlementMode: "manual-monthly" });
createRoot(document.getElementById("root")!).render(<App initialAuthenticated={false} initialState={structuredClone(syntheticState)} />);
