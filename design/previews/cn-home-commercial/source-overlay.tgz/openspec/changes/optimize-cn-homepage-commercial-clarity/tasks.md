## 1. Baseline and scope
- [x] 1.1 Review domestic baseline, partner/video requirements and pricing source; record isolated presentation scope.

## 2. Implementation
- [x] 2.1 Implement concise Chinese journey, real catalogue pricing and retained domestic links/media.
- [x] 2.2 Align static homepage and add regression tests for missing/unpublished catalogue and partner behavior.

## 3. Acceptance
- [x] 3.1 Run tests, typecheck/build/static checks and responsive visual acceptance. Existing SEO redirect/bundle-budget failures remain documented, not waived.
- [x] 3.2 Record screenshots, exact baseline worktree and deployment handoff; do not deploy.
