## Why

The owner requests a Chinese homepage optimization modeled on the accepted international homepage. Repeated sections delay pricing; unsubstantiated hardcoded metrics and zero-price fallbacks undermine commercial clarity.

## What Changes

- Concise Chinese hero, four benefits, earlier server-catalogue pricing, grouped existing videos, compact optional role details, FAQ and closing CTA.
- Preserve domestic partner navigation and feature-gated bottom promotion, contact channels, filings, guide and legal links.
- Remove unsupported volume/efficiency metrics; display only published valid catalogue items and live rates, never invent zero prices when unavailable.
- Align static homepage core copy while leaving live pricing authoritative to the backend.

## Capabilities

### New Capabilities
- `cn-homepage-commercial-clarity`: scoped domestic commercial homepage hierarchy and truthful pricing presentation.

### Modified Capabilities
None. Latest partner navigation spec supersedes earlier bottom-only navigation; retain that existing behavior.

## Impact

Only domestic public presentation, static homepage and tests in the documented production-baseline worktree. No backend, billing transactions, login, partner settlement, AI, audio, private data or international changes. No deployment in this task, dependencies, new API calls or analytics.
