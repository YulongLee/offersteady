## ADDED Requirements

### Requirement: Clear domestic homepage journey
The homepage SHALL present a concise Chinese hero and existing free-use action, four benefits, early domestic pricing, both existing films, optional detailed use cases, FAQ and a final action. It MUST preserve guide, downloads, contact, filing and partner navigation links.

#### Scenario: Visitor evaluates the product
- **WHEN** a visitor opens the homepage
- **THEN** pricing precedes videos and optional use-case details
- **AND** unsupported numerical proof is absent and AI guidance remains distinguished from real experience

### Requirement: Truthful dynamic pricing and unchanged enrollment
Pricing SHALL use the existing billing catalogue/rates; only published valid paid passes SHALL be displayed. Partner bottom discovery SHALL retain the existing enabled-state guard and SHALL NOT enroll visitors automatically.

#### Scenario: Missing or unpublished catalogue items
- **WHEN** catalogue items are absent, unpublished, or have invalid price or duration
- **THEN** no invalid or invented zero-price pass is shown and the billing information link remains available

#### Scenario: Activity is disabled
- **WHEN** the server disables the partner program
- **THEN** bottom commission promotion is absent while the existing navigation and protected dashboard behavior are unchanged

### Requirement: Responsive isolated presentation
The change SHALL preserve native muted inline metadata-preloaded video controls, crawlable static homepage copy, and usable layouts at 320, 390, 900 and 1440 px without modifying core or international behavior.

#### Scenario: Static or narrow-screen access
- **WHEN** the homepage is requested without JavaScript or viewed on a narrow screen
- **THEN** core benefits, setup and legal/contact links remain readable and no unintended page overflow is introduced
