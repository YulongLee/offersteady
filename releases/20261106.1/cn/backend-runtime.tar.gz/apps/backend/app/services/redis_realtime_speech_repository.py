from __future__ import annotations

import json
import threading
import time
from dataclasses import asdict, replace
from typing import Callable, TypeVar

from redis import Redis
import psycopg

from app.core.config import Settings
from app.ports.realtime_speech import (
    AccountDesktopDeviceRecord,
    AsrUsageReport,
    DesktopDeviceRecord,
    QuestionCandidateRecord,
    RealtimeEvent,
    RealtimeFrameReceiptRecord,
    RealtimePublisherRecord,
    SessionDesktopBindingRecord,
    TranscriptSegmentRecord,
    WebSessionHeartbeatRecord,
)
from app.services.realtime_speech_repository import InMemoryRealtimeSpeechRepository
from app.services.cn_realtime_entity_state import CNRealtimeEntityState
from app.core.errors import DomainRequestError


T = TypeVar("T")


class RedisRealtimeSpeechRepository(InMemoryRealtimeSpeechRepository):
    """Shared Redis-backed runtime repository with atomic snapshot updates.

    Raw audio is never included. Redis contains only leases, bindings, receipts,
    transcript metadata and bounded operational events needed for recovery.
    """

    def __init__(self, settings: Settings) -> None:
        super().__init__(state_file=None)
        if not settings.redis_url:
            raise ValueError("redis_url_required")
        self._redis = Redis.from_url(
            settings.redis_url,
            decode_responses=True,
            socket_timeout=settings.redis_socket_timeout_seconds,
            socket_connect_timeout=settings.redis_socket_timeout_seconds,
            health_check_interval=15,
        )
        self._snapshot_key = "offersteady:realtime:runtime:v2"
        self._lock_key = f"{self._snapshot_key}:lock"
        self._receipt_key = f"{self._snapshot_key}:receipts"
        self._publisher_key = f"{self._snapshot_key}:publishers"
        self._publisher_token_key = f"{self._snapshot_key}:publisher-tokens"
        self._transcript_key = f"{self._snapshot_key}:transcripts"
        self._activity_key = f"{self._snapshot_key}:activity"
        self._device_entity_key = f"{self._snapshot_key}:entities:devices:v1"
        self._device_code_index_key = f"{self._snapshot_key}:indexes:device-codes:v1"
        self._web_heartbeat_entity_key = f"{self._snapshot_key}:entities:web-heartbeats:v1"
        self._active_web_user_key = f"{self._snapshot_key}:indexes:active-web-users:v1"
        self._binding_entity_key = f"{self._snapshot_key}:entities:bindings:v1"
        self._latest_binding_device_key = f"{self._snapshot_key}:indexes:binding-devices:v1"
        self._latest_binding_code_key = f"{self._snapshot_key}:indexes:binding-codes:v1"
        self._runtime_lock = threading.RLock()
        self._runtime_owner_scan_lock = threading.Lock()
        self._runtime_owner_scan_cursors: dict[str, int] = {}
        self._runtime_owner_scan_key_index = 0
        self._event_retention = max(100, settings.realtime_event_retention)
        self._runtime_ttl_seconds = max(300, settings.realtime_runtime_ttl_seconds)
        self._settings = settings
        self._cn_controls = (CNRealtimeEntityState(self._redis, base=self._snapshot_key, ttl=self._runtime_ttl_seconds, retention=self._event_retention)
                             if settings.product_edition == "cn" else None)
        if self._cn_controls is not None:
            self._binding_entity_key = self._cn_controls.keys[2]
            self._latest_binding_device_key = self._cn_controls.keys[3]
            self._latest_binding_code_key = self._cn_controls.keys[4]
        self._event_diagnostic_lock = threading.Lock()
        self._event_diagnostics = {
            "xaddCount": 0,
            "xaddLatestMs": 0,
            "xaddMaxMs": 0,
            "xreadCount": 0,
            "xreadLatestMs": 0,
            "xreadMaxMs": 0,
            "eventLatestLagMs": 0,
            "streamLength": 0,
            "pendingEvents": 0,
            "pendingApplicable": False,
            "consumerMode": "xread-no-group",
            "globalSnapshotWriteCount": 0,
            "globalSnapshotLatestBytes": 0,
            "entityWriteCount": 0,
            "entitySeedCount": 0,
        }
        self._redis.ping()
        self._reload()

    def _snapshot(self) -> dict[str, object]:
        return {
            # Publishers are stored as entity-scoped hashes. Keep this field empty
            # so an audio lifecycle update never expands the global snapshot.
            "publishers": [],
            "receipts": [],
            "transcripts": [],
            "candidates": [asdict(item) for item in self.candidates.values()],
            "events": [],
            "activity": self.session_activity_versions,
            "devices": [asdict(item) for item in self.desktop_devices_by_id.values()],
            "accountDevices": [asdict(item) for item in self.account_desktop_devices.values()],
            "bindings": [asdict(item) for item in self.session_bindings.values()],
            "heartbeats": [asdict(item) for item in self.web_session_heartbeats.values()],
        }

    def _ensure_event_diagnostics(self) -> None:
        if hasattr(self, "_event_diagnostic_lock"):
            return
        self._event_diagnostic_lock = threading.Lock()
        self._event_diagnostics = {
            "xaddCount": 0,
            "xaddLatestMs": 0,
            "xaddMaxMs": 0,
            "xreadCount": 0,
            "xreadLatestMs": 0,
            "xreadMaxMs": 0,
            "eventLatestLagMs": 0,
            "streamLength": 0,
            "pendingEvents": 0,
            "pendingApplicable": False,
            "consumerMode": "xread-no-group",
            "globalSnapshotWriteCount": 0,
            "globalSnapshotLatestBytes": 0,
            "entityWriteCount": 0,
            "entitySeedCount": 0,
        }

    @staticmethod
    def _web_heartbeat_field(*, user_id: str, session_id: str) -> str:
        return f"{user_id}|{session_id}"

    @staticmethod
    def _binding_field(*, user_id: str, session_id: str) -> str:
        return f"{user_id}|{session_id}"

    @staticmethod
    def _binding_device_field(*, device_id: str, manual_code: str) -> str:
        return f"{device_id}|{manual_code}"

    def _record_storage_diagnostic(self, key: str, *, value: int = 1) -> None:
        self._ensure_event_diagnostics()
        with self._event_diagnostic_lock:
            if key == "globalSnapshotLatestBytes":
                self._event_diagnostics[key] = value
            else:
                self._event_diagnostics[key] = int(self._event_diagnostics.get(key, 0)) + value

    def _reload(self) -> None:
        raw = self._redis.get(self._snapshot_key)
        payload = json.loads(raw) if raw else {}
        self.publishers_by_id = {}
        self.publishers_by_token = {}
        legacy_publishers = payload.get("publishers", [])
        for item in legacy_publishers:
            record = RealtimePublisherRecord(**item)
            self.publishers_by_id[record.publisher_id] = record
            self.publishers_by_token[record.token] = record.publisher_id
        if legacy_publishers:
            # One-time, idempotent migration keeps reconnect tokens valid while
            # publisher lifecycle updates move away from the global snapshot.
            pipeline = self._redis.pipeline()
            for item in legacy_publishers:
                record = RealtimePublisherRecord(**item)
                pipeline.hset(
                    self._publisher_key,
                    record.publisher_id,
                    json.dumps(asdict(record), ensure_ascii=True, separators=(",", ":")),
                )
                pipeline.hset(self._publisher_token_key, record.token, record.publisher_id)
            pipeline.expire(self._publisher_key, self._runtime_ttl_seconds)
            pipeline.expire(self._publisher_token_key, self._runtime_ttl_seconds)
            pipeline.execute()
        for _publisher_id, raw_publisher in self._redis.hscan_iter(self._publisher_key):
            record = RealtimePublisherRecord(**json.loads(raw_publisher))
            self.publishers_by_id[record.publisher_id] = record
            self.publishers_by_token[record.token] = record.publisher_id
        self.frame_receipts = {}
        for item in payload.get("receipts", []):
            record = RealtimeFrameReceiptRecord(**item)
            self.frame_receipts.setdefault(record.session_id, {})[(record.source_kind, record.source_id)] = record
        self.transcripts = {}
        for item in payload.get("transcripts", []):
            usage = item.get("usage")
            if isinstance(usage, dict):
                item["usage"] = AsrUsageReport(**usage)
            record = TranscriptSegmentRecord(**item)
            self.transcripts.setdefault(record.session_id, {})[record.segment_id] = record
        self.candidates = {}
        for item in payload.get("candidates", []):
            record = QuestionCandidateRecord(**item)
            self.candidates[record.candidate_id] = record
        self.events = {}
        for item in payload.get("events", []):
            record = RealtimeEvent(**item)
            self.events.setdefault(record.session_id, []).append(record)
        self.session_activity_versions = {str(key): int(value) for key, value in payload.get("activity", {}).items()}
        for session_id, version in self._redis.hgetall(self._activity_key).items():
            self.session_activity_versions[session_id] = max(
                self.session_activity_versions.get(session_id, 0),
                int(version),
            )
        self.desktop_devices_by_id = {}
        self.desktop_devices_by_code = {}
        for item in payload.get("devices", []):
            record = DesktopDeviceRecord(**item)
            self.desktop_devices_by_id[record.device_id] = record
            self.desktop_devices_by_code[record.manual_code] = record.device_id
        self.account_desktop_devices = {}
        for item in payload.get("accountDevices", []):
            record = AccountDesktopDeviceRecord(**item)
            self.account_desktop_devices[(record.owner_user_id, record.device_id)] = record
        self.session_bindings = {}
        for item in payload.get("bindings", []):
            record = SessionDesktopBindingRecord(**item)
            self.session_bindings[(record.owner_user_id, record.session_id)] = record
        if not self.account_desktop_devices:
            for binding in self.session_bindings.values():
                key = (binding.owner_user_id, binding.device_id)
                current = self.account_desktop_devices.get(key)
                self.account_desktop_devices[key] = AccountDesktopDeviceRecord(
                    owner_user_id=binding.owner_user_id,
                    device_id=binding.device_id,
                    manual_code=binding.manual_code,
                    linked_at_ms=min(current.linked_at_ms, binding.bound_at_ms) if current else binding.bound_at_ms,
                    last_used_at_ms=max(current.last_used_at_ms, binding.bound_at_ms) if current else binding.bound_at_ms,
                )
        self.web_session_heartbeats = {}
        for item in payload.get("heartbeats", []):
            record = WebSessionHeartbeatRecord(**item)
            self.web_session_heartbeats[(record.owner_user_id, record.session_id)] = record
        self._overlay_entity_state()

    def _overlay_entity_state(self) -> None:
        raw_devices = self._redis.hgetall(self._device_entity_key)
        if raw_devices:
            device_code_mapping: dict[str, str] = {}
            for raw in raw_devices.values():
                record = DesktopDeviceRecord(**json.loads(raw))
                current = self.desktop_devices_by_id.get(record.device_id)
                if current is None or (record.generation, record.last_seen_at_ms) >= (
                    current.generation,
                    current.last_seen_at_ms,
                ):
                    self.desktop_devices_by_id[record.device_id] = record
                    self.desktop_devices_by_code[record.manual_code] = record.device_id
                device_code_mapping[record.manual_code] = record.device_id
            if device_code_mapping:
                self._redis.hset(self._device_code_index_key, mapping=device_code_mapping)
                self._redis.expire(self._device_code_index_key, self._runtime_ttl_seconds)
        elif self.desktop_devices_by_id:
            pipeline = self._redis.pipeline()
            for record in self.desktop_devices_by_id.values():
                pipeline.hset(
                    self._device_entity_key,
                    record.device_id,
                    json.dumps(asdict(record), ensure_ascii=True, separators=(",", ":")),
                )
                pipeline.hset(self._device_code_index_key, record.manual_code, record.device_id)
            pipeline.expire(self._device_entity_key, self._runtime_ttl_seconds)
            pipeline.expire(self._device_code_index_key, self._runtime_ttl_seconds)
            pipeline.execute()
            self._record_storage_diagnostic("entitySeedCount", value=len(self.desktop_devices_by_id))

        if self._cn_entity_mode():
            self._overlay_cn_control_entities()
        else:
            raw_bindings = self._redis.hgetall(self._binding_entity_key)
            if raw_bindings:
                newest_by_device: dict[str, SessionDesktopBindingRecord] = {}
                newest_by_code: dict[str, SessionDesktopBindingRecord] = {}
                for raw in raw_bindings.values():
                    record = SessionDesktopBindingRecord(**json.loads(raw))
                    key = (record.owner_user_id, record.session_id)
                    current = self.session_bindings.get(key)
                    if current is None or (record.binding_generation, record.bound_at_ms) >= (
                        current.binding_generation,
                        current.bound_at_ms,
                    ):
                        self.session_bindings[key] = record
                    device_field = self._binding_device_field(
                        device_id=record.device_id,
                        manual_code=record.manual_code,
                    )
                    current_device = newest_by_device.get(device_field)
                    if current_device is None or (record.binding_generation, record.bound_at_ms) >= (
                        current_device.binding_generation,
                        current_device.bound_at_ms,
                    ):
                        newest_by_device[device_field] = record
                    current_code = newest_by_code.get(record.manual_code)
                    if current_code is None or (record.binding_generation, record.bound_at_ms) >= (
                        current_code.binding_generation,
                        current_code.bound_at_ms,
                    ):
                        newest_by_code[record.manual_code] = record
                pipeline = self._redis.pipeline()
                for field, record in newest_by_device.items():
                    pipeline.hset(
                        self._latest_binding_device_key,
                        field,
                        json.dumps(asdict(record), ensure_ascii=True, separators=(",", ":")),
                    )
                for code, record in newest_by_code.items():
                    pipeline.hset(
                        self._latest_binding_code_key,
                        code,
                        json.dumps(asdict(record), ensure_ascii=True, separators=(",", ":")),
                    )
                pipeline.expire(self._binding_entity_key, self._runtime_ttl_seconds)
                pipeline.expire(self._latest_binding_device_key, self._runtime_ttl_seconds)
                pipeline.expire(self._latest_binding_code_key, self._runtime_ttl_seconds)
                pipeline.execute()
            elif self.session_bindings:
                pipeline = self._redis.pipeline()
                newest_by_device: dict[str, SessionDesktopBindingRecord] = {}
                newest_by_code: dict[str, SessionDesktopBindingRecord] = {}
                for record in self.session_bindings.values():
                    encoded = json.dumps(asdict(record), ensure_ascii=True, separators=(",", ":"))
                    pipeline.hset(
                        self._binding_entity_key,
                        self._binding_field(user_id=record.owner_user_id, session_id=record.session_id),
                        encoded,
                    )
                    device_field = self._binding_device_field(
                        device_id=record.device_id,
                        manual_code=record.manual_code,
                    )
                    current_device = newest_by_device.get(device_field)
                    if current_device is None or (record.binding_generation, record.bound_at_ms) >= (
                        current_device.binding_generation,
                        current_device.bound_at_ms,
                    ):
                        newest_by_device[device_field] = record
                    current_code = newest_by_code.get(record.manual_code)
                    if current_code is None or (record.binding_generation, record.bound_at_ms) >= (
                        current_code.binding_generation,
                        current_code.bound_at_ms,
                    ):
                        newest_by_code[record.manual_code] = record
                for field, record in newest_by_device.items():
                    pipeline.hset(
                        self._latest_binding_device_key,
                        field,
                        json.dumps(asdict(record), ensure_ascii=True, separators=(",", ":")),
                    )
                for code, record in newest_by_code.items():
                    pipeline.hset(
                        self._latest_binding_code_key,
                        code,
                        json.dumps(asdict(record), ensure_ascii=True, separators=(",", ":")),
                    )
                for key in (self._binding_entity_key, self._latest_binding_device_key, self._latest_binding_code_key):
                    pipeline.expire(key, self._runtime_ttl_seconds)
                pipeline.execute()
                self._record_storage_diagnostic("entitySeedCount", value=len(self.session_bindings))

        raw_heartbeats = self._redis.hgetall(self._web_heartbeat_entity_key)
        if raw_heartbeats:
            active_by_user: dict[str, WebSessionHeartbeatRecord] = {}
            for raw in raw_heartbeats.values():
                record = WebSessionHeartbeatRecord(**json.loads(raw))
                key = (record.owner_user_id, record.session_id)
                current = self.web_session_heartbeats.get(key)
                if current is None or (record.lease_generation, record.seen_at_ms) >= (
                    current.lease_generation,
                    current.seen_at_ms,
                ):
                    self.web_session_heartbeats[key] = record
                current_active = active_by_user.get(record.owner_user_id)
                if record.page == "live" and record.page_instance_id and (
                    current_active is None
                    or (record.lease_generation, record.seen_at_ms)
                    >= (current_active.lease_generation, current_active.seen_at_ms)
                ):
                    active_by_user[record.owner_user_id] = record
            if active_by_user:
                self._redis.hset(
                    self._active_web_user_key,
                    mapping={
                        user_id: json.dumps(asdict(record), ensure_ascii=True, separators=(",", ":"))
                        for user_id, record in active_by_user.items()
                    },
                )
                self._redis.expire(self._active_web_user_key, self._runtime_ttl_seconds)
        elif self.web_session_heartbeats:
            pipeline = self._redis.pipeline()
            for record in self.web_session_heartbeats.values():
                encoded = json.dumps(asdict(record), ensure_ascii=True, separators=(",", ":"))
                pipeline.hset(
                    self._web_heartbeat_entity_key,
                    self._web_heartbeat_field(user_id=record.owner_user_id, session_id=record.session_id),
                    encoded,
                )
                if record.page == "live" and record.page_instance_id:
                    pipeline.hset(self._active_web_user_key, record.owner_user_id, encoded)
            pipeline.expire(self._web_heartbeat_entity_key, self._runtime_ttl_seconds)
            pipeline.expire(self._active_web_user_key, self._runtime_ttl_seconds)
            pipeline.execute()
            self._record_storage_diagnostic("entitySeedCount", value=len(self.web_session_heartbeats))

    def _cn_entity_mode(self) -> bool:
        return getattr(self, "_cn_controls", None) is not None

    def _overlay_cn_control_entities(self) -> None:
        store = self._cn_controls
        # Old v1 entities may be newer than the old snapshot. They remain raw
        # and untouched so an idle rollback can still decode its own protocol.
        legacy_bindings = dict(self.session_bindings)
        for raw in self._redis.hvals(store.legacy_bindings):
            record = SessionDesktopBindingRecord(**json.loads(raw))
            key = (record.owner_user_id, record.session_id)
            current = legacy_bindings.get(key)
            if current is None or (record.binding_generation, record.bound_at_ms) >= (current.binding_generation, current.bound_at_ms):
                legacy_bindings[key] = record
        count = store.seed(candidates=self.candidates.values(), accounts=self.account_desktop_devices.values(),
                           bindings=legacy_bindings.values(), activity=self.session_activity_versions)
        store.seed_owner_indexes()
        self.candidates = {x.candidate_id: x for x in store.all_records("candidate")}
        self.account_desktop_devices = {(x.owner_user_id, x.device_id): x for x in store.all_records("account")}
        self.session_bindings = {(x.owner_user_id, x.session_id): x for x in store.all_records("binding")}
        self._record_storage_diagnostic("entitySeedCount", value=count)

    def _cn_saved(self, op, record, *, expected=None):
        stored, version = self._cn_controls.save(op, record, expected=expected)
        if stored is None:
            if expected is not None:
                return None
            if op == "event":
                # Match the service's established retired-event safe drop,
                # including a restart that only knows the persistent fence.
                return record
            raise DomainRequestError("realtime-speech", "runtime-save", "面试会话已结束，不能继续更新实时状态。", 409, "session_not_live")
        with self._runtime_lock:
            if op == "candidate": self.candidates[stored.candidate_id] = stored
            elif op == "account": self.account_desktop_devices[(stored.owner_user_id, stored.device_id)] = stored
            elif op == "binding": self.session_bindings[(stored.owner_user_id, stored.session_id)] = stored
            elif op in {"heartbeat", "claim"}: self.web_session_heartbeats[(stored.owner_user_id, stored.session_id)] = stored
            elif op == "publisher":
                self.publishers_by_id[stored.publisher_id] = stored
                self.publishers_by_token[stored.token] = stored.publisher_id
            elif op == "receipt": self.frame_receipts.setdefault(stored.session_id, {})[(stored.source_kind, stored.source_id)] = stored
            elif op == "transcript": self.transcripts.setdefault(stored.session_id, {})[stored.segment_id] = stored
            elif op == "event":
                entries = self.events.setdefault(stored.session_id, [])
                entries.append(stored)
                entries.sort(key=lambda x: (x.created_at_ms, x.event_id))
                self.event_cursors.setdefault(stored.session_id, {})[stored.event_id] = version
                with self._event_condition:
                    self._event_condition.notify_all()
            if version:
                self.session_activity_versions[stored.session_id] = max(version, self.session_activity_versions.get(stored.session_id, 0))
        self._record_storage_diagnostic("entityWriteCount")
        return stored

    def _read(self, operation: Callable[[], T]) -> T:
        with self._runtime_lock:
            if not self._cn_entity_mode() and self._settings.realtime_redis_snapshot_reload_on_access:
                self._reload()
            return operation()

    def _write(self, operation: Callable[[], T]) -> T:
        with self._redis.lock(self._lock_key, timeout=5, blocking_timeout=2):
            with self._runtime_lock:
                if self._settings.realtime_redis_snapshot_reload_on_access:
                    self._reload()
                result = operation()
                encoded = json.dumps(self._snapshot(), ensure_ascii=True, separators=(",", ":"))
                self._redis.set(self._snapshot_key, encoded)
                self._redis.expire(self._snapshot_key, self._runtime_ttl_seconds)
                if self.session_activity_versions:
                    self._redis.hset(self._activity_key, mapping=self.session_activity_versions)
                    self._redis.expire(self._activity_key, self._runtime_ttl_seconds)
                self._record_storage_diagnostic("globalSnapshotWriteCount")
                self._record_storage_diagnostic("globalSnapshotLatestBytes", value=len(encoded.encode("utf-8")))
                return result

    def _persist_desktop_device_entity(self, record: DesktopDeviceRecord) -> None:
        pipeline = self._redis.pipeline()
        pipeline.hset(
            self._device_entity_key,
            record.device_id,
            json.dumps(asdict(record), ensure_ascii=True, separators=(",", ":")),
        )
        pipeline.hset(self._device_code_index_key, record.manual_code, record.device_id)
        pipeline.expire(self._device_entity_key, self._runtime_ttl_seconds)
        pipeline.expire(self._device_code_index_key, self._runtime_ttl_seconds)
        pipeline.execute()
        self._record_storage_diagnostic("entityWriteCount")

    def save_desktop_device(self, device):
        with self._runtime_lock:
            stored = super().save_desktop_device(device)
        self._persist_desktop_device_entity(stored)
        return stored
    def get_desktop_device_by_code(self, manual_code):
        device_id = self._redis.hget(self._device_code_index_key, manual_code)
        raw = self._redis.hget(self._device_entity_key, device_id) if device_id else None
        if raw:
            record = DesktopDeviceRecord(**json.loads(raw))
            with self._runtime_lock:
                self.desktop_devices_by_id[record.device_id] = record
                self.desktop_devices_by_code[record.manual_code] = record.device_id
            return replace(record)
        return self._read(lambda: super(RedisRealtimeSpeechRepository, self).get_desktop_device_by_code(manual_code))
    def save_account_desktop_device(self, association):
        if self._cn_entity_mode(): return self._cn_saved("account", association)
        return self._write(lambda: super(RedisRealtimeSpeechRepository, self).save_account_desktop_device(association))
    def get_account_desktop_device(self, *, user_id, device_id):
        if self._cn_entity_mode():
            raw = self._redis.hget(self._cn_controls.accounts, f"{user_id}|{device_id}")
            return AccountDesktopDeviceRecord(**json.loads(raw)) if raw else None
        return self._read(lambda: super(RedisRealtimeSpeechRepository, self).get_account_desktop_device(user_id=user_id, device_id=device_id))
    def get_last_account_desktop_device(self, *, user_id):
        if self._cn_entity_mode():
            records = self.list_account_desktop_devices(user_id=user_id)
            return records[0] if records else None
        return self._read(lambda: super(RedisRealtimeSpeechRepository, self).get_last_account_desktop_device(user_id=user_id))
    def list_account_desktop_devices(self, *, user_id):
        if self._cn_entity_mode():
            return sorted(self._cn_controls.owner_records("accounts", user_id), key=lambda x: (x.last_used_at_ms, x.device_id), reverse=True)
        return self._read(lambda: super(RedisRealtimeSpeechRepository, self).list_account_desktop_devices(user_id=user_id))
    def save_session_desktop_binding(self, binding):
        if self._cn_entity_mode(): return self._cn_saved("binding", binding)
        stored = self._write(lambda: super(RedisRealtimeSpeechRepository, self).save_session_desktop_binding(binding))
        encoded = json.dumps(asdict(stored), ensure_ascii=True, separators=(",", ":"))
        pipeline = self._redis.pipeline()
        pipeline.hset(
            self._binding_entity_key,
            self._binding_field(user_id=stored.owner_user_id, session_id=stored.session_id),
            encoded,
        )
        pipeline.hset(
            self._latest_binding_device_key,
            self._binding_device_field(device_id=stored.device_id, manual_code=stored.manual_code),
            encoded,
        )
        pipeline.hset(self._latest_binding_code_key, stored.manual_code, encoded)
        for key in (self._binding_entity_key, self._latest_binding_device_key, self._latest_binding_code_key):
            pipeline.expire(key, self._runtime_ttl_seconds)
        pipeline.execute()
        self._record_storage_diagnostic("entityWriteCount")
        return stored

    def get_session_desktop_binding(self, *, user_id, session_id):
        raw = self._redis.hget(
            self._binding_entity_key,
            self._binding_field(user_id=user_id, session_id=session_id),
        )
        if self._cn_entity_mode():
            record = self._cn_controls.decode(SessionDesktopBindingRecord, raw) if raw else None
            return replace(record, status="stale") if record and self._cn_controls.is_retired(record.session_id) else record
        return SessionDesktopBindingRecord(**json.loads(raw)) if raw else self._read(
            lambda: super(RedisRealtimeSpeechRepository, self).get_session_desktop_binding(user_id=user_id, session_id=session_id)
        )

    def get_latest_session_desktop_binding_for_device(self, *, device_id, manual_code):
        if self._cn_entity_mode(): return self._cn_controls.latest_binding(manual_code=manual_code, device_id=device_id)
        raw = self._redis.hget(
            self._latest_binding_device_key,
            self._binding_device_field(device_id=device_id, manual_code=manual_code),
        )
        if self._cn_entity_mode():
            record = SessionDesktopBindingRecord(**json.loads(raw)) if raw else None
            return replace(record, status="stale") if record and self._cn_controls.is_retired(record.session_id) else record
        return SessionDesktopBindingRecord(**json.loads(raw)) if raw else self._read(
            lambda: super(RedisRealtimeSpeechRepository, self).get_latest_session_desktop_binding_for_device(device_id=device_id, manual_code=manual_code)
        )

    def get_latest_session_desktop_binding_by_code(self, *, manual_code):
        if self._cn_entity_mode(): return self._cn_controls.latest_binding(manual_code=manual_code)
        raw = self._redis.hget(self._latest_binding_code_key, manual_code)
        if self._cn_entity_mode():
            record = SessionDesktopBindingRecord(**json.loads(raw)) if raw else None
            return replace(record, status="stale") if record and self._cn_controls.is_retired(record.session_id) else record
        return SessionDesktopBindingRecord(**json.loads(raw)) if raw else self._read(
            lambda: super(RedisRealtimeSpeechRepository, self).get_latest_session_desktop_binding_by_code(manual_code=manual_code)
        )
    def list_session_desktop_bindings_for_device(self, *, device_id, manual_code):
        if self._cn_entity_mode():
            return sorted((x for x in self._cn_controls.all_records("binding") if x.device_id == device_id and x.manual_code == manual_code), key=lambda x: (x.bound_at_ms, x.session_id))
        return self._read(lambda: super(RedisRealtimeSpeechRepository, self).list_session_desktop_bindings_for_device(device_id=device_id, manual_code=manual_code))

    def get_pinned_session_desktop_binding(self, *, device_id, manual_code, session_id, binding_id):
        if self._cn_entity_mode():
            return self._cn_controls.pinned_binding(device_id=device_id, manual_code=manual_code,
                                                    session_id=session_id, binding_id=binding_id)
        return next((item for item in self.list_session_desktop_bindings_for_device(
            device_id=device_id, manual_code=manual_code)
            if item.session_id == session_id and item.binding_id == binding_id), None)

    def list_session_desktop_bindings_for_user(self, *, user_id):
        if self._cn_entity_mode():
            return sorted(self._cn_controls.owner_records("bindings", user_id), key=lambda x: (x.bound_at_ms, x.session_id))
        return self._read(lambda: super(RedisRealtimeSpeechRepository, self).list_session_desktop_bindings_for_user(user_id=user_id))
    def _persist_web_heartbeat_entity(self, record: WebSessionHeartbeatRecord) -> None:
        encoded = json.dumps(asdict(record), ensure_ascii=True, separators=(",", ":"))
        pipeline = self._redis.pipeline()
        pipeline.hset(
            self._web_heartbeat_entity_key,
            self._web_heartbeat_field(user_id=record.owner_user_id, session_id=record.session_id),
            encoded,
        )
        if record.page == "live" and record.page_instance_id:
            pipeline.hset(self._active_web_user_key, record.owner_user_id, encoded)
        pipeline.expire(self._web_heartbeat_entity_key, self._runtime_ttl_seconds)
        pipeline.expire(self._active_web_user_key, self._runtime_ttl_seconds)
        pipeline.execute()
        self._record_storage_diagnostic("entityWriteCount")

    def save_web_session_heartbeat(self, heartbeat):
        if self._cn_entity_mode(): return self._cn_saved("heartbeat", heartbeat)
        with self._runtime_lock:
            stored = super().save_web_session_heartbeat(heartbeat)
        self._persist_web_heartbeat_entity(stored)
        return stored
    def get_web_session_heartbeat(self, *, user_id, session_id):
        if self._cn_entity_mode() and self._cn_controls.is_retired(session_id): return None
        raw = self._redis.hget(
            self._web_heartbeat_entity_key,
            self._web_heartbeat_field(user_id=user_id, session_id=session_id),
        )
        return WebSessionHeartbeatRecord(**json.loads(raw)) if raw else self._read(
            lambda: super(RedisRealtimeSpeechRepository, self).get_web_session_heartbeat(user_id=user_id, session_id=session_id)
        )
    def claim_live_web_session(self, heartbeat):
        if self._cn_entity_mode(): return self._cn_saved("claim", heartbeat)
        user_lock_key = f"{self._lock_key}:live-user:{heartbeat.owner_user_id}"
        with self._redis.lock(user_lock_key, timeout=5, blocking_timeout=2):
            with self._runtime_lock:
                raw_active = self._redis.hget(self._active_web_user_key, heartbeat.owner_user_id)
                if raw_active:
                    active = WebSessionHeartbeatRecord(**json.loads(raw_active))
                    self.web_session_heartbeats[(active.owner_user_id, active.session_id)] = active
                stored = super().claim_live_web_session(heartbeat)
            self._persist_web_heartbeat_entity(stored)
            return stored
    def get_active_live_web_session(self, *, user_id):
        raw = self._redis.hget(self._active_web_user_key, user_id)
        if self._cn_entity_mode():
            record = WebSessionHeartbeatRecord(**json.loads(raw)) if raw else None
            return None if record and self._cn_controls.is_retired(record.session_id) else record
        return WebSessionHeartbeatRecord(**json.loads(raw)) if raw else self._read(
            lambda: super(RedisRealtimeSpeechRepository, self).get_active_live_web_session(user_id=user_id)
        )
    def save_publisher(self, publisher):
        if self._cn_entity_mode(): return self._cn_saved("publisher", publisher)
        with self._runtime_lock:
            stored = super().save_publisher(publisher)
        payload = json.dumps(asdict(stored), ensure_ascii=True, separators=(",", ":"))
        pipeline = self._redis.pipeline()
        pipeline.hset(self._publisher_key, stored.publisher_id, payload)
        pipeline.hset(self._publisher_token_key, stored.token, stored.publisher_id)
        pipeline.expire(self._publisher_key, self._runtime_ttl_seconds)
        pipeline.expire(self._publisher_token_key, self._runtime_ttl_seconds)
        pipeline.execute()
        return stored

    def get_publisher_by_token(self, token):
        publisher_id = self._redis.hget(self._publisher_token_key, token)
        if publisher_id:
            return self.get_publisher(publisher_id)
        if self._cn_entity_mode(): return None
        return self._read(lambda: super(RedisRealtimeSpeechRepository, self).get_publisher_by_token(token))

    def get_publisher(self, publisher_id):
        raw = self._redis.hget(self._publisher_key, publisher_id)
        if raw:
            record = RealtimePublisherRecord(**json.loads(raw))
            return None if self._cn_entity_mode() and self._cn_controls.is_retired(record.session_id) else record
        if self._cn_entity_mode(): return None
        return self._read(lambda: super(RedisRealtimeSpeechRepository, self).get_publisher(publisher_id))

    def list_publishers_for_session(self, *, session_id):
        if self._cn_entity_mode() and self._cn_controls.is_retired(session_id): return []
        records = []
        for _field, raw in self._redis.hscan_iter(self._publisher_key):
            payload = json.loads(raw)
            if payload.get("session_id") == session_id:
                records.append(RealtimePublisherRecord(**payload))
        if records:
            return sorted(records, key=lambda item: item.issued_at_ms)
        if self._cn_entity_mode(): return []
        return self._read(lambda: super(RedisRealtimeSpeechRepository, self).list_publishers_for_session(session_id=session_id))

    def prune_publishers_for_session(self, *, session_id, keep_publisher_ids):
        removable = [
            item for item in self.list_publishers_for_session(session_id=session_id)
            if item.publisher_id not in keep_publisher_ids
        ]
        if not removable:
            return None
        with self._runtime_lock:
            super().prune_publishers_for_session(session_id=session_id, keep_publisher_ids=keep_publisher_ids)
        pipeline = self._redis.pipeline()
        for item in removable:
            pipeline.hdel(self._publisher_key, item.publisher_id)
            pipeline.hdel(self._publisher_token_key, item.token)
        pipeline.execute()
        return None

    def clear_session_runtime(self, *, session_id, preserve_transcripts=True):
        cn_cleared = self._cn_controls.call("clear", session_id) if self._cn_entity_mode() else 0
        with self._runtime_lock:
            result = super().clear_session_runtime(
                session_id=session_id,
                preserve_transcripts=preserve_transcripts,
            )
        publisher_ids: list[str] = []
        publisher_tokens: list[str] = []
        for publisher_id, raw in self._redis.hscan_iter(self._publisher_key):
            try:
                payload = json.loads(raw)
            except (TypeError, ValueError):
                continue
            if payload.get("session_id") == session_id:
                publisher_ids.append(publisher_id)
                token = payload.get("token")
                if isinstance(token, str):
                    publisher_tokens.append(token)
        receipt_fields = [
            field for field, _raw in self._redis.hscan_iter(
                self._receipt_key, match=f"{session_id}:*"
            )
        ]
        heartbeat_fields = [
            field for field, _raw in self._redis.hscan_iter(
                self._web_heartbeat_entity_key, match=f"*|{session_id}"
            )
        ]
        active_user_fields: list[str] = []
        for user_id, raw in self._redis.hscan_iter(self._active_web_user_key):
            try:
                payload = json.loads(raw)
            except (TypeError, ValueError):
                continue
            if payload.get("session_id") == session_id:
                active_user_fields.append(user_id)
        transcript_fields: list[str] = []
        if not preserve_transcripts:
            transcript_fields = [
                field for field, _raw in self._redis.hscan_iter(
                    self._transcript_key, match=f"{session_id}:*"
                )
            ]
        pipeline = self._redis.pipeline()
        if publisher_ids:
            pipeline.hdel(self._publisher_key, *publisher_ids)
        if publisher_tokens:
            pipeline.hdel(self._publisher_token_key, *publisher_tokens)
        if receipt_fields:
            pipeline.hdel(self._receipt_key, *receipt_fields)
        if heartbeat_fields:
            pipeline.hdel(self._web_heartbeat_entity_key, *heartbeat_fields)
        if active_user_fields:
            pipeline.hdel(self._active_web_user_key, *active_user_fields)
        if transcript_fields:
            pipeline.hdel(self._transcript_key, *transcript_fields)
        pipeline.delete(
            f"offersteady:realtime:events:{session_id}",
            self._event_cursor_index_key(session_id),
            self._latest_event_key(session_id),
        )
        pipeline.hdel(self._activity_key, session_id)
        pipeline.execute()
        if not self._cn_entity_mode():
            with self._redis.lock(self._lock_key, timeout=5, blocking_timeout=2):
                with self._runtime_lock:
                    encoded = json.dumps(self._snapshot(), ensure_ascii=True, separators=(",", ":"))
                    self._redis.set(self._snapshot_key, encoded)
                    self._redis.expire(self._snapshot_key, self._runtime_ttl_seconds)
        result["cleared_publishers"] = max(result["cleared_publishers"], len(publisher_ids))
        result["cleared_frame_receipts"] = max(result["cleared_frame_receipts"], len(receipt_fields))
        result["cleared_candidates"] = max(result.get("cleared_candidates", 0), int(cn_cleared))
        result["cleared_transcripts"] = max(result["cleared_transcripts"], len(transcript_fields))
        return result

    def list_runtime_session_owners(self, *, limit: int = 128) -> dict[str, str]:
        """Discover orphan candidates with a bounded, rotating Redis scan."""
        bounded_limit = max(1, limit)
        scan_budget = max(24, bounded_limit * 3)
        owners: dict[str, str] = {}
        keys = (self._publisher_key, self._receipt_key, self._web_heartbeat_entity_key)
        with self._runtime_owner_scan_lock:
            start_index = self._runtime_owner_scan_key_index % len(keys)
            scanned = 0
            for offset in range(len(keys)):
                if scanned >= scan_budget or len(owners) >= bounded_limit:
                    break
                key = keys[(start_index + offset) % len(keys)]
                cursor = self._runtime_owner_scan_cursors.get(key, 0)
                next_cursor, batch = self._redis.hscan(
                    key,
                    cursor=cursor,
                    count=min(64, scan_budget - scanned),
                )
                self._runtime_owner_scan_cursors[key] = int(next_cursor)
                scanned += len(batch)
                for raw in batch.values():
                    try:
                        payload = json.loads(raw)
                    except (TypeError, ValueError):
                        continue
                    session_id = str(payload.get("session_id") or "")
                    owner_user_id = str(payload.get("owner_user_id") or "")
                    if session_id and owner_user_id:
                        owners.setdefault(session_id, owner_user_id)
                    if len(owners) >= bounded_limit:
                        break
            self._runtime_owner_scan_key_index = (start_index + 1) % len(keys)
        return owners
    def save_frame_receipt(self, receipt):
        if self._cn_entity_mode(): return self._cn_saved("receipt", receipt)
        with self._runtime_lock:
            stored = super().save_frame_receipt(receipt)
        field = f"{stored.session_id}:{stored.source_kind}:{stored.source_id}"
        self._redis.hset(self._receipt_key, field, json.dumps(asdict(stored), ensure_ascii=True, separators=(",", ":")))
        self._redis.expire(self._receipt_key, self._runtime_ttl_seconds)
        return stored

    def get_frame_receipt(self, *, session_id, source_kind, source_id):
        raw = self._redis.hget(self._receipt_key, f"{session_id}:{source_kind}:{source_id}")
        if raw:
            return RealtimeFrameReceiptRecord(**json.loads(raw))
        return None

    def list_frame_receipts_for_session(self, *, session_id):
        prefix = f"{session_id}:"
        records = [
            RealtimeFrameReceiptRecord(**json.loads(raw))
            for field, raw in self._redis.hscan_iter(self._receipt_key, match=f"{prefix}*")
        ]
        return sorted(records, key=lambda item: (item.source_kind, item.source_id))

    def save_transcript(self, segment):
        if self._cn_entity_mode(): return self._cn_saved("transcript", segment)
        with self._runtime_lock:
            persisted_version = self._redis.hget(self._activity_key, segment.session_id)
            if persisted_version is not None:
                self.session_activity_versions[segment.session_id] = max(
                    self.session_activity_versions.get(segment.session_id, 0),
                    int(persisted_version),
                )
            stored = super().save_transcript(segment)
            activity_version = self.session_activity_versions.get(stored.session_id, 0)
        field = f"{stored.session_id}:{stored.segment_id}"
        self._redis.hset(self._transcript_key, field, json.dumps(asdict(stored), ensure_ascii=True, separators=(",", ":")))
        self._redis.expire(self._transcript_key, self._runtime_ttl_seconds)
        self._redis.hset(self._activity_key, stored.session_id, activity_version)
        self._redis.expire(self._activity_key, self._runtime_ttl_seconds)
        self._record_storage_diagnostic("entityWriteCount")
        return stored

    def persist_transcript(self, stored):
        if stored.is_final and self._settings.realtime_transcript_persistence_enabled and self._settings.database_url:
            expires_at_ms = int(time.time() * 1000) + self._settings.realtime_transcript_retention_days * 86_400_000
            with psycopg.connect(self._settings.database_url) as connection:
                with connection.cursor() as cursor:
                    cursor.execute(
                        """
                        INSERT INTO approved_realtime_transcripts
                          (session_id, owner_user_id, segment_id, role, transcript_text, created_at_ms, expires_at_ms)
                        VALUES (%s, %s, %s, %s, %s, %s, %s)
                        ON CONFLICT (session_id, segment_id) DO UPDATE SET
                          role = EXCLUDED.role,
                          transcript_text = EXCLUDED.transcript_text,
                          expires_at_ms = EXCLUDED.expires_at_ms
                        """,
                        (stored.session_id, stored.owner_user_id, stored.segment_id, stored.role, stored.text, stored.created_at_ms, expires_at_ms),
                    )
        return None

    @staticmethod
    def _decode_transcript(raw: str) -> TranscriptSegmentRecord:
        payload = json.loads(raw)
        usage = payload.get("usage")
        if isinstance(usage, dict):
            payload["usage"] = AsrUsageReport(**usage)
        return TranscriptSegmentRecord(**payload)

    def get_transcript(self, session_id, segment_id):
        raw = self._redis.hget(self._transcript_key, f"{session_id}:{segment_id}")
        return self._decode_transcript(raw) if raw else None

    def list_transcripts_for_session(self, *, session_id):
        records = [
            self._decode_transcript(raw)
            for _field, raw in self._redis.hscan_iter(self._transcript_key, match=f"{session_id}:*")
        ]
        return sorted(records, key=lambda item: (item.started_at_ms, item.segment_id, item.revision))
    def save_candidate(self, candidate):
        if self._cn_entity_mode(): return self._cn_saved("candidate", candidate)
        return self._write(lambda: super(RedisRealtimeSpeechRepository, self).save_candidate(candidate))

    def compare_and_save_candidate(self, candidate, *, expected):
        if self._cn_entity_mode(): return self._cn_saved("candidate", candidate, expected=expected)
        return self.save_candidate(candidate)
    def get_candidate(self, candidate_id):
        if self._cn_entity_mode(): return self._cn_controls.candidate(candidate_id)
        return self._read(lambda: super(RedisRealtimeSpeechRepository, self).get_candidate(candidate_id))
    def list_candidates_for_session(self, *, session_id):
        if self._cn_entity_mode(): return self._cn_controls.session_candidates(session_id)
        return self._read(lambda: super(RedisRealtimeSpeechRepository, self).list_candidates_for_session(session_id=session_id))

    def save_event(self, event):
        if self._cn_entity_mode(): return self._save_cn_event(event)
        with self._runtime_lock:
            stored = super().save_event(event)
        stream_key = f"offersteady:realtime:events:{stored.session_id}"
        cursor_index_key = self._event_cursor_index_key(stored.session_id)
        cursor = self.session_activity_versions.get(stored.session_id, 0)
        xadd_started_at_ms = int(time.time() * 1000)
        xadd_started = time.perf_counter()
        stream_id = self._redis.xadd(
            stream_key,
            {"cursor": str(cursor), "event": json.dumps(asdict(stored), ensure_ascii=True)},
            maxlen=self._event_retention,
            approximate=True,
        )
        xadd_completed_at_ms = int(time.time() * 1000)
        xadd_ms = max(0, int((time.perf_counter() - xadd_started) * 1000))
        self._ensure_event_diagnostics()
        with self._event_diagnostic_lock:
            self._event_diagnostics["xaddCount"] += 1
            self._event_diagnostics["xaddLatestMs"] = xadd_ms
            self._event_diagnostics["xaddMaxMs"] = max(self._event_diagnostics["xaddMaxMs"], xadd_ms)
        pipeline = self._redis.pipeline()
        pipeline.zadd(cursor_index_key, {stream_id: cursor})
        pipeline.hset(
            self._latest_event_key(stored.session_id),
            stored.kind,
            json.dumps(asdict(stored), ensure_ascii=True),
        )
        pipeline.zremrangebyrank(cursor_index_key, 0, -(self._event_retention + 1))
        pipeline.hset(self._activity_key, stored.session_id, cursor)
        pipeline.expire(cursor_index_key, self._runtime_ttl_seconds)
        pipeline.expire(self._latest_event_key(stored.session_id), self._runtime_ttl_seconds)
        pipeline.expire(stream_key, self._runtime_ttl_seconds)
        pipeline.expire(self._activity_key, self._runtime_ttl_seconds)
        pipeline.execute()
        self._record_storage_diagnostic("entityWriteCount")
        performance = stored.payload.get("performance")
        if not isinstance(performance, dict):
            return stored
        return replace(
            stored,
            payload={
                **stored.payload,
                "performance": {
                    **performance,
                    "redisEventXaddStartAtMs": xadd_started_at_ms,
                    "redisEventXaddCompleteAtMs": xadd_completed_at_ms,
                    "redisEventXaddAtMs": xadd_completed_at_ms,
                    "redisEventXaddDurationMs": xadd_ms,
                },
            },
        )

    def _save_cn_event(self, event):
        started_at = int(time.time() * 1000)
        started = time.perf_counter()
        stored = self._cn_saved("event", event)
        if stored is event:
            return replace(event)
        ended_at = int(time.time() * 1000)
        elapsed = max(0, int((time.perf_counter() - started) * 1000))
        self._ensure_event_diagnostics()
        with self._event_diagnostic_lock:
            self._event_diagnostics["xaddCount"] += 1
            self._event_diagnostics["xaddLatestMs"] = elapsed
            self._event_diagnostics["xaddMaxMs"] = max(self._event_diagnostics["xaddMaxMs"], elapsed)
        performance = stored.payload.get("performance")
        if not isinstance(performance, dict): return stored
        return replace(stored, payload={**stored.payload, "performance": {
            **performance, "redisEventXaddStartAtMs": started_at, "redisEventXaddCompleteAtMs": ended_at,
            "redisEventXaddAtMs": ended_at, "redisEventXaddDurationMs": elapsed,
        }})

    @staticmethod
    def _event_cursor_index_key(session_id: str) -> str:
        return f"offersteady:realtime:event-cursors:{session_id}"

    @staticmethod
    def _latest_event_key(session_id: str) -> str:
        return f"offersteady:realtime:latest-events:{session_id}"

    @staticmethod
    def _decode_event_rows(rows) -> list[tuple[int, RealtimeEvent]]:
        decoded: list[tuple[int, RealtimeEvent]] = []
        for _stream_id, fields in rows:
            raw = fields.get("event")
            if not raw:
                continue
            decoded.append((int(fields.get("cursor", "0")), RealtimeEvent(**json.loads(raw))))
        return decoded

    @staticmethod
    def _mark_events_read(
        events: list[RealtimeEvent], *, read_at_ms: int, mode: str
    ) -> list[RealtimeEvent]:
        enriched: list[RealtimeEvent] = []
        for event in events:
            performance = event.payload.get("performance")
            if not isinstance(performance, dict):
                enriched.append(event)
                continue
            enriched.append(replace(
                event,
                payload={
                    **event.payload,
                    "performance": {
                        **performance,
                        "redisEventXreadAtMs": read_at_ms,
                        "redisReadMode": mode,
                    },
                },
            ))
        return enriched

    def _record_stream_read(
        self,
        *,
        stream_key: str,
        events: list[RealtimeEvent],
        read_ms: int,
        elapsed_ms: int,
        mode: str,
    ) -> None:
        latest_lag_ms = max(
            (max(0, read_ms - event.created_at_ms) for event in events),
            default=0,
        )
        xlen = getattr(self._redis, "xlen", None)
        stream_length = int(xlen(stream_key)) if callable(xlen) else -1
        self._ensure_event_diagnostics()
        with self._event_diagnostic_lock:
            if mode == "xread":
                self._event_diagnostics["xreadCount"] += 1
                self._event_diagnostics["xreadLatestMs"] = elapsed_ms
                self._event_diagnostics["xreadMaxMs"] = max(self._event_diagnostics["xreadMaxMs"], elapsed_ms)
            self._event_diagnostics["eventLatestLagMs"] = latest_lag_ms
            self._event_diagnostics["streamLength"] = stream_length
            # XREAD is deliberately used without a consumer group. XPENDING is
            # therefore not applicable and must not be reported as hidden work.
            self._event_diagnostics["pendingEvents"] = 0
            self._event_diagnostics["pendingApplicable"] = False
            self._event_diagnostics["consumerMode"] = "xread-no-group"

    def _index_event_rows(self, *, session_id: str, rows) -> None:
        mapping = {
            stream_id: int(fields.get("cursor", "0"))
            for stream_id, fields in rows
            if int(fields.get("cursor", "0")) > 0
        }
        if not mapping:
            return
        cursor_index_key = self._event_cursor_index_key(session_id)
        pipeline = self._redis.pipeline()
        pipeline.zadd(cursor_index_key, mapping)
        pipeline.zremrangebyrank(cursor_index_key, 0, -(self._event_retention + 1))
        pipeline.expire(cursor_index_key, self._runtime_ttl_seconds)
        pipeline.execute()

    def _stream_id_at_or_before_cursor(self, *, session_id: str, cursor: int) -> str | None:
        values = self._redis.zrevrangebyscore(
            self._event_cursor_index_key(session_id),
            cursor,
            "-inf",
            start=0,
            num=1,
        )
        return str(values[0]) if values else None

    def _legacy_stream_id_at_or_before_cursor(self, *, session_id: str, cursor: int) -> str | None:
        rows = self._redis.xrange(f"offersteady:realtime:events:{session_id}")
        self._index_event_rows(session_id=session_id, rows=rows)
        matching = [
            stream_id
            for stream_id, fields in rows
            if int(fields.get("cursor", "0")) <= cursor
        ]
        return str(matching[-1]) if matching else None

    def _stream_bounds(self, *, session_id: str) -> tuple[int | None, int]:
        stream_key = f"offersteady:realtime:events:{session_id}"
        first_rows = self._redis.xrange(stream_key, count=1)
        current_cursor = self.get_event_stream_version(session_id=session_id)
        if not first_rows:
            return None, current_cursor
        return int(first_rows[0][1].get("cursor", "0")), current_cursor

    def list_events_for_session(self, *, session_id):
        return [
            event for _cursor, event in self._decode_event_rows(
                self._redis.xrange(f"offersteady:realtime:events:{session_id}")
            )
        ]

    def list_latest_events_for_session(self, *, session_id: str, kinds: set[str]):
        if not kinds:
            return []
        ordered_kinds = sorted(kinds)
        cache_key = self._latest_event_key(session_id)
        raw_values = self._redis.hmget(cache_key, ordered_kinds)
        cached = dict(zip(ordered_kinds, raw_values, strict=True))
        latest = {
            kind: RealtimeEvent(**json.loads(raw))
            for kind, raw in cached.items()
            if raw is not None and raw != "null"
        }
        missing = {kind for kind, raw in cached.items() if raw is None}
        if missing:
            for item in reversed(self.list_events_for_session(session_id=session_id)):
                if item.kind in missing:
                    latest[item.kind] = item
                    missing.remove(item.kind)
                    if not missing:
                        break
            pipeline = self._redis.pipeline()
            for kind in kinds:
                item = latest.get(kind)
                pipeline.hset(
                    cache_key,
                    kind,
                    json.dumps(asdict(item), ensure_ascii=True) if item is not None else "null",
                )
            pipeline.expire(cache_key, self._runtime_ttl_seconds)
            pipeline.execute()
        return [latest[kind] for kind in ordered_kinds if kind in latest]

    def list_events_after(self, *, session_id: str, cursor: int) -> tuple[int, list[RealtimeEvent], bool]:
        stream_key = f"offersteady:realtime:events:{session_id}"
        first_cursor, current_cursor = self._stream_bounds(session_id=session_id)
        if first_cursor is None:
            return current_cursor, [], True
        resumable = cursor <= 0 or cursor >= first_cursor - 1
        if not resumable:
            return current_cursor, [], False
        if cursor <= 0:
            rows = self._redis.xrange(stream_key, count=self._event_retention)
        else:
            start_id = self._stream_id_at_or_before_cursor(session_id=session_id, cursor=cursor)
            if start_id is None:
                start_id = self._legacy_stream_id_at_or_before_cursor(session_id=session_id, cursor=cursor)
            rows = self._redis.xrange(
                stream_key,
                min=f"({start_id}" if start_id else "-",
                count=self._event_retention,
            )
        read_at_ms = int(time.time() * 1000)
        retained = self._decode_event_rows(rows)
        events = [item for item_cursor, item in retained if item_cursor > cursor]
        if events:
            self._record_stream_read(
                stream_key=stream_key,
                events=events,
                read_ms=read_at_ms,
                elapsed_ms=0,
                mode="xrange",
            )
        return current_cursor, self._mark_events_read(events, read_at_ms=read_at_ms, mode="xrange"), True

    def wait_for_events_after(
        self, *, session_id: str, cursor: int, timeout_ms: int
    ) -> tuple[int, list[RealtimeEvent], bool]:
        immediate = self.list_events_after(session_id=session_id, cursor=cursor)
        if immediate[1] or not immediate[2] or timeout_ms <= 0:
            return immediate
        stream_key = f"offersteady:realtime:events:{session_id}"
        start_id = self._stream_id_at_or_before_cursor(session_id=session_id, cursor=cursor)
        if start_id is None:
            start_id = self._legacy_stream_id_at_or_before_cursor(session_id=session_id, cursor=cursor) or "0-0"
        xread_started = time.perf_counter()
        streams = self._redis.xread(
            {stream_key: start_id},
            count=self._event_retention,
            block=max(1, timeout_ms),
        )
        xread_ms = max(0, int((time.perf_counter() - xread_started) * 1000))
        rows = streams[0][1] if streams else []
        read_at_ms = int(time.time() * 1000)
        retained = self._decode_event_rows(rows)
        events = [item for item_cursor, item in retained if item_cursor > cursor]
        self._record_stream_read(
            stream_key=stream_key,
            events=events,
            read_ms=read_at_ms,
            elapsed_ms=xread_ms,
            mode="xread",
        )
        current_cursor = max(
            self.get_event_stream_version(session_id=session_id),
            max((item_cursor for item_cursor, _event in retained), default=cursor),
        )
        return current_cursor, self._mark_events_read(events, read_at_ms=read_at_ms, mode="xread"), True

    def operational_diagnostics(self) -> dict[str, object]:
        self._ensure_event_diagnostics()
        with self._event_diagnostic_lock:
            return dict(self._event_diagnostics)

    def get_session_activity_version(self, *, session_id):
        activity_version = int(self._redis.hget(self._activity_key, session_id) or 0)
        items = self._redis.xrevrange(f"offersteady:realtime:events:{session_id}", count=1)
        event_version = int(items[0][1].get("cursor", "0")) if items else 0
        return max(activity_version, event_version)

    def get_event_stream_version(self, *, session_id: str) -> int:
        return self.get_session_activity_version(session_id=session_id)

    def readiness(self) -> bool:
        return bool(self._redis.ping())
