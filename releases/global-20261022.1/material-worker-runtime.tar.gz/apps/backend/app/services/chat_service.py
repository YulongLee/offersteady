from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import threading
from concurrent.futures import Future, ThreadPoolExecutor
from collections.abc import Iterator
from dataclasses import replace
from json import JSONDecodeError
from pathlib import Path
from time import time
from uuid import uuid4

import httpx

from app.core.config import Settings
from app.core.errors import DomainRequestError
from app.core.logging import log_event
from app.ports.chat import (
    ChatAnswerChunk,
    ChatAnswerTaskRecord,
    ChatRepository,
    GatewayAnswerResult,
    LLMGatewayPort,
    MaterialContextAssembly,
    MaterialContextSource,
    PromptBuildResult,
    PromptBuilderPort,
    PromptConfig,
    PromptTemplatePort,
    UsageReport,
)
from app.ports.retrieval import RetrievalContext, RetrievalFilter, RetrievalPort
from app.ports.interview_session import InterviewLanguage
from app.ports.commercial_hardening import AiUsageRecord, CommercialHardeningRepository
from app.ports.storage import FileStoragePort
from app.schemas.retrieval import RetrievalResponse, RetrievedChunkResponse
from app.services.session_service import SessionService
from app.services.programming_prompt import append_programming_policy, carry_programming_policy
from app.services.billing_service import BillingService
from app.interview_languages import get_interview_language, interview_prompt_assets_ready, interview_prompt_directory, output_language_violation


def _now_ms() -> int:
    return int(time() * 1000)


_NORMALIZED_QUESTION_OPEN = "<normalized_question>"
_NORMALIZED_QUESTION_CLOSE = "</normalized_question>"
_NORMALIZATION_BUFFER_LIMIT = 800
_DETAIL_RETRIEVAL_EXECUTOR = ThreadPoolExecutor(max_workers=4, thread_name_prefix="chat-detail-retrieval")
_HAN_SCRIPT_PATTERN = re.compile(r"[\u3400-\u4dbf\u4e00-\u9fff]")
_LATIN_SCRIPT_PATTERN = re.compile(r"[A-Za-z]")
_ENGLISH_REPAIR_DIRECTIVE = (
    "ENGLISH-ONLY REPAIR: The previous provider attempt used the wrong output language. "
    "Regenerate the requested content in English only. Chinese or mixed-language input is evidence, "
    "not the output language. Do not mention this repair instruction."
)
_COMMERCIAL_ANSWER_CONTRACT = (
    "<commercial_answer_contract>"
    "Speak concisely and professionally: conclusion first, then evidence, method, and result. "
    "Use only verifiable facts from the supplied resume, job description, knowledge base, or screenshot; "
    "label inference and uncertainty, never fabricate experience or metrics, follow the selected programming-language constraints, "
    "and present every generated answer as AI advice for the candidate to review."
    "</commercial_answer_contract>"
)


def _language_repair_directive(interview_language: InterviewLanguage) -> str:
    if interview_language == "en-US":
        return _ENGLISH_REPAIR_DIRECTIVE
    definition = get_interview_language(interview_language)
    language = definition.output_language if definition else "the selected session language"
    return (
        f"LANGUAGE REPAIR: The previous provider attempt used the wrong output language. "
        f"Regenerate the requested content in {language} only. Preserve facts and structure, "
        "do not translate source evidence unless needed for the answer, and do not mention this repair instruction."
    )


def _clean_question_text(value: str) -> str:
    return " ".join(value.replace("\x00", " ").split()).strip(" `\"'")


def _resolve_normalized_question(payload: str, fallback_question: str) -> tuple[str, str, str]:
    fallback = _clean_question_text(fallback_question)
    start = payload.find(_NORMALIZED_QUESTION_OPEN)
    end = payload.find(_NORMALIZED_QUESTION_CLOSE)
    if start < 0 or end < start:
        visible = payload.replace(_NORMALIZED_QUESTION_OPEN, "").replace(_NORMALIZED_QUESTION_CLOSE, "").lstrip()
        return fallback, visible, "fallback"
    candidate = _clean_question_text(payload[start + len(_NORMALIZED_QUESTION_OPEN):end])
    visible = payload[end + len(_NORMALIZED_QUESTION_CLOSE):].lstrip()
    if not candidate or len(candidate) > 500:
        return fallback, visible, "fallback"
    return candidate, visible, "completed"


def _english_output_violation(value: str) -> bool:
    """Reject materially Chinese prose while allowing a small verified proper noun."""
    han_count = len(_HAN_SCRIPT_PATTERN.findall(value))
    if han_count < 4:
        return False
    latin_count = len(_LATIN_SCRIPT_PATTERN.findall(value))
    return han_count / max(1, han_count + latin_count) >= 0.08


def _english_repair_prompt(prompt: PromptBuildResult, interview_language: InterviewLanguage = "en-US") -> PromptBuildResult:
    directive = _language_repair_directive(interview_language)
    definition = get_interview_language(interview_language)
    label = definition.output_language if definition else "the selected session language"
    system_prompt = f"{prompt.system_prompt}\n\n{directive}"
    user_prompt = f"<output_language_repair>{label} only</output_language_repair>\n\n{prompt.user_prompt}"
    return replace(
        prompt,
        system_prompt=system_prompt,
        user_prompt=user_prompt,
        rendered_prompt=f"{system_prompt}\n\n{user_prompt}",
    )


def _english_repair_instruction(instruction: str, interview_language: InterviewLanguage = "en-US") -> str:
    return f"{instruction}\n\n{_language_repair_directive(interview_language)}"


class RetryableChatError(Exception):
    def __init__(self, message: str, *, code: str = "chat_provider_unavailable") -> None:
        self.code = code
        super().__init__(message)


class NonRetryableChatError(Exception):
    def __init__(
        self,
        message: str,
        *,
        code: str = "chat_provider_invalid_response",
        partial_suffix: str = "",
    ) -> None:
        self.code = code
        self.partial_suffix = partial_suffix
        super().__init__(message)


class ChatTaskCancelled(Exception):
    pass


class FilePromptTemplateAdapter(PromptTemplatePort):
    def __init__(self, settings: Settings) -> None:
        self.settings = settings

    def load_system_prompt(self, interview_language: InterviewLanguage = "zh-CN") -> tuple[str, PromptConfig]:
        prompt_path = Path(self.settings.chat_prompt_template_path)
        if not prompt_path.is_absolute():
            prompt_path = Path(__file__).resolve().parents[4] / self.settings.chat_prompt_template_path
        default_path = Path(__file__).resolve().parents[4] / "ai/prompts/chat-service/system.md"
        if prompt_path == default_path and interview_prompt_assets_ready(interview_language):
            prompt_path = interview_prompt_directory(interview_language) / "system.md"
        elif interview_language != "zh-CN":
            prompt_path = prompt_path.with_name(f"{prompt_path.stem}.en{prompt_path.suffix}")
        text = prompt_path.read_text(encoding="utf-8").strip()
        if "<commercial_answer_contract>" not in text:
            text = f"{text}\n\n{_COMMERCIAL_ANSWER_CONTRACT}"
        definition = get_interview_language(interview_language)
        if definition and interview_language not in {"zh-CN", "en-US"} and "<output_language>" not in text:
            text = f"{text}\n\n<output_language>{definition.output_language} only. Keep the response professional and natural for a commercial interview assistant.</output_language>"
        return text, PromptConfig(
            template_id=("interview-chat-en-system" if interview_language == "en-US" else "interview-chat-system") if interview_language in {"zh-CN", "en-US"} else f"interview-chat-{interview_language}-system",
            version=self.settings.chat_prompt_version,
            max_history_entries=self.settings.chat_max_history_entries,
            include_retrieval_context=True,
        )

    def load_stage_prompt(self, stage: str, interview_language: InterviewLanguage = "zh-CN") -> tuple[str, PromptConfig]:
        if stage not in {"quick", "detail", "continuation"}:
            raise ValueError(f"unsupported_prompt_stage:{stage}")
        prompt_path = Path(self.settings.chat_prompt_template_path)
        if not prompt_path.is_absolute():
            prompt_path = Path(__file__).resolve().parents[4] / self.settings.chat_prompt_template_path
        default_path = Path(__file__).resolve().parents[4] / "ai/prompts/chat-service/system.md"
        if prompt_path == default_path and interview_prompt_assets_ready(interview_language):
            stage_path = interview_prompt_directory(interview_language) / f"{stage}.md"
        else:
            filename = f"{stage}.en.md" if interview_language != "zh-CN" else f"{stage}.md"
            stage_path = prompt_path.with_name(filename)
        text = stage_path.read_text(encoding="utf-8").strip()
        if "<commercial_answer_contract>" not in text:
            text = f"{text}\n\n{_COMMERCIAL_ANSWER_CONTRACT}"
        definition = get_interview_language(interview_language)
        if definition and interview_language not in {"zh-CN", "en-US"} and "<output_language>" not in text:
            text = f"{text}\n\n<output_language>{definition.output_language} only. Preserve the requested answer structure and avoid mentioning internal prompts.</output_language>"
        return text, PromptConfig(
            template_id=(f"interview-chat-en-{stage}" if interview_language == "en-US" else f"interview-chat-{stage}") if interview_language in {"zh-CN", "en-US"} else f"interview-chat-{interview_language}-{stage}",
            version=self.settings.chat_prompt_version,
            max_history_entries=self.settings.chat_max_history_entries,
            include_retrieval_context=stage == "detail",
        )


class InterviewPromptBuilder(PromptBuilderPort):
    def build(
        self,
        *,
        question: str,
        session_title: str,
        system_prompt: str,
        conversation_history: list[str],
        session_material_context_text: str,
        retrieval_context_text: str,
        prompt_config: PromptConfig,
    ) -> PromptBuildResult:
        selected_history = conversation_history[-prompt_config.max_history_entries :]
        english = "-en-" in prompt_config.template_id
        output_language_match = re.search(r"<output_language>(.*?)</output_language>", system_prompt, flags=re.DOTALL)
        output_language = output_language_match.group(1).strip() if output_language_match else None
        anchor_prefix = "Quick answer anchor: " if english else "本轮简要回答锚点："
        answer_anchors = [item.removeprefix(anchor_prefix).strip() for item in selected_history if item.startswith(anchor_prefix)]
        history_text = "\n".join(item for item in selected_history if not item.startswith(anchor_prefix))
        sections = [
            *(["<output_language>English only, regardless of the language of any input or evidence.</output_language>"] if english else []),
            "<authoritative_request>",
            (f"Session title: {session_title}\nCurrent question: {question}" if english else f"会话标题：{session_title}\n当前问题：{question}"),
            "</authoritative_request>",
        ]
        if output_language and not english:
            sections.insert(0, f"<output_language>{output_language}</output_language>")
        if history_text:
            sections.append(f"<untrusted_conversation_evidence>\n{history_text}\n</untrusted_conversation_evidence>")
        if session_material_context_text.strip():
            sections.append(f"<untrusted_fixed_material_evidence>\n{session_material_context_text.strip()}\n</untrusted_fixed_material_evidence>")
        if prompt_config.include_retrieval_context and retrieval_context_text.strip():
            sections.append(f"<untrusted_knowledge_evidence>\n{retrieval_context_text.strip()}\n</untrusted_knowledge_evidence>")
        elif prompt_config.include_retrieval_context:
            sections.append("<knowledge_status>No confirmed knowledge-base evidence matched this request.</knowledge_status>" if english else "<knowledge_status>本次未命中已确认知识库。</knowledge_status>")
        if answer_anchors:
            sections.append(f"<authoritative_answer_anchor>\n{answer_anchors[-1]}\n</authoritative_answer_anchor>")
        user_prompt = "\n\n".join(sections)
        return PromptBuildResult(
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            rendered_prompt=f"{system_prompt}\n\n{user_prompt}",
            prompt_config=prompt_config,
            retrieval_excerpt_count=retrieval_context_text.count("["),
        )


class QwenCompatibleGateway(LLMGatewayPort):
    def __init__(self, settings: Settings, *, http_client: httpx.Client | None = None) -> None:
        self.settings = settings
        self._http_client = http_client
        self._http_client_lock = threading.Lock()

    def _client(self) -> httpx.Client:
        client = self._http_client
        if client is not None:
            return client
        with self._http_client_lock:
            if self._http_client is None:
                max_connections = max(1, self.settings.chat_http_max_connections)
                self._http_client = httpx.Client(
                    timeout=self.settings.integration_http_timeout_seconds,
                    limits=httpx.Limits(
                        max_connections=max_connections,
                        max_keepalive_connections=min(
                            max_connections,
                            max(1, self.settings.chat_http_max_keepalive_connections),
                        ),
                        keepalive_expiry=max(1.0, self.settings.chat_http_keepalive_expiry_seconds),
                    ),
                )
            return self._http_client

    def close(self) -> None:
        with self._http_client_lock:
            client = self._http_client
            self._http_client = None
        if client is not None:
            client.close()

    def generate(
        self,
        *,
        question: str,
        prompt: PromptBuildResult,
        stream: bool,
        attempt: int,
    ) -> GatewayAnswerResult:
        lowered = question.lower()
        if "__permanent_fail__" in lowered:
            raise NonRetryableChatError("forced_permanent_failure", code="forced_permanent_failure")
        if "__retry_once__" in lowered and attempt == 0:
            raise RetryableChatError("forced_retryable_failure", code="forced_retryable_failure")
        if self._should_use_remote_gateway():
            return self._generate_with_remote(question=question, prompt=prompt, stream=stream)
        answer = self._compose_answer(question=question, prompt=prompt)
        chunk_size = max(8, self.settings.chat_stream_chunk_chars)
        chunks = [
            ChatAnswerChunk(sequence=index + 1, text=answer[start:start + chunk_size], is_final=False)
            for index, start in enumerate(range(0, len(answer), chunk_size))
        ]
        if chunks:
            last = chunks[-1]
            chunks[-1] = ChatAnswerChunk(sequence=last.sequence, text=last.text, is_final=True)
        usage = UsageReport(
            prompt_tokens=max(1, len(prompt.rendered_prompt) // 4),
            completion_tokens=max(1, len(answer) // 4),
            total_tokens=max(1, len(prompt.rendered_prompt) // 4) + max(1, len(answer) // 4),
            provider_name="qwen-compatible",
            model_name=self.settings.chat_qwen_model,
        )
        return GatewayAnswerResult(
            provider_name="qwen-compatible",
            model_name=self.settings.chat_qwen_model,
            chunks=chunks if stream else [ChatAnswerChunk(sequence=1, text=answer, is_final=True)],
            final_text=answer,
            finish_reason="completed",
            usage=usage,
        )

    def stream_generate(
        self,
        *,
        question: str,
        prompt: PromptBuildResult,
        attempt: int,
    ) -> Iterator[ChatAnswerChunk]:
        lowered = question.lower()
        if "__permanent_fail__" in lowered:
            raise NonRetryableChatError("forced_permanent_failure", code="forced_permanent_failure")
        if "__retry_once__" in lowered and attempt == 0:
            raise RetryableChatError("forced_retryable_failure", code="forced_retryable_failure")
        if "__stream_fail_after_chunk__" in lowered:
            normalized_question = _clean_question_text(question.replace("__stream_fail_after_chunk__", ""))
            yield ChatAnswerChunk(
                sequence=1,
                text=(
                    f"{_NORMALIZED_QUESTION_OPEN}{normalized_question}{_NORMALIZED_QUESTION_CLOSE}\n"
                    "这是已经生成的部分回答。"
                ),
                is_final=False,
            )
            raise RetryableChatError("forced_stream_failure", code="forced_stream_failure")
        if self._should_use_remote_gateway():
            yield from self._stream_with_remote(prompt=prompt)
            return
        answer = self._compose_answer(question=question, prompt=prompt)
        chunks = self._chunk_answer(answer)
        for chunk in chunks:
            yield chunk

    def _should_use_remote_gateway(self) -> bool:
        if os.environ.get("PYTEST_CURRENT_TEST") and os.environ.get("OFFERSTEADY_TEST_USE_REMOTE_CHAT") != "1":
            return False
        return True

    def _generate_with_remote(self, *, question: str, prompt: PromptBuildResult, stream: bool) -> GatewayAnswerResult:
        if not self.settings.chat_qwen_base_url or not self.settings.chat_qwen_api_key:
            raise NonRetryableChatError("当前对话模型未配置完成，请检查服务端 .env 配置。", code="chat_config_missing")
        body = self._request_completion(prompt=prompt)
        answer = self._extract_answer_text(body)
        if not answer:
            raise NonRetryableChatError("当前对话模型返回了无效结果，请稍后重试或检查模型配置。", code="chat_provider_invalid_response")
        usage_payload = body.get("usage", {}) if isinstance(body, dict) else {}
        usage = UsageReport(
            prompt_tokens=max(1, int(usage_payload.get("prompt_tokens", 0) or max(1, len(prompt.rendered_prompt) // 4))),
            completion_tokens=max(1, int(usage_payload.get("completion_tokens", 0) or max(1, len(answer) // 4))),
            total_tokens=max(1, int(usage_payload.get("total_tokens", 0) or (max(1, len(prompt.rendered_prompt) // 4) + max(1, len(answer) // 4)))),
            provider_name="qwen-compatible",
            model_name=self.settings.chat_qwen_model,
        )
        return GatewayAnswerResult(
            provider_name="qwen-compatible",
            model_name=self.settings.chat_qwen_model,
            chunks=self._chunk_answer(answer) if stream else [ChatAnswerChunk(sequence=1, text=answer, is_final=True)],
            final_text=answer,
            finish_reason="completed",
            usage=usage,
        )

    def _request_completion(self, *, prompt: PromptBuildResult) -> dict:
        response = self._post_completion(prompt=prompt, stream=False)
        try:
            body = response.json()
        except JSONDecodeError as exc:
            raise NonRetryableChatError("当前对话模型返回了无法解析的结果。", code="chat_provider_invalid_response") from exc
        if not isinstance(body, dict):
            raise NonRetryableChatError("当前对话模型返回了无效结果。", code="chat_provider_invalid_response")
        return body

    def _post_completion(self, *, prompt: PromptBuildResult, stream: bool) -> httpx.Response:
        base_url = self.settings.chat_qwen_base_url.rstrip("/")
        url = f"{base_url}/chat/completions"
        payload = {
            "model": self.settings.chat_qwen_model,
            "stream": stream,
            "temperature": 0.2,
            "max_tokens": self._max_tokens_for_prompt(prompt),
            "enable_thinking": False,
            "messages": [
                {"role": "system", "content": prompt.system_prompt},
                {"role": "user", "content": prompt.user_prompt},
            ],
        }
        started_at = _now_ms()
        try:
            response = self._client().post(url, headers={"Authorization": f"Bearer {self.settings.chat_qwen_api_key}"}, json=payload)
        except httpx.HTTPError as exc:
            raise RetryableChatError("当前对话模型暂时不可用，请稍后重试。", code="chat_provider_unavailable") from exc
        finally:
            log_event(
                logging.getLogger(__name__),
                logging.INFO,
                settings=self.settings,
                event="chat.provider_request_finished",
                feature="live-answer",
                action="provider-request",
                duration_ms=_now_ms() - started_at,
                stream=stream,
                model=self.settings.chat_qwen_model,
            )
        self._raise_for_provider_status(response.status_code)
        return response

    def _raise_for_provider_status(self, status_code: int) -> None:
        if status_code in {401, 403}:
            raise NonRetryableChatError("当前对话模型鉴权失败，请检查服务配置。", code="chat_provider_auth_failed")
        if status_code == 429:
            raise RetryableChatError("当前对话模型请求过多，请稍后重试。", code="chat_provider_rate_limited")
        if status_code >= 500:
            raise RetryableChatError("当前对话模型暂时不可用，请稍后重试。", code="chat_provider_unavailable")
        if status_code >= 400:
            raise NonRetryableChatError("当前对话模型请求未通过，请检查会话或模型配置。", code="chat_provider_request_rejected")

    def _stream_with_remote(self, *, prompt: PromptBuildResult) -> Iterator[ChatAnswerChunk]:
        if not self.settings.chat_qwen_base_url or not self.settings.chat_qwen_api_key:
            raise NonRetryableChatError("当前对话模型未配置完成，请检查服务端 .env 配置。", code="chat_config_missing")
        base_url = self.settings.chat_qwen_base_url.rstrip("/")
        url = f"{base_url}/chat/completions"
        payload = {
            "model": self.settings.chat_qwen_model,
            "stream": True,
            "temperature": 0.2,
            "max_tokens": self._max_tokens_for_prompt(prompt),
            "enable_thinking": False,
            "messages": [
                {"role": "system", "content": prompt.system_prompt},
                {"role": "user", "content": prompt.user_prompt},
            ],
        }
        sequence = 0
        started_at = _now_ms()
        try:
            with self._client().stream("POST", url, headers={"Authorization": f"Bearer {self.settings.chat_qwen_api_key}"}, json=payload) as response:
                self._raise_for_provider_status(response.status_code)
                for line in response.iter_lines():
                    text, finish_reason = self._extract_stream_line(line)
                    if not text and finish_reason is None:
                        continue
                    sequence += 1
                    yield ChatAnswerChunk(
                        sequence=sequence,
                        text=text,
                        is_final=finish_reason is not None,
                        provider_finish_reason=finish_reason,
                    )
        except httpx.HTTPError as exc:
            raise RetryableChatError("当前对话模型暂时不可用，请稍后重试。", code="chat_provider_unavailable") from exc
        finally:
            log_event(
                logging.getLogger(__name__),
                logging.INFO,
                settings=self.settings,
                event="chat.provider_stream_finished",
                feature="live-answer",
                action="provider-stream",
                duration_ms=_now_ms() - started_at,
                model=self.settings.chat_qwen_model,
                chunk_count=sequence,
            )

    def _max_tokens_for_prompt(self, prompt: PromptBuildResult) -> int:
        template_id = prompt.prompt_config.template_id
        if "continuation" in template_id:
            return max(128, self.settings.chat_continuation_max_tokens)
        if template_id.endswith("-quick"):
            return max(128, self.settings.chat_quick_max_tokens)
        if template_id.endswith("-detail"):
            return max(256, self.settings.chat_detail_max_tokens)
        return max(256, self.settings.chat_detail_max_tokens)

    @staticmethod
    def _normalize_provider_finish_reason(value: object) -> str | None:
        if value is None:
            return None
        normalized = str(value).strip().lower().replace("_", "-")
        if normalized in {"stop", "length", "content-filter", "tool-calls"}:
            return normalized
        return "unknown"

    def _extract_stream_line(self, line: str) -> tuple[str, str | None]:
        if not line:
            return "", None
        payload = line.strip()
        if not payload:
            return "", None
        if payload.startswith("data:"):
            payload = payload[5:].strip()
        if payload == "[DONE]":
            return "", None
        try:
            body = json.loads(payload)
        except JSONDecodeError:
            return "", None
        choices = body.get("choices")
        if not isinstance(choices, list) or not choices:
            return "", None
        choice = choices[0] if isinstance(choices[0], dict) else {}
        finish_reason = self._normalize_provider_finish_reason(choice.get("finish_reason"))
        delta = choice.get("delta") or choice.get("message") or {}
        content = delta.get("content")
        if isinstance(content, str):
            return content, finish_reason
        if isinstance(content, list):
            return "".join(item.get("text", "") for item in content if isinstance(item, dict)), finish_reason
        return "", finish_reason

    def _extract_stream_line_text(self, line: str) -> str:
        text, _finish_reason = self._extract_stream_line(line)
        return text

    def _extract_answer_text(self, body: dict) -> str:
        choices = body.get("choices")
        if isinstance(choices, list) and choices:
            message = choices[0].get("message", {})
            content = message.get("content")
            if isinstance(content, str):
                return content.strip()
            if isinstance(content, list):
                text_parts = [item.get("text", "") for item in content if isinstance(item, dict) and item.get("type") in {None, "text"}]
                return "".join(part for part in text_parts if part).strip()
        return ""

    def _chunk_answer(self, answer: str) -> list[ChatAnswerChunk]:
        chunk_size = max(8, self.settings.chat_stream_chunk_chars)
        chunks = [
            ChatAnswerChunk(sequence=index + 1, text=answer[start:start + chunk_size], is_final=False)
            for index, start in enumerate(range(0, len(answer), chunk_size))
        ]
        if chunks:
            last = chunks[-1]
            chunks[-1] = ChatAnswerChunk(sequence=last.sequence, text=last.text, is_final=True)
        return chunks or [ChatAnswerChunk(sequence=1, text=answer, is_final=True)]

    def _compose_answer(self, *, question: str, prompt: PromptBuildResult) -> str:
        english = "-en-" in prompt.prompt_config.template_id
        if prompt.prompt_config.template_id.endswith("-quick"):
            return (
                f"{_NORMALIZED_QUESTION_OPEN}{_clean_question_text(question)}"
                f"{_NORMALIZED_QUESTION_CLOSE}\n"
                + ("I would start with the core conclusion, then support it with one or two concrete reasons and trade-offs." if english else "我会先直接回答核心结论，再用一到两个关键依据说明实现方式和取舍。")
            )
        if english and prompt.prompt_config.template_id.endswith("-detail"):
            return (
                "I would explain the context, my verified responsibility, the key decision and its trade-offs, "
                "followed by the result or lesson learned. If personal evidence is unavailable, I would describe "
                "the approach I would take instead of inventing prior experience, employers, metrics, or outcomes."
            )
        if english:
            evidence_hint = "This answer uses the confirmed evidence available for this interview." if prompt.retrieval_excerpt_count > 0 else "The available personal evidence is limited, so I would keep any experience claims explicit and factual."
            return (
                "Quick Answer\n"
                f"For “{question}”, I would state the conclusion first and support it with the most relevant verified facts. {evidence_hint}\n\n"
                "---\n\n"
                "Detailed Answer\n"
                "I would then explain the context, my verified responsibility, the key decision and its trade-offs, followed by the result or lesson learned. "
                "If no personal evidence is available, I would describe the approach I would take instead of inventing prior experience or metrics."
            )
        evidence_hint = "已结合本场资料和检索依据。" if prompt.retrieval_excerpt_count > 0 else "当前可用资料有限，建议结合你的真实经历补充。"
        return (
            "简要回答\n"
            f"围绕“{question}”，可以先直接给出核心结论，再点出与你真实经历最相关的一两个依据。"
            f"{evidence_hint}\n\n"
            "---\n\n"
            "详细回答\n"
            "我会先说明项目背景和目标，再展开你亲自负责的部分、关键决策和推进过程。"
            "接着补充为什么这样做，以及最后带来了什么结果或复盘收获。"
            "如果暂时没有可量化的数据，就诚实描述可观察到的改善，不要补造公司、项目、职责、结果或数字。"
        )


class ChatService:
    def __init__(
        self,
        *,
        settings: Settings,
        logger: logging.Logger,
        session_service: SessionService,
        retrieval_service: RetrievalPort,
        object_storage: FileStoragePort,
        repository: ChatRepository,
        prompt_template: PromptTemplatePort,
        prompt_builder: PromptBuilderPort,
        llm_gateway: LLMGatewayPort,
        billing_service: BillingService | None = None,
        commercial_repository: CommercialHardeningRepository | None = None,
    ) -> None:
        self.settings = settings
        self.logger = logger
        self.session_service = session_service
        self.retrieval_service = retrieval_service
        self.object_storage = object_storage
        self.repository = repository
        self.prompt_template = prompt_template
        self.prompt_builder = prompt_builder
        self.llm_gateway = llm_gateway
        self.billing_service = billing_service
        self.commercial_repository = commercial_repository
        self.billing_usage_by_task: dict[str, str] = {}
        self._prepared_context_lock = threading.Lock()
        self._prepared_context: dict[tuple[str, str, int], dict[str, object]] = {}
        self._latest_prefetch_revision: dict[tuple[str, str], int] = {}

    def prefetch_question_context(
        self,
        *,
        user_id: str,
        session_id: str,
        question_id: str,
        revision: int,
        question: str,
    ) -> None:
        """Prepare retrieval off the media path; failures fall back on click."""
        try:
            question_key = (session_id, question_id)
            with self._prepared_context_lock:
                latest = self._latest_prefetch_revision.get(question_key, -1)
                if revision < latest:
                    return
                self._latest_prefetch_revision[question_key] = revision
            session = self.session_service.get_session(user_id=user_id, session_id=session_id)
            retrieval = self._retrieve_context(user_id=user_id, session=session, question=question)
            prepared = {
                "question": question.strip(),
                "retrieval": retrieval,
                "createdAtMs": _now_ms(),
            }
            with self._prepared_context_lock:
                if self._latest_prefetch_revision.get(question_key) != revision:
                    return
                for key in tuple(self._prepared_context):
                    if key[:2] == question_key and key[2] < revision:
                        self._prepared_context.pop(key, None)
                self._prepared_context[(session_id, question_id, revision)] = prepared
                if len(self._prepared_context) > 128:
                    oldest = min(self._prepared_context, key=lambda item: int(self._prepared_context[item].get("createdAtMs", 0)))
                    self._prepared_context.pop(oldest, None)
        except Exception as exc:
            self.logger.info("chat.question_prefetch_skipped", extra={"safe_error_code": exc.__class__.__name__})

    def _prepared_retrieval(
        self,
        *,
        session_id: str,
        question_id: str | None,
        revision: int | None,
        question: str,
    ) -> RetrievalContext | None:
        if not question_id or revision is None:
            return None
        with self._prepared_context_lock:
            prepared = self._prepared_context.get((session_id, question_id, revision))
        if not prepared or _now_ms() - int(prepared.get("createdAtMs", 0)) > 60_000:
            return None
        prepared_question = str(prepared.get("question", "")).strip()
        if prepared_question not in question.strip() and question.strip() not in prepared_question:
            return None
        retrieval = prepared.get("retrieval")
        return retrieval if isinstance(retrieval, RetrievalContext) else None

    def _reserve_answer_usage(self, *, user_id: str, usage_id: str) -> None:
        if self.billing_service is None:
            return
        reservation = self.billing_service.reserve_usage(user_id=user_id, usage_id=usage_id, usage_kind="answer")
        if reservation.status == "insufficient_balance":
            raise DomainRequestError("billing", "reserve-answer", "积分不足，请先购买积分或开通会员。", 409)

    def _record_ai_usage(
        self,
        *,
        user_id: str,
        session_id: str,
        task_id: str,
        status: str,
        started_at_ms: int,
        usage: UsageReport | None = None,
        first_token_ms: int | None = None,
        safe_error_code: str | None = None,
    ) -> None:
        if self.commercial_repository is None:
            return
        try:
            self.commercial_repository.record_ai_usage(AiUsageRecord(
                usage_id=f"ai-chat:{task_id}",
                owner_user_id=user_id,
                operation_kind="chat",
                provider=usage.provider_name if usage is not None else "qwen-compatible",
                model=usage.model_name if usage is not None else self.settings.chat_qwen_model,
                status="succeeded" if status == "succeeded" else "failed",
                related_task_id=task_id,
                session_id=session_id,
                input_units=usage.prompt_tokens if usage is not None else None,
                output_units=usage.completion_tokens if usage is not None else None,
                total_units=usage.total_tokens if usage is not None else None,
                duration_ms=max(0, _now_ms() - started_at_ms),
                first_token_ms=first_token_ms,
                safe_error_code=safe_error_code,
                created_at_ms=_now_ms(),
            ))
        except Exception as exc:  # Observability must never break a user answer.
            self.logger.warning("chat.ai_usage_record_failed", extra={"task_id": task_id, "safe_error_code": exc.__class__.__name__})

    def _load_stage_prompt(self, stage: str, interview_language: InterviewLanguage = "zh-CN") -> tuple[str, PromptConfig]:
        loader = getattr(self.prompt_template, "load_stage_prompt", None)
        return loader(stage, interview_language) if callable(loader) else self.prompt_template.load_system_prompt(interview_language)

    def _conversation_history(self, *, user_id: str, session_id: str, question: str, session=None) -> list[str]:
        entries = self.session_service.get_context_window(
            user_id=user_id,
            session_id=session_id,
            limit=self.settings.chat_max_history_entries + 1,
            validated_session=session,
        )
        history = [f"{item.role}:{item.content}" for item in entries]
        if history and history[-1] == f"manual-question:{question.strip()}":
            history.pop()
        return history[-self.settings.chat_max_history_entries :]

    @staticmethod
    def _prompt_metadata(provenance: dict[str, object], *, stages: dict[str, str]) -> dict[str, object]:
        return {**provenance, "promptStrategyMode": "adaptive-evidence-first", "promptStages": stages}

    def _log_language_violation(
        self,
        *,
        session_id: str,
        task_id: str,
        stage: str,
        prompt: PromptBuildResult,
        attempt: int,
        interview_language: InterviewLanguage | None = None,
    ) -> None:
        routed_language = interview_language
        if routed_language is None:
            match = re.search(r"([a-z]{2}-[A-Z]{2})", prompt.prompt_config.template_id)
            routed_language = match.group(1) if match and get_interview_language(match.group(1)) else "en-US"
        log_event(
            self.logger,
            logging.WARNING,
            settings=self.settings,
            event="chat.output_language_violation",
            feature="live-answer",
            action="enforce-output-language",
            session_id=session_id,
            task_id=task_id,
            interview_language=routed_language,
            stage=stage,
            prompt_template_id=prompt.prompt_config.template_id,
            prompt_version=prompt.prompt_config.version,
            provider_attempt=attempt,
            error_code="chat_output_language_violation",
        )

    @staticmethod
    def _size_bucket(length: int) -> str:
        return "xs" if length <= 256 else "sm" if length <= 1000 else "md" if length <= 4000 else "lg"

    @staticmethod
    def _answer_looks_incomplete(text: str, finish_reason: str) -> bool:
        candidate = text.rstrip()
        if not candidate:
            return True
        if finish_reason == "length":
            return True
        if candidate.count("```") % 2:
            return True
        if candidate.endswith(("，", ",", "：", ":", "；", ";", "、", "（", "(", "【", "[", "{", "以及", "并且", "或者")):
            return True
        return re.search(r"(?:^|\n)\s*(?:[-*+] |\d+[.)、]\s*)$", candidate) is not None

    @staticmethod
    def _append_without_overlap(existing: str, continuation: str) -> tuple[str, str]:
        suffix = continuation.lstrip("\ufeff")
        max_overlap = min(len(existing), len(suffix))
        overlap = 0
        for size in range(max_overlap, 0, -1):
            if existing.endswith(suffix[:size]):
                overlap = size
                break
        appended = suffix[overlap:]
        return existing + appended, appended

    def _continuation_prompt(
        self,
        *,
        stage: str,
        original_prompt: PromptBuildResult,
        existing_answer: str,
        interview_language: InterviewLanguage,
    ) -> PromptBuildResult:
        system_prompt, config = self._load_stage_prompt("continuation", interview_language)
        system_prompt = carry_programming_policy(system_prompt, original_prompt.system_prompt)
        user_prompt = (
            f"<original_request>\n{original_prompt.user_prompt}\n</original_request>\n\n"
            f"<answer_stage>{stage}</answer_stage>\n"
            f"<authoritative_existing_answer>\n{existing_answer}\n</authoritative_existing_answer>"
        )
        continuation_config = replace(config, template_id=f"{config.template_id}-{stage}")
        return PromptBuildResult(
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            rendered_prompt=f"{system_prompt}\n\n{user_prompt}",
            prompt_config=continuation_config,
            retrieval_excerpt_count=original_prompt.retrieval_excerpt_count,
        )

    def _complete_answer_stage(
        self,
        *,
        stage: str,
        question: str,
        prompt: PromptBuildResult,
        existing_answer: str,
        finish_reason: str,
        provider_attempt: int,
        task_id: str,
        session_id: str = "unknown",
        interview_language: InterviewLanguage = "zh-CN",
    ) -> tuple[str, int, int]:
        if finish_reason in {"content-filter", "tool-calls", "unknown"}:
            raise NonRetryableChatError(
                "当前回答未能正常完成，请重新发起回答。",
                code="chat_provider_incomplete_response",
            )
        self._log_stage_finish(stage=stage, finish_reason=finish_reason, continuation_attempt=0, text=existing_answer)
        if not self._answer_looks_incomplete(existing_answer, finish_reason):
            return "", 0, 0

        current_text = existing_answer
        appended_parts: list[str] = []
        prompt_characters = 0
        max_attempts = max(0, self.settings.chat_continuation_max_attempts)
        for continuation_attempt in range(1, max_attempts + 1):
            if self._is_task_cancelled(task_id):
                raise ChatTaskCancelled()
            continuation_prompt = self._continuation_prompt(
                stage=stage,
                original_prompt=prompt,
                existing_answer=current_text,
                interview_language=interview_language,
            )
            prompt_characters += len(continuation_prompt.rendered_prompt)
            continuation_parts: list[str] = []
            continuation_finish_reason = "stop"
            for language_attempt in range(2 if interview_language != "zh-CN" else 1):
                active_prompt = (
                    _english_repair_prompt(continuation_prompt, interview_language)
                    if language_attempt > 0
                    else continuation_prompt
                )
                continuation_parts = []
                continuation_finish_reason = "stop"
                for chunk in self.llm_gateway.stream_generate(
                    question=question,
                    prompt=active_prompt,
                    attempt=provider_attempt + language_attempt,
                ):
                    if self._is_task_cancelled(task_id):
                        raise ChatTaskCancelled()
                    if chunk.text:
                        continuation_parts.append(chunk.text)
                    if chunk.provider_finish_reason is not None:
                        continuation_finish_reason = chunk.provider_finish_reason
                if not output_language_violation("".join(continuation_parts), interview_language):
                    break
                self._log_language_violation(
                    session_id=session_id,
                    task_id=task_id,
                    stage=f"{stage}-continuation",
                    prompt=active_prompt,
                    attempt=provider_attempt + language_attempt,
                )
            else:
                raise NonRetryableChatError(
                    "The answer model repeatedly returned the wrong language. Please retry this question.",
                    code="chat_output_language_violation",
                )
            if continuation_finish_reason in {"content-filter", "tool-calls", "unknown"}:
                raise NonRetryableChatError(
                    "当前回答未能正常完成，请重新发起回答。",
                    code="chat_provider_incomplete_response",
                )
            continuation_text = "".join(continuation_parts)
            current_text, appended = self._append_without_overlap(current_text, continuation_text)
            if appended:
                appended_parts.append(appended)
            self._log_stage_finish(
                stage=stage,
                finish_reason=continuation_finish_reason,
                continuation_attempt=continuation_attempt,
                text=current_text,
            )
            if not self._answer_looks_incomplete(current_text, continuation_finish_reason):
                return "".join(appended_parts), continuation_attempt, prompt_characters

        raise NonRetryableChatError(
            "回答尚未生成完整，请重试当前问题。已生成内容会为你保留。",
            code="chat_answer_incomplete",
            partial_suffix="".join(appended_parts),
        )

    def _log_stage_finish(self, *, stage: str, finish_reason: str, continuation_attempt: int, text: str) -> None:
        log_event(
            self.logger,
            logging.INFO,
            settings=self.settings,
            event="chat.answer_stage_finished",
            feature="live-answer",
            action="answer-completeness",
            stage=stage,
            finish_reason=finish_reason,
            continuation_attempt=continuation_attempt,
            answer_size_bucket=self._size_bucket(len(text)),
            model=self.settings.chat_qwen_model,
        )

    def answer_question(
        self, *, user_id: str, session_id: str, question: str, stream: bool, usage_id: str | None = None
    ) -> tuple[ChatAnswerTaskRecord, RetrievalResponse]:
        session = self.session_service.get_session(user_id=user_id, session_id=session_id)
        if session.session_mode == "written":
            raise DomainRequestError("live-answer", "start", "笔试模式仅支持截屏回答。", 409, error_code="written_exam_mode_mismatch")
        if session.status != "live":
            raise DomainRequestError("live-answer", "start", "只有进行中的面试会话才能发起实时回答。", 400)
        self.session_service.touch_activity(user_id=user_id, session_id=session_id, force=True)
        now_ms = _now_ms()
        task_id = f"answer-{uuid4().hex}"
        billing_usage_id = usage_id or f"live-answer:{task_id}"
        self._reserve_answer_usage(user_id=user_id, usage_id=billing_usage_id)
        self.billing_usage_by_task[task_id] = billing_usage_id
        task = self.repository.save_task(
            ChatAnswerTaskRecord(
                task_id=task_id,
                session_id=session_id,
                owner_user_id=user_id,
                question=question.strip(),
                answer_text="",
                status="queued",
                stream_mode=stream,
                created_at_ms=now_ms,
                updated_at_ms=now_ms,
            )
        )
        self._log(logging.INFO, "chat.started", task=task, session_id=session_id, question=question, retry_count=0)
        self.session_service.append_context(
            user_id=user_id,
            session_id=session_id,
            role="manual-question",
            source_kind="manual-input",
            content=question,
            visibility="session",
            related_task_id=task.task_id,
            validated_session=session,
            activity_already_touched=True,
        )
        conversation_history = self._conversation_history(user_id=user_id, session_id=session_id, question=question)
        retrieval = self._retrieve_context(user_id=user_id, session=session, question=question)
        material_context_text, material_assembly, material_provenance = self._assemble_material_context(session=session, retrieval=retrieval)
        system_prompt, prompt_config = self.prompt_template.load_system_prompt(session.interview_language)
        system_prompt = append_programming_policy(system_prompt, session=session)
        history_entries = self.session_service.get_context_window(user_id=user_id, session_id=session_id, limit=self.settings.chat_max_history_entries)
        prompt = self.prompt_builder.build(
            question=question,
            session_title=session.title,
            system_prompt=system_prompt,
            conversation_history=[f"{item.role}:{item.content}" for item in history_entries],
            session_material_context_text=material_context_text,
            retrieval_context_text=retrieval.context_text,
            prompt_config=prompt_config,
        )
        last_error: Exception | None = None
        current_task = replace(
            task,
            status="streaming",
            prompt_template_id=prompt.prompt_config.template_id,
            prompt_version=prompt.prompt_config.version,
            retrieval_excerpt_count=retrieval.final_count,
            material_context_status=material_assembly.status,
            fixed_source_count=material_assembly.fixed_source_count,
            retrieved_source_count=material_assembly.retrieved_source_count,
            material_provenance=material_provenance,
            unavailable_material_sources=[self._material_source_payload(item) for item in material_assembly.unavailable_sources],
            updated_at_ms=_now_ms(),
        )
        self.repository.save_task(current_task)
        for attempt in range(self.settings.chat_retry_max_attempts + 1):
            try:
                active_prompt = (
                    _english_repair_prompt(prompt, session.interview_language)
                    if session.interview_language != "zh-CN" and attempt > 0
                    else prompt
                )
                gateway_result = self.llm_gateway.generate(
                    question=question,
                    prompt=active_prompt,
                    stream=stream,
                    attempt=attempt,
                )
                if session.interview_language != "zh-CN" and output_language_violation(gateway_result.final_text, session.interview_language):
                    self._log_language_violation(
                        session_id=session_id,
                        task_id=current_task.task_id,
                        stage="nonstream",
                        prompt=active_prompt,
                        attempt=attempt,
                    )
                    raise RetryableChatError(
                        "The answer model returned the wrong language.",
                        code="chat_output_language_violation",
                    )
                completed = self._complete_task(task=current_task, gateway_result=gateway_result, retry_count=attempt)
                self.session_service.append_context(
                    user_id=user_id,
                    session_id=session_id,
                    role="assistant",
                    source_kind="ai-answer",
                    content=completed.answer_text,
                    visibility="ai",
                    related_task_id=completed.task_id,
                )
                if gateway_result.usage is not None:
                    self.session_service.record_usage(
                        user_id=user_id,
                        session_id=session_id,
                        usage_kind="total",
                        prompt_tokens=gateway_result.usage.prompt_tokens,
                        completion_tokens=gateway_result.usage.completion_tokens,
                        total_tokens=gateway_result.usage.total_tokens,
                        provider_name=gateway_result.usage.provider_name,
                        model_name=gateway_result.usage.model_name,
                        related_task_id=completed.task_id,
                    )
                self._record_ai_usage(
                    user_id=user_id, session_id=session_id, task_id=completed.task_id,
                    status="succeeded", started_at_ms=now_ms, usage=gateway_result.usage,
                )
                self._log(logging.INFO, "chat.completed", task=completed, session_id=session_id, question=question, retry_count=attempt)
                if self.billing_service is not None:
                    self.billing_service.settle_usage(usage_id=billing_usage_id)
                return completed, self._to_retrieval_response(retrieval)
            except RetryableChatError as exc:
                last_error = exc
                self._log(logging.WARNING, "chat.retrying", task=current_task, session_id=session_id, question=question, retry_count=attempt + 1, error_code=exc.code)
                continue
            except NonRetryableChatError as exc:
                last_error = exc
                break
        error_code = getattr(last_error, "code", last_error.__class__.__name__ if last_error else "chat_failed")
        failed = self.repository.save_task(
            replace(
                current_task,
                status="failed",
                retry_count=self.settings.chat_retry_max_attempts,
                error_code=error_code,
                error_message=str(last_error) if last_error else "chat_failed",
                updated_at_ms=_now_ms(),
                completed_at_ms=_now_ms(),
            )
        )
        if self.billing_service is not None:
            self.billing_service.release_usage(usage_id=billing_usage_id)
        self._record_ai_usage(
            user_id=user_id, session_id=session_id, task_id=failed.task_id,
            status="failed", started_at_ms=now_ms, safe_error_code=error_code,
        )
        self._log(logging.WARNING, "chat.failed", task=failed, session_id=session_id, question=question, retry_count=failed.retry_count, error_code=error_code)
        return failed, self._to_retrieval_response(retrieval)

    def stream_answer_question(
        self, *, user_id: str, session_id: str, question: str, usage_id: str | None = None,
        question_id: str | None = None, question_revision: int | None = None,
        clicked_at_ms: int | None = None, prefetch_revision: int | None = None,
        route_received_at_ms: int | None = None, executor_admitted_at_ms: int | None = None,
        answer_generator_started_at_ms: int | None = None,
    ) -> Iterator[dict]:
        answer_accepted_at_ms = answer_generator_started_at_ms or _now_ms()
        session = self.session_service.get_session(user_id=user_id, session_id=session_id)
        if session.session_mode == "written":
            raise DomainRequestError("live-answer", "start-stream", "笔试模式仅支持截屏回答。", 409, error_code="written_exam_mode_mismatch")
        if session.status != "live":
            raise DomainRequestError("live-answer", "start-stream", "只有进行中的面试会话才能发起实时回答。", 400)
        self.session_service.touch_activity(user_id=user_id, session_id=session_id, force=True)
        now_ms = _now_ms()
        task_id = f"answer-{uuid4().hex}"
        billing_usage_id = usage_id or f"live-answer:{task_id}"
        self._reserve_answer_usage(user_id=user_id, usage_id=billing_usage_id)
        self.billing_usage_by_task[task_id] = billing_usage_id
        task = self.repository.save_task(
            ChatAnswerTaskRecord(
                task_id=task_id,
                session_id=session_id,
                owner_user_id=user_id,
                question=question.strip(),
                answer_text="",
                status="queued",
                stream_mode=True,
                raw_question=question.strip(),
                question_normalization_status="pending",
                question_id=question_id,
                question_revision=question_revision,
                clicked_at_ms=clicked_at_ms or now_ms,
                prefetch_revision=prefetch_revision,
                created_at_ms=now_ms,
                updated_at_ms=now_ms,
            )
        )
        self._log(logging.INFO, "chat.stream_started", task=task, session_id=session_id, question=question, retry_count=0)
        self.session_service.append_context(
            user_id=user_id,
            session_id=session_id,
            role="manual-question",
            source_kind="manual-input",
            content=question,
            visibility="session",
            related_task_id=task.task_id,
            validated_session=session,
            activity_already_touched=True,
        )
        quick_retrieval = self._prepared_retrieval(
            session_id=session_id,
            question_id=question_id,
            revision=prefetch_revision,
            question=question,
        ) or RetrievalContext(
            normalized_question=question.strip(),
            context_text="",
            chunks=[],
            candidate_count=0,
            final_count=0,
            strategy="filtered-first",
        )
        material_context_text, material_assembly, material_provenance = self._assemble_material_context(session=session, retrieval=quick_retrieval)
        quick_system_prompt, prompt_config = self._load_stage_prompt("quick", session.interview_language)
        quick_system_prompt = append_programming_policy(quick_system_prompt, session=session)
        material_context_text = material_context_text[:min(2400, int(getattr(self.settings, "rag_context_max_characters", 6000)))]
        conversation_history = self._conversation_history(
            user_id=user_id,
            session_id=session_id,
            question=question,
            session=session,
        )
        prompt = self.prompt_builder.build(
            question=question,
            session_title=session.title,
            system_prompt=quick_system_prompt,
            conversation_history=conversation_history,
            session_material_context_text=material_context_text,
            retrieval_context_text="",
            prompt_config=prompt_config,
        )
        current_task = self.repository.save_task(
            replace(
                task,
                status="streaming",
                provider_name="qwen-compatible",
                model_name=self.settings.chat_qwen_model,
                prompt_template_id=prompt.prompt_config.template_id,
                prompt_version=prompt.prompt_config.version,
                retrieval_excerpt_count=quick_retrieval.final_count,
                material_context_status=material_assembly.status,
                fixed_source_count=material_assembly.fixed_source_count,
                retrieved_source_count=material_assembly.retrieved_source_count,
                material_provenance=self._prompt_metadata(
                    material_provenance,
                    stages={"quick": f"{prompt.prompt_config.template_id}:{prompt.prompt_config.version}"},
                ),
                unavailable_material_sources=[self._material_source_payload(item) for item in material_assembly.unavailable_sources],
                updated_at_ms=_now_ms(),
            )
        )
        yield {"type": "task-started", "task": current_task, "retrieval": self._to_retrieval_response(quick_retrieval)}
        chunks: list[ChatAnswerChunk] = []
        answer_parts: list[str] = []
        normalization_buffer = ""
        normalization_resolved = False
        normalized_question = question.strip()
        quick_language_buffer = ""
        quick_language_validated = session.interview_language == "zh-CN"
        quick_finish_reason = "stop"
        continuation_prompt_characters = 0
        continuation_count = 0
        last_error: Exception | None = None
        stream_started_at_ms = _now_ms()
        provider_request_at_ms = stream_started_at_ms
        first_token_at_ms: int | None = None
        first_visible_at_ms: int | None = None
        detail_retrieval_future: Future[RetrievalContext] | None = None

        def mark_first_visible() -> dict[str, int] | None:
            nonlocal first_visible_at_ms
            if first_visible_at_ms is not None:
                return None
            first_visible_at_ms = _now_ms()
            timing = {
                "serverAcceptedAtMs": answer_accepted_at_ms,
                "routeReceivedAtMs": route_received_at_ms or answer_accepted_at_ms,
                "executorAdmittedAtMs": executor_admitted_at_ms or answer_accepted_at_ms,
                "answerGeneratorStartedAtMs": answer_generator_started_at_ms or answer_accepted_at_ms,
                "providerRequestAtMs": provider_request_at_ms,
                "providerFirstTokenAtMs": first_token_at_ms or first_visible_at_ms,
                "firstVisibleAtMs": first_visible_at_ms,
            }
            log_event(
                self.logger,
                logging.INFO,
                settings=self.settings,
                event="chat.first_visible_answer",
                feature="live-answer",
                action="first-visible-answer",
                session_id=session_id,
                task_id=current_task.task_id,
                admission_to_visible_ms=max(0, first_visible_at_ms - answer_accepted_at_ms),
                provider_to_visible_ms=max(0, first_visible_at_ms - provider_request_at_ms),
            )
            return timing

        for attempt in range(self.settings.chat_retry_max_attempts + 1):
            try:
                active_quick_prompt = (
                    _english_repair_prompt(prompt, session.interview_language)
                    if session.interview_language != "zh-CN" and attempt > 0
                    else prompt
                )
                if self._is_task_cancelled(current_task.task_id):
                    cancelled = self.repository.get_task(current_task.task_id) or current_task
                    yield {"type": "cancelled", "task": cancelled}
                    return
                for chunk in self.llm_gateway.stream_generate(
                    question=question,
                    prompt=active_quick_prompt,
                    attempt=attempt,
                ):
                    if self._is_task_cancelled(current_task.task_id):
                        cancelled = self.repository.get_task(current_task.task_id) or current_task
                        yield {"type": "cancelled", "task": cancelled}
                        return
                    if chunk.provider_finish_reason is not None:
                        quick_finish_reason = chunk.provider_finish_reason
                    if chunk.text and first_token_at_ms is None:
                        first_token_at_ms = _now_ms()
                        log_event(
                            self.logger,
                            logging.INFO,
                            settings=self.settings,
                            event="chat.provider_first_token",
                            feature="live-answer",
                            action="provider-first-token",
                            session_id=session_id,
                            task_id=current_task.task_id,
                            admission_to_provider_ms=max(0, provider_request_at_ms - answer_accepted_at_ms),
                            route_to_executor_admission_ms=max(0, (executor_admitted_at_ms or answer_accepted_at_ms) - (route_received_at_ms or answer_accepted_at_ms)),
                            executor_admission_to_generator_ms=max(0, (answer_generator_started_at_ms or answer_accepted_at_ms) - (executor_admitted_at_ms or answer_accepted_at_ms)),
                            provider_first_token_ms=max(0, first_token_at_ms - provider_request_at_ms),
                        )
                    visible_text = chunk.text
                    if not normalization_resolved:
                        normalization_buffer += chunk.text
                        envelope_complete = _NORMALIZED_QUESTION_CLOSE in normalization_buffer
                        force_fallback = len(normalization_buffer) >= _NORMALIZATION_BUFFER_LIMIT
                        if not envelope_complete and not force_fallback:
                            continue
                        normalized_question, visible_text, normalization_status = _resolve_normalized_question(
                            normalization_buffer,
                            question,
                        )
                        if session.interview_language != "zh-CN" and output_language_violation(normalized_question, session.interview_language):
                            self._log_language_violation(
                                session_id=session_id,
                                task_id=current_task.task_id,
                                stage="question-normalization",
                                prompt=active_quick_prompt,
                                attempt=attempt,
                            )
                            raise RetryableChatError(
                                "The answer model normalized the question in the wrong language.",
                                code="chat_output_language_violation",
                            )
                        normalization_resolved = True
                        current_task = self.repository.save_task(
                            replace(
                                current_task,
                                question=normalized_question,
                                raw_question=question.strip(),
                                normalized_question=normalized_question,
                                question_normalization_status=normalization_status,
                                updated_at_ms=_now_ms(),
                            )
                        )
                        if self.settings.chat_detail_retrieval_prefetch_enabled:
                            detail_retrieval_future = _DETAIL_RETRIEVAL_EXECUTOR.submit(
                                self._retrieve_context,
                                user_id=user_id,
                                session=session,
                                question=normalized_question,
                            )
                        yield {"type": "question-normalized", "task": current_task}
                    if session.interview_language == "zh-CN":
                        visible_text = f"简单回答\n{visible_text}"
                    if session.interview_language != "zh-CN" and not quick_language_validated:
                        quick_language_buffer += visible_text
                        if output_language_violation(quick_language_buffer, session.interview_language):
                            self._log_language_violation(
                                session_id=session_id,
                                task_id=current_task.task_id,
                                stage="quick",
                                prompt=active_quick_prompt,
                                attempt=attempt,
                            )
                            raise RetryableChatError(
                                "The answer model returned the wrong language.",
                                code="chat_output_language_violation",
                            )
                        script_characters = len(_HAN_SCRIPT_PATTERN.findall(quick_language_buffer)) + len(
                            _LATIN_SCRIPT_PATTERN.findall(quick_language_buffer)
                        )
                        if script_characters < 24 and chunk.provider_finish_reason is None:
                            continue
                        visible_text = f"Quick Answer\n{quick_language_buffer}"
                        quick_language_validated = True
                    if not visible_text:
                        continue
                    normalized = ChatAnswerChunk(sequence=len(chunks) + 1, text=visible_text, is_final=False)
                    chunks.append(normalized)
                    answer_parts.append(normalized.text)
                    current_task = self.repository.save_task(
                        replace(current_task, chunks=chunks.copy(), answer_text="".join(answer_parts), retry_count=attempt, updated_at_ms=_now_ms())
                    )
                    timing = mark_first_visible()
                    yield {"type": "chunk", "task": current_task, "chunk": normalized, **({"timing": timing} if timing else {})}
                if not normalization_resolved:
                    normalized_question, visible_text, normalization_status = _resolve_normalized_question(
                        normalization_buffer,
                        question,
                    )
                    if session.interview_language != "zh-CN" and output_language_violation(normalized_question, session.interview_language):
                        self._log_language_violation(
                            session_id=session_id,
                            task_id=current_task.task_id,
                            stage="question-normalization",
                            prompt=active_quick_prompt,
                            attempt=attempt,
                        )
                        raise RetryableChatError(
                            "The answer model normalized the question in the wrong language.",
                            code="chat_output_language_violation",
                        )
                    normalization_resolved = True
                    current_task = self.repository.save_task(
                        replace(
                            current_task,
                            question=normalized_question,
                            raw_question=question.strip(),
                            normalized_question=normalized_question,
                            question_normalization_status=normalization_status,
                            updated_at_ms=_now_ms(),
                        )
                    )
                    if self.settings.chat_detail_retrieval_prefetch_enabled:
                        detail_retrieval_future = _DETAIL_RETRIEVAL_EXECUTOR.submit(
                            self._retrieve_context,
                            user_id=user_id,
                            session=session,
                            question=normalized_question,
                        )
                    yield {"type": "question-normalized", "task": current_task}
                    if session.interview_language != "zh-CN":
                        quick_language_buffer += visible_text
                        if output_language_violation(quick_language_buffer, session.interview_language):
                            self._log_language_violation(
                                session_id=session_id,
                                task_id=current_task.task_id,
                                stage="quick",
                                prompt=active_quick_prompt,
                                attempt=attempt,
                            )
                            raise RetryableChatError(
                                "The answer model returned the wrong language.",
                                code="chat_output_language_violation",
                            )
                        visible_text = f"Quick Answer\n{quick_language_buffer}"
                        quick_language_validated = True
                    else:
                        visible_text = f"简单回答\n{visible_text}"
                    normalized = ChatAnswerChunk(sequence=len(chunks) + 1, text=visible_text, is_final=False)
                    chunks.append(normalized)
                    answer_parts.append(normalized.text)
                    current_task = self.repository.save_task(
                        replace(current_task, chunks=chunks.copy(), answer_text="".join(answer_parts), retry_count=attempt, updated_at_ms=_now_ms())
                    )
                    timing = mark_first_visible()
                    yield {"type": "chunk", "task": current_task, "chunk": normalized, **({"timing": timing} if timing else {})}
                elif session.interview_language != "zh-CN" and not quick_language_validated:
                    if output_language_violation(quick_language_buffer, session.interview_language):
                        self._log_language_violation(
                            session_id=session_id,
                            task_id=current_task.task_id,
                            stage="quick",
                            prompt=active_quick_prompt,
                            attempt=attempt,
                        )
                        raise RetryableChatError(
                            "The answer model returned the wrong language.",
                            code="chat_output_language_violation",
                        )
                    normalized = ChatAnswerChunk(
                        sequence=len(chunks) + 1,
                        text=f"Quick Answer\n{quick_language_buffer}",
                        is_final=False,
                    )
                    chunks.append(normalized)
                    answer_parts.append(normalized.text)
                    quick_language_validated = True
                    current_task = self.repository.save_task(
                        replace(current_task, chunks=chunks.copy(), answer_text="".join(answer_parts), retry_count=attempt, updated_at_ms=_now_ms())
                    )
                    timing = mark_first_visible()
                    yield {"type": "chunk", "task": current_task, "chunk": normalized, **({"timing": timing} if timing else {})}
                quick_heading = "Quick Answer" if session.interview_language == "en-US" else "简单回答"
                quick_answer = "".join(answer_parts).removeprefix(f"{quick_heading}\n").strip()
                quick_suffix, quick_continuations, quick_prompt_characters = self._complete_answer_stage(
                    stage="quick",
                    question=normalized_question,
                    prompt=active_quick_prompt,
                    existing_answer=quick_answer,
                    finish_reason=quick_finish_reason,
                    provider_attempt=attempt,
                    task_id=current_task.task_id,
                    session_id=session_id,
                    interview_language=session.interview_language,
                )
                continuation_count += quick_continuations
                continuation_prompt_characters += quick_prompt_characters
                if quick_suffix:
                    normalized = ChatAnswerChunk(sequence=len(chunks) + 1, text=quick_suffix, is_final=False)
                    chunks.append(normalized)
                    answer_parts.append(normalized.text)
                    current_task = self.repository.save_task(
                        replace(current_task, chunks=chunks.copy(), answer_text="".join(answer_parts), retry_count=attempt, updated_at_ms=_now_ms())
                    )
                    yield {"type": "chunk", "task": current_task, "chunk": normalized}
                retrieval = (
                    detail_retrieval_future.result()
                    if detail_retrieval_future is not None
                    else self._retrieve_context(user_id=user_id, session=session, question=normalized_question)
                )
                if self._is_task_cancelled(current_task.task_id):
                    cancelled = self.repository.get_task(current_task.task_id) or current_task
                    yield {"type": "cancelled", "task": cancelled}
                    return
                material_context_text, material_assembly, material_provenance = self._assemble_material_context(session=session, retrieval=retrieval)
                detail_system_prompt, detail_prompt_config = self._load_stage_prompt("detail", session.interview_language)
                detail_system_prompt = append_programming_policy(detail_system_prompt, session=session)
                quick_answer_anchor = "".join(answer_parts).removeprefix(f"{quick_heading}\n").strip()
                detail_prompt = self.prompt_builder.build(
                    question=normalized_question,
                    session_title=session.title,
                    system_prompt=detail_system_prompt,
                    conversation_history=[*conversation_history, f"{'Quick answer anchor: ' if session.interview_language == 'en-US' else '本轮简要回答锚点：'}{quick_answer_anchor}"],
                    session_material_context_text=material_context_text[:int(getattr(self.settings, "rag_context_max_characters", 6000))],
                    retrieval_context_text=retrieval.context_text,
                    prompt_config=detail_prompt_config,
                )
                current_task = self.repository.save_task(
                    replace(
                        current_task,
                        prompt_template_id="interview-chat-quick+detail",
                        prompt_version=detail_prompt.prompt_config.version,
                        retrieval_excerpt_count=retrieval.final_count,
                        material_context_status=material_assembly.status,
                        fixed_source_count=material_assembly.fixed_source_count,
                        retrieved_source_count=material_assembly.retrieved_source_count,
                        material_provenance=self._prompt_metadata(
                            material_provenance,
                            stages={
                                "quick": f"{prompt.prompt_config.template_id}:{prompt.prompt_config.version}",
                                "detail": f"{detail_prompt.prompt_config.template_id}:{detail_prompt.prompt_config.version}",
                            },
                        ),
                        unavailable_material_sources=[self._material_source_payload(item) for item in material_assembly.unavailable_sources],
                        updated_at_ms=_now_ms(),
                    )
                )
                separator = f"\n\n---\n\n{'Detailed Answer' if session.interview_language == 'en-US' else '详细回答'}\n"
                normalized = ChatAnswerChunk(sequence=len(chunks) + 1, text=separator, is_final=False)
                chunks.append(normalized)
                answer_parts.append(normalized.text)
                current_task = self.repository.save_task(
                    replace(current_task, chunks=chunks.copy(), answer_text="".join(answer_parts), retry_count=attempt, updated_at_ms=_now_ms())
                )
                yield {"type": "chunk", "task": current_task, "chunk": normalized}
                detail_parts: list[str] = []
                detail_finish_reason = "stop"
                detail_chunks: list[ChatAnswerChunk] = []
                if session.interview_language != "en-US":
                    for chunk in self.llm_gateway.stream_generate(
                        question=normalized_question,
                        prompt=detail_prompt,
                        attempt=attempt,
                    ):
                        if self._is_task_cancelled(current_task.task_id):
                            cancelled = self.repository.get_task(current_task.task_id) or current_task
                            yield {"type": "cancelled", "task": cancelled}
                            return
                        if chunk.provider_finish_reason is not None:
                            detail_finish_reason = chunk.provider_finish_reason
                        if not chunk.text:
                            continue
                        detail_parts.append(chunk.text)
                        normalized = ChatAnswerChunk(sequence=len(chunks) + 1, text=chunk.text, is_final=False)
                        chunks.append(normalized)
                        answer_parts.append(normalized.text)
                        current_task = self.repository.save_task(
                            replace(current_task, chunks=chunks.copy(), answer_text="".join(answer_parts), retry_count=attempt, updated_at_ms=_now_ms())
                        )
                        yield {"type": "chunk", "task": current_task, "chunk": normalized}
                else:
                    for language_attempt in range(2):
                        active_detail_prompt = (
                            _english_repair_prompt(detail_prompt, session.interview_language)
                            if language_attempt > 0
                            else detail_prompt
                        )
                        detail_parts = []
                        detail_chunks = []
                        detail_finish_reason = "stop"
                        for chunk in self.llm_gateway.stream_generate(
                            question=normalized_question,
                            prompt=active_detail_prompt,
                            attempt=attempt + language_attempt,
                        ):
                            if self._is_task_cancelled(current_task.task_id):
                                cancelled = self.repository.get_task(current_task.task_id) or current_task
                                yield {"type": "cancelled", "task": cancelled}
                                return
                            if chunk.provider_finish_reason is not None:
                                detail_finish_reason = chunk.provider_finish_reason
                            if chunk.text:
                                detail_parts.append(chunk.text)
                                detail_chunks.append(chunk)
                        if not output_language_violation("".join(detail_parts), session.interview_language):
                            break
                        self._log_language_violation(
                            session_id=session_id,
                            task_id=current_task.task_id,
                            stage="detail",
                            prompt=active_detail_prompt,
                            attempt=attempt + language_attempt,
                        )
                    else:
                        raise NonRetryableChatError(
                            "The answer model repeatedly returned the wrong language. Please retry this question.",
                            code="chat_output_language_violation",
                        )
                    for chunk in detail_chunks:
                        normalized = ChatAnswerChunk(sequence=len(chunks) + 1, text=chunk.text, is_final=False)
                        chunks.append(normalized)
                        answer_parts.append(normalized.text)
                        current_task = self.repository.save_task(
                            replace(current_task, chunks=chunks.copy(), answer_text="".join(answer_parts), retry_count=attempt, updated_at_ms=_now_ms())
                        )
                        yield {"type": "chunk", "task": current_task, "chunk": normalized}
                detail_answer = "".join(detail_parts).strip()
                detail_suffix, detail_continuations, detail_prompt_characters = self._complete_answer_stage(
                    stage="detail",
                    question=normalized_question,
                    prompt=detail_prompt,
                    existing_answer=detail_answer,
                    finish_reason=detail_finish_reason,
                    provider_attempt=attempt,
                    task_id=current_task.task_id,
                    session_id=session_id,
                    interview_language=session.interview_language,
                )
                continuation_count += detail_continuations
                continuation_prompt_characters += detail_prompt_characters
                if detail_suffix:
                    normalized = ChatAnswerChunk(sequence=len(chunks) + 1, text=detail_suffix, is_final=False)
                    chunks.append(normalized)
                    answer_parts.append(normalized.text)
                    current_task = self.repository.save_task(
                        replace(current_task, chunks=chunks.copy(), answer_text="".join(answer_parts), retry_count=attempt, updated_at_ms=_now_ms())
                    )
                    yield {"type": "chunk", "task": current_task, "chunk": normalized}
                final_text = "".join(answer_parts).strip()
                if not final_text:
                    raise NonRetryableChatError("当前对话模型返回了无效结果，请稍后重试或检查模型配置。", code="chat_provider_invalid_response")
                if session.interview_language != "zh-CN" and output_language_violation(final_text, session.interview_language):
                    self._log_language_violation(
                        session_id=session_id,
                        task_id=current_task.task_id,
                        stage="complete",
                        prompt=detail_prompt,
                        attempt=attempt,
                    )
                    raise NonRetryableChatError(
                        "The answer model returned the wrong language. Please retry this question.",
                        code="chat_output_language_violation",
                    )
                if chunks:
                    last = chunks[-1]
                    chunks[-1] = ChatAnswerChunk(sequence=last.sequence, text=last.text, is_final=True)
                usage = UsageReport(
                    prompt_tokens=max(1, (len(prompt.rendered_prompt) + len(detail_prompt.rendered_prompt) + continuation_prompt_characters) // 4),
                    completion_tokens=max(1, len(final_text) // 4),
                    total_tokens=max(1, (len(prompt.rendered_prompt) + len(detail_prompt.rendered_prompt) + continuation_prompt_characters) // 4) + max(1, len(final_text) // 4),
                    provider_name="qwen-compatible",
                    model_name=self.settings.chat_qwen_model,
                )
                completed = self._complete_task(
                    task=current_task,
                    gateway_result=GatewayAnswerResult(
                        provider_name="qwen-compatible",
                        model_name=self.settings.chat_qwen_model,
                        chunks=chunks.copy(),
                        final_text=final_text,
                        finish_reason="completed",
                        usage=usage,
                    ),
                    retry_count=attempt,
                )
                self.session_service.append_context(
                    user_id=user_id,
                    session_id=session_id,
                    role="assistant",
                    source_kind="ai-answer",
                    content=completed.answer_text,
                    visibility="ai",
                    related_task_id=completed.task_id,
                )
                self.session_service.record_usage(
                    user_id=user_id,
                    session_id=session_id,
                    usage_kind="total",
                    prompt_tokens=usage.prompt_tokens,
                    completion_tokens=usage.completion_tokens,
                    total_tokens=usage.total_tokens,
                    provider_name=usage.provider_name,
                    model_name=usage.model_name,
                    related_task_id=completed.task_id,
                )
                self._record_ai_usage(
                    user_id=user_id, session_id=session_id, task_id=completed.task_id,
                    status="succeeded", started_at_ms=stream_started_at_ms, usage=usage,
                    first_token_ms=(first_token_at_ms - stream_started_at_ms) if first_token_at_ms is not None else None,
                )
                log_event(
                    self.logger, logging.INFO, settings=self.settings,
                    event="chat.prompt_quality_completed", feature="live-answer", action="prompt-quality",
                    session_id=session_id, task_id=completed.task_id,
                    prompt_template_id=completed.prompt_template_id, prompt_version=completed.prompt_version,
                    interview_language=session.interview_language,
                    stage="quick+detail",
                    prompt_strategy_mode="adaptive-evidence-first",
                    fixed_source_count=completed.fixed_source_count, retrieved_source_count=completed.retrieved_source_count,
                    question_size_bucket=self._size_bucket(len(question)), answer_size_bucket=self._size_bucket(len(completed.answer_text)),
                    first_token_ms=(first_token_at_ms - stream_started_at_ms) if first_token_at_ms is not None else None,
                    completion_ms=_now_ms() - stream_started_at_ms, status=completed.status,
                    continuation_count=continuation_count,
                )
                self._log(logging.INFO, "chat.stream_completed", task=completed, session_id=session_id, question=question, retry_count=attempt)
                if self.billing_service is not None:
                    self.billing_service.settle_usage(usage_id=billing_usage_id)
                yield {"type": "completed", "task": completed, "retrieval": self._to_retrieval_response(retrieval)}
                return
            except ChatTaskCancelled:
                cancelled = self.repository.get_task(current_task.task_id) or current_task
                yield {"type": "cancelled", "task": cancelled}
                return
            except RetryableChatError as exc:
                last_error = exc
                self._log(logging.WARNING, "chat.stream_retrying", task=current_task, session_id=session_id, question=question, retry_count=attempt + 1, error_code=exc.code)
                if chunks:
                    break
                normalization_buffer = ""
                normalization_resolved = False
                normalized_question = question.strip()
                quick_language_buffer = ""
                quick_language_validated = session.interview_language == "zh-CN"
                continue
            except NonRetryableChatError as exc:
                if exc.partial_suffix:
                    partial_chunk = ChatAnswerChunk(
                        sequence=len(chunks) + 1,
                        text=exc.partial_suffix,
                        is_final=False,
                    )
                    chunks.append(partial_chunk)
                    answer_parts.append(partial_chunk.text)
                    current_task = self.repository.save_task(
                        replace(
                            current_task,
                            chunks=chunks.copy(),
                            answer_text="".join(answer_parts),
                            retry_count=attempt,
                            updated_at_ms=_now_ms(),
                        )
                    )
                last_error = exc
                break
        error_code = getattr(last_error, "code", last_error.__class__.__name__ if last_error else "chat_failed")
        failed = self.repository.save_task(
            replace(
                current_task,
                status="failed",
                chunks=chunks.copy(),
                answer_text="".join(answer_parts),
                retry_count=self.settings.chat_retry_max_attempts,
                error_code=error_code,
                error_message=str(last_error) if last_error else "chat_failed",
                updated_at_ms=_now_ms(),
                completed_at_ms=_now_ms(),
            )
        )
        if self.billing_service is not None:
            self.billing_service.release_usage(usage_id=billing_usage_id)
        self._record_ai_usage(
            user_id=user_id, session_id=session_id, task_id=failed.task_id,
            status="failed", started_at_ms=stream_started_at_ms, safe_error_code=error_code,
        )
        self._log(logging.WARNING, "chat.stream_failed", task=failed, session_id=session_id, question=question, retry_count=failed.retry_count, error_code=error_code)
        yield {"type": "failed", "task": failed, "error_code": error_code, "error_message": failed.error_message, "partial_text": failed.answer_text}

    def get_task(self, *, user_id: str, task_id: str) -> ChatAnswerTaskRecord:
        task = self.repository.get_task(task_id)
        if task is None:
            raise DomainRequestError("live-answer", "get-task", "回答任务不存在。", 404)
        if task.owner_user_id != user_id:
            raise DomainRequestError("live-answer", "get-task", "不能查看其他用户的回答任务。", 403)
        return task

    def cancel_task(self, *, user_id: str, task_id: str, expected_revision: int | None = None) -> tuple[str, ChatAnswerTaskRecord]:
        task = self.get_task(user_id=user_id, task_id=task_id)
        revision = max(1, task.updated_at_ms)
        if expected_revision is not None and expected_revision not in {0, 1, revision}:
            return "stale-revision", task
        if task.status == "cancelled":
            return "already-cancelled", task
        if task.status not in {"queued", "streaming"}:
            return "not-cancellable", task
        cancelled = self.repository.save_task(replace(task, status="cancelled", updated_at_ms=_now_ms(), completed_at_ms=_now_ms()))
        if self.billing_service is not None:
            self.billing_service.release_usage(
                usage_id=self.billing_usage_by_task.get(task.task_id, f"live-answer:{task.task_id}")
            )
        return "cancelled", cancelled

    def _is_task_cancelled(self, task_id: str) -> bool:
        task = self.repository.get_task(task_id)
        return task is not None and task.status == "cancelled"

    def list_session_history(self, *, user_id: str, session_id: str) -> list[ChatAnswerTaskRecord]:
        self.session_service.get_session(user_id=user_id, session_id=session_id)
        return self.repository.list_tasks_for_session(session_id=session_id)

    def _complete_task(self, *, task: ChatAnswerTaskRecord, gateway_result: GatewayAnswerResult, retry_count: int) -> ChatAnswerTaskRecord:
        completed = replace(
            task,
            answer_text=gateway_result.final_text,
            status="completed",
            provider_name=gateway_result.provider_name,
            model_name=gateway_result.model_name,
            chunks=gateway_result.chunks,
            retry_count=retry_count,
            updated_at_ms=_now_ms(),
            completed_at_ms=_now_ms(),
        )
        return self.repository.save_task(completed)

    def _retrieve_context(self, *, user_id: str, session, question: str):
        try:
            knowledge_documents = [document for document in session.material_binding.bound_documents if document.active and document.document_kind == "knowledge"]
            context = self.retrieval_service.retrieve(
                question=question,
                filter=RetrievalFilter(
                    owner_user_id=user_id,
                    interview_session_id=session.session_id,
                    document_kinds=["knowledge"] if knowledge_documents else [],
                    document_ids=[document.document_id for document in knowledge_documents],
                    document_version_ids=[
                        document.document_version_id
                        for document in knowledge_documents
                        if document.document_version_id
                    ],
                    knowledge_collection_ids=[
                        document.knowledge_collection_id
                        for document in knowledge_documents
                        if document.knowledge_collection_id
                    ],
                ),
                candidate_top_k=min(self.settings.retrieval_candidate_top_k, 6),
                final_top_k=min(self.settings.retrieval_final_top_k, 3),
                strategy=self.settings.retrieval_strategy,  # type: ignore[arg-type]
            )
            return context
        except Exception as exc:
            self._log(
                logging.WARNING,
                "chat.retrieval_degraded",
                task=None,
                session_id=session.session_id,
                question=question,
                retry_count=0,
                error_code=exc.__class__.__name__,
            )
            from app.ports.retrieval import RetrievalContext

            return RetrievalContext(
                normalized_question=question.strip(),
                context_text="",
                chunks=[],
                candidate_count=0,
                final_count=0,
                strategy="filtered-first",
            )

    def _assemble_material_context(self, *, session, retrieval) -> tuple[str, MaterialContextAssembly, dict[str, object]]:
        lines: list[str] = []
        used_sources: list[MaterialContextSource] = []
        unavailable_sources: list[MaterialContextSource] = []
        for label, kind in (("简历", "resume"), ("职位 JD", "job_description")):
            document = next((item for item in session.material_binding.bound_documents if item.active and item.document_kind == kind), None)
            if document is None:
                continue
            content, truncated = self._load_material_summary_for_prompt(document)
            source = MaterialContextSource(
                source_id=document.document_id,
                source_version=document.document_version_id or document.document_id,
                display_name=document.display_name,
                kind="jd" if document.document_kind == "job_description" else document.document_kind,
                document_id=document.document_id,
                document_version_id=document.document_version_id,
                context_role="fixed",
                evidence_summary=(content[:80].replace("\n", " ") if content else None),
                truncated=truncated,
                unavailable=not bool(content),
                unavailable_reason=None if content else "material_summary_unavailable",
            )
            if content:
                used_sources.append(source)
                lines.append(f"[{label}] {document.display_name} ({document.document_version_id or document.document_id})\n{content}")
            else:
                unavailable_sources.append(source)
                lines.append(f"[{label}] {document.display_name}：资料已选择，但面试摘要当前不可用，本次回答不得声称已使用该资料细节。")
        retrieved_by_document: dict[str, list] = {}
        for chunk in retrieval.chunks:
            retrieved_by_document.setdefault(chunk.document_id, []).append(chunk)
        for document in [item for item in session.material_binding.bound_documents if item.active and item.document_kind == "knowledge"]:
            chunks = retrieved_by_document.get(document.document_id, [])
            if not chunks:
                continue
            first = chunks[0]
            used_sources.append(
                MaterialContextSource(
                    source_id=document.document_id,
                    source_version=document.document_version_id or document.document_id,
                    display_name=document.display_name,
                    kind="knowledge",
                    document_id=document.document_id,
                    document_version_id=document.document_version_id,
                    context_role="retrieved",
                    evidence_summary=first.content[:80].replace("\n", " "),
                    retrieval_count=len(chunks),
                    truncated=False,
                )
            )
        status = "ready" if used_sources and not unavailable_sources else "degraded" if used_sources or unavailable_sources else "no-context"
        assembly = MaterialContextAssembly(
            status=status,
            fixed_source_count=len([item for item in used_sources if item.context_role == "fixed"]),
            retrieved_source_count=len([item for item in used_sources if item.context_role == "retrieved"]),
            used_sources=used_sources,
            unavailable_sources=unavailable_sources,
        )
        provenance = {
            "interviewLanguage": getattr(session, "interview_language", "zh-CN"),
            "selectionRevision": session.material_binding.revision,
            "usedSources": [self._material_source_payload(item) for item in used_sources],
            "unavailableSources": [self._material_source_payload(item) for item in unavailable_sources],
            "fixedSourceCount": assembly.fixed_source_count,
            "retrievedSourceCount": assembly.retrieved_source_count,
            "noPersonalMaterialUsed": not used_sources,
            "retrievalTraceId": getattr(retrieval, "trace_id", None),
        }
        return "\n\n".join(lines), assembly, provenance

    def _session_material_prompt_context(self, session) -> str:
        return self._assemble_material_context(session=session, retrieval=type("EmptyRetrieval", (), {"chunks": []})())[0]

    def _load_material_summary_for_prompt(self, document) -> tuple[str, bool]:
        summary = (document.summary or "").strip()
        if not summary:
            return "", False
        generic_prefixes = (
            "文档处理完成",
            "文档处理中",
            "文档已重新进入处理队列",
            "文档解析失败",
            "文档向量化失败",
            "文档处理失败",
        )
        if any(summary.startswith(prefix) for prefix in generic_prefixes):
            return "", False
        limit = 900 if document.document_kind == "resume" else 700
        truncated = len(summary) > limit
        return summary[:limit] + ("\n\n[资料摘要已截断]" if truncated else ""), truncated

    def _material_source_payload(self, source: MaterialContextSource) -> dict[str, object]:
        return {
            "sourceId": source.source_id,
            "sourceVersion": source.source_version,
            "displayName": source.display_name,
            "kind": source.kind,
            "documentId": source.document_id,
            "documentVersionId": source.document_version_id,
            "contextRole": source.context_role,
            "evidenceSummary": source.evidence_summary,
            "retrievalCount": source.retrieval_count,
            "truncated": source.truncated,
            "unavailable": source.unavailable,
            "unavailableReason": source.unavailable_reason,
        }

    def _to_retrieval_response(self, retrieval) -> RetrievalResponse:
        return RetrievalResponse(
            normalizedQuestion=retrieval.normalized_question,
            contextText=retrieval.context_text,
            chunks=[
                RetrievedChunkResponse(
                    documentId=chunk.document_id,
                    documentKind=chunk.document_kind,
                    chunkId=chunk.chunk_id,
                    chunkIndex=chunk.chunk_index,
                    content=chunk.content,
                    score=chunk.score,
                    rerankScore=chunk.rerank_score,
                    metadata=chunk.metadata,
                )
                for chunk in retrieval.chunks
            ],
            candidateCount=retrieval.candidate_count,
            finalCount=retrieval.final_count,
            strategy=retrieval.strategy,
        )

    def _log(self, level: int, event: str, *, task: ChatAnswerTaskRecord | None, session_id: str, question: str, retry_count: int, error_code: str | None = None) -> None:
        provenance = task.material_provenance if task else {}
        log_event(
            self.logger,
            level,
            settings=self.settings,
            event=event,
            feature="live-answer",
            action="chat",
            session_id=session_id,
            task_id=task.task_id if task else None,
            provider_name=task.provider_name if task else None,
            model_name=task.model_name if task else None,
            prompt_version=task.prompt_version if task else None,
            prompt_template_id=task.prompt_template_id if task else None,
            interview_language=provenance.get("interviewLanguage"),
            stage=event.removeprefix("chat."),
            stream_mode=task.stream_mode if task else None,
            status=task.status if task else None,
            retry_count=retry_count,
            retrieval_excerpt_count=task.retrieval_excerpt_count if task else None,
            question_hash=hashlib.sha256(question.encode("utf-8")).hexdigest()[:12],
            question_length=len(question),
            error_code=error_code,
        )
