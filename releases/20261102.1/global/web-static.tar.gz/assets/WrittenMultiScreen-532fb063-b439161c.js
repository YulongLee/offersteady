import { AccountMenu as e, AnswerWorkspace as t, ConversationMonitor as n, Logo as r, ManualQuestionComposer as i, MobileInterviewControls as a, WebAnswerToggle as o, WorkspaceDivider as s, usePrototype as c, useWebAnswerControl as l } from "./WorkspaceApp-6c6d97a4-b2deeab9.js";
import { i as u, n as d, r as f } from "./global-jsx-runtime-pOLjH0Mm.js";
import { E as p, N as m, P as ee, _ as h, x as g } from "./main-08d5d48b-1eebe5e2.js";
import { t as _ } from "./app-adapter-59d370b8-9e3afa1f.js";
var { useEffect: v, useRef: y, useState: b, useMemo: te, useLayoutEffect: ne } = u(), x = [
	{
		id: "pdf",
		label: "PDF",
		extensions: [".pdf"],
		mimeTypes: ["application/pdf"]
	},
	{
		id: "docx",
		label: "DOCX",
		extensions: [".docx"],
		mimeTypes: ["application/vnd.openxmlformats-officedocument.wordprocessingml.document"]
	},
	{
		id: "doc",
		label: "DOC",
		extensions: [".doc"],
		mimeTypes: [
			"application/msword",
			"application/doc",
			"application/vnd.ms-word"
		]
	},
	{
		id: "txt",
		label: "TXT",
		extensions: [".txt"],
		mimeTypes: ["text/plain"]
	},
	{
		id: "md",
		label: "MD",
		extensions: [".md"],
		mimeTypes: [
			"text/markdown",
			"text/x-markdown",
			"text/plain"
		]
	}
], S = {
	maxFileSizeBytes: 20 * 1024 * 1024,
	acceptedExtensions: x.flatMap((e) => e.extensions),
	acceptedMimeTypes: x.flatMap((e) => e.mimeTypes),
	label: x.map((e) => e.label).join("、")
};
S.acceptedExtensions.join(",");
//#endregion
//#region artifacts/global-written-multi-screen-20261019/web-source/packages/protocol/src/speaker.ts
var re = (e) => e.terminalState ?? (e.isFinal ? "final" : null), C = (e) => e === "final" ? 2 : +(e === "incomplete"), ie = (e, t) => {
	if (!e || e.id !== t.id) return !0;
	let n = re(e), r = re(t);
	return C(r) < C(n) || t.revision < e.revision ? !1 : t.revision > e.revision ? !0 : C(r) > C(n);
};
S.label, S.maxFileSizeBytes;
//#endregion
//#region artifacts/global-written-multi-screen-20261019/web-source/packages/protocol/src/interview-language.ts
var ae = /* @__PURE__ */ new Set([
	"zh-CN",
	"en-US",
	"ja-JP",
	"ko-KR",
	"fr-FR",
	"de-DE",
	"es-ES",
	"pt-BR",
	"it-IT",
	"ru-RU"
]), oe = {
	"zh-CN": [
		"Chinese",
		"中文",
		"zh",
		"Chinese"
	],
	"en-US": [
		"English",
		"English",
		"en",
		"English"
	],
	"ja-JP": [
		"Japanese",
		"日本語",
		"ja",
		"Japanese"
	],
	"ko-KR": [
		"Korean",
		"한국어",
		"ko",
		"Korean"
	],
	"vi-VN": [
		"Vietnamese",
		"Tiếng Việt",
		"vi",
		"Vietnamese"
	],
	"th-TH": [
		"Thai",
		"ไทย",
		"th",
		"Thai"
	],
	"id-ID": [
		"Indonesian",
		"Bahasa Indonesia",
		"id",
		"Indonesian"
	],
	"ms-MY": [
		"Malay",
		"Bahasa Melayu",
		"ms",
		"Malay"
	],
	"fil-PH": [
		"Filipino",
		"Filipino",
		"fil",
		"Filipino"
	],
	"hi-IN": [
		"Hindi",
		"हिन्दी",
		"hi",
		"Hindi"
	],
	"ar-SA": [
		"Arabic",
		"العربية",
		"ar",
		"Arabic"
	],
	"fr-FR": [
		"French",
		"Français",
		"fr",
		"French"
	],
	"de-DE": [
		"German",
		"Deutsch",
		"de",
		"German"
	],
	"es-ES": [
		"Spanish",
		"Español",
		"es",
		"Spanish"
	],
	"pt-BR": [
		"Portuguese",
		"Português",
		"pt",
		"Portuguese"
	],
	"ru-RU": [
		"Russian",
		"Русский",
		"ru",
		"Russian"
	],
	"it-IT": [
		"Italian",
		"Italiano",
		"it",
		"Italian"
	],
	"nl-NL": [
		"Dutch",
		"Nederlands",
		"nl",
		"Dutch"
	],
	"sv-SE": [
		"Swedish",
		"Svenska",
		"sv",
		"Swedish"
	],
	"da-DK": [
		"Danish",
		"Dansk",
		"da",
		"Danish"
	],
	"fi-FI": [
		"Finnish",
		"Suomi",
		"fi",
		"Finnish"
	],
	"nb-NO": [
		"Norwegian",
		"Norsk",
		"no",
		"Norwegian"
	],
	"el-GR": [
		"Greek",
		"Ελληνικά",
		"el",
		"Greek"
	],
	"pl-PL": [
		"Polish",
		"Polski",
		"pl",
		"Polish"
	],
	"cs-CZ": [
		"Czech",
		"Čeština",
		"cs",
		"Czech"
	],
	"hu-HU": [
		"Hungarian",
		"Magyar",
		"hu",
		"Hungarian"
	],
	"ro-RO": [
		"Romanian",
		"Română",
		"ro",
		"Romanian"
	],
	"bg-BG": [
		"Bulgarian",
		"Български",
		"bg",
		"Bulgarian"
	],
	"hr-HR": [
		"Croatian",
		"Hrvatski",
		"hr",
		"Croatian"
	],
	"sk-SK": [
		"Slovak",
		"Slovenčina",
		"sk",
		"Slovak"
	]
}, w = Object.keys(oe).map((e) => {
	let [t, n, r, i] = oe[e];
	return {
		locale: e,
		label: t,
		nativeLabel: n,
		asrLanguageCode: r,
		outputLanguage: i,
		tier: ae.has(e) ? "production" : "beta",
		direction: e === "ar-SA" ? "rtl" : "ltr"
	};
});
function se(e) {
	return w.find((t) => t.locale === e);
}
//#endregion
//#region artifacts/global-written-multi-screen-20261019/web-source/apps/web-global/src/context-selection.ts
var ce = (e, t) => e.filter((e) => e.ownerUserId === t && e.status !== "deleted"), le = (e) => e.status === "ready" && e.selectable !== !1, ue = (e, t) => {
	let n = new Set([
		t.resumeSourceId,
		t.jobDescriptionSourceId,
		...t.knowledgeSourceIds
	].filter(Boolean));
	return e.filter((e) => n.has(e.id));
};
u().Fragment;
//#endregion
//#region artifacts/global-written-multi-screen-20261019/web/module-src/WrittenMultiScreenActionBar.tsx
function de({ manualDraft: e, latestInterviewerQuestion: t = "", screenshotTask: n, onQuickAnswer: r, onScreenshot: i, disabled: a = !1, quickAnswerStatus: o = "idle", screenshotAnswerStatus: s = "idle", screenshotOnly: c = !1, multiScreen: l = !1, pendingScreenshots: u = [], screenshotLimit: p = 4, captureBusy: m = !1, captureMessage: ee = "", captureUnavailable: h = !1, onBatchAnswer: g, onRemoveScreenshot: _ }) {
	let v = o === "processing", y = s === "processing" || !!(n && ![
		"completed",
		"failed",
		"cancelled"
	].includes(n.stage)), b = y || m;
	return /* @__PURE__ */ f("section", {
		className: "answer-action-bar",
		"aria-label": "Interview controls",
		children: [/* @__PURE__ */ f("div", {
			className: "answer-action-buttons",
			children: [
				c ? null : /* @__PURE__ */ f("button", {
					className: "button primary action-tile",
					"aria-label": "Quick answer",
					disabled: a || v,
					title: e.trim() ? "Answer the question entered on the left" : t.trim() ? "Answer the latest interviewer question" : "Enter a question or wait for the conversation to sync",
					onClick: r,
					children: [/* @__PURE__ */ d("strong", { children: "Quick answer" }), /* @__PURE__ */ d("small", { children: e.trim() ? "Answer the entered question" : "Answer the latest interviewer question" })]
				}),
				/* @__PURE__ */ f("button", {
					className: "button ghost action-tile",
					"aria-label": l ? "Capture" : "Screen Assist",
					disabled: a || y || l && (m || h || u.length >= p),
					title: l ? "Capture the current shared screen and answer together later" : "Capture your selected shared screen and answer",
					onClick: i,
					children: [/* @__PURE__ */ d("strong", { children: l ? "Capture" : "Screen Assist" }), /* @__PURE__ */ d("small", { children: l ? "Keep this view, then scroll and capture more" : "Capture the shared screen and generate an answer" })]
				}),
				l ? /* @__PURE__ */ f("button", {
					className: "button primary action-tile",
					"aria-label": "Answer",
					disabled: a || b || u.length === 0,
					onClick: g,
					children: [/* @__PURE__ */ d("strong", { children: "Answer" }), /* @__PURE__ */ d("small", { children: "Generate one answer from all captures" })]
				}) : null
			]
		}), l ? /* @__PURE__ */ f("div", {
			className: "written-screenshot-collection",
			children: [/* @__PURE__ */ f("div", {
				className: "written-screenshot-summary",
				role: "status",
				"aria-live": "polite",
				children: [/* @__PURE__ */ d("span", { children: ee || `Captured ${u.length} / ${p}` }), m ? /* @__PURE__ */ d("small", { children: "Capturing…" }) : null]
			}), u.length > 0 ? /* @__PURE__ */ d("ol", {
				className: "written-screenshot-list",
				"aria-label": "Pending captures",
				children: u.map((e, t) => /* @__PURE__ */ f("li", { children: [/* @__PURE__ */ f("span", {
					title: e.name,
					children: ["Capture ", t + 1]
				}), /* @__PURE__ */ d("button", {
					type: "button",
					"aria-label": `Remove capture ${t + 1}`,
					disabled: a || b,
					onClick: () => _ == null ? void 0 : _(e.requestId),
					children: "×"
				})] }, e.requestId))
			}) : null]
		}) : null]
	});
}
var T = 8, E = (e) => e.replace(/\s+/g, "").replace(/[，。！？、；：,.!?;:~～…·]/g, "").trim(), fe = (e, t) => {
	let n = e.trim(), r = t.trim();
	if (!n) return r;
	if (!r) return n;
	let i = E(n), a = E(r);
	return i === a ? r.length >= n.length ? r : n : i.includes(a) ? n : a.includes(i) ? r : `${n} ${r}`;
}, pe = (e) => {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) E(n.text) && ie(t.get(n.id), n) && t.set(n.id, n);
	return [...t.values()].sort((e, t) => e.startedAtMs - t.startedAtMs || e.revision - t.revision);
}, D = (e) => {
	let t = [], n = /* @__PURE__ */ new Map();
	for (let r of pe(e)) {
		if (r.isFinal) {
			t.push(r);
			continue;
		}
		let e = `${r.sourceKind}:${r.sourceId}`, i = n.get(e);
		(!i || r.endedAtMs > i.endedAtMs || r.endedAtMs === i.endedAtMs && r.revision > i.revision) && n.set(e, r);
	}
	return {
		confirmed: t,
		activeDrafts: [...n.values()]
	};
}, O = (e) => {
	let t = D(e);
	return [...t.confirmed, ...t.activeDrafts].sort((e, t) => e.startedAtMs - t.startedAtMs || e.revision - t.revision);
}, k = (e) => {
	let t = [];
	for (let n of O(e)) {
		let e = t.at(-1), r = e ? n.startedAtMs - e.endedAtMs : Infinity, i = (e == null ? void 0 : e.sourceSegmentIds) ?? [];
		if (!(e && e.sessionId === n.sessionId && e.role === n.role && e.sourceKind === n.sourceKind && e.isFinal === n.isFinal && !e.overlap && !n.overlap && r >= -250 && r <= 700 && n.endedAtMs - e.startedAtMs <= 45e3 && i.length < T) || !e) {
			t.push({
				...n,
				sourceSegmentIds: [n.id]
			});
			continue;
		}
		t[t.length - 1] = {
			...e,
			revision: e.revision + n.revision,
			text: fe(e.text, n.text),
			transcriptConfidence: Math.min(e.transcriptConfidence, n.transcriptConfidence),
			endedAtMs: Math.max(e.endedAtMs, n.endedAtMs),
			isFinal: n.isFinal,
			...!n.isFinal && n.turnState ? { turnState: n.turnState } : {},
			...n.terminalState ? { terminalState: n.terminalState } : {},
			...n.finalizationReason ? { finalizationReason: n.finalizationReason } : {},
			...n.publishedAtMs === void 0 ? {} : { publishedAtMs: n.publishedAtMs },
			...n.performance ? { performance: n.performance } : {},
			sourceSegmentIds: [...i, n.id]
		};
	}
	return t;
}, A = (e) => e.replace(/\s+/g, " ").trim(), j = (e, t = "") => {
	var n;
	let r = k(e), i = [...r].reverse().find((e) => (e.sourceKind === "system" || e.role === "interviewer") && e.text.trim()), a = A(t);
	if (!i) return a;
	let o = ((n = [...r].reverse().find((e) => e.role === "candidate" && e.isFinal && e.endedAtMs <= i.startedAtMs)) == null ? void 0 : n.endedAtMs) ?? -Infinity, s = r.filter((e) => (e.sourceKind === "system" || e.role === "interviewer") && e.endedAtMs > o && e.endedAtMs <= i.endedAtMs), c = [...s].reverse().find((e) => e.isFinal), l = !i.isFinal && (!c || i.endedAtMs > c.endedAtMs) ? i : null, u = s.filter((e) => e.isFinal).slice(-4);
	l && !u.some((e) => e.id === l.id) && u.push(l);
	let d = u.map((e) => A(e.text)).filter(Boolean);
	return a && !d.some((e) => e.includes(a) || a.includes(e)) && d.push(a), d.join(" ").trim();
}, me = (e, t = 320, n = 420, r = 12) => {
	let i = Math.max(1, e - r), a = Math.max(25, t / i * 100), o = Math.min(75, 100 - n / i * 100);
	return a <= o ? {
		min: a,
		max: o
	} : {
		min: 42,
		max: 42
	};
}, he = (e, t = {
	min: 25,
	max: 75
}) => Math.min(t.max, Math.max(t.min, e)), ge = (e) => `offersteady.live.${e}.split.v1`, _e = (e) => {
	if (!e) return 42;
	try {
		let t = JSON.parse(e);
		return t.version !== 1 || typeof t.ratio != "number" || !Number.isFinite(t.ratio) || t.ratio < 25 || t.ratio > 75 ? 42 : t.ratio;
	} catch {
		return 42;
	}
}, ve = (e) => JSON.stringify({
	version: 1,
	ratio: he(e)
}), ye = (e = 42) => ({
	splitRatio: he(e),
	viewingAnswerId: null,
	newAnswerAvailable: !1
}), be = (e, t, n) => t && n && t !== n && e.viewingAnswerId ? {
	...e,
	newAnswerAvailable: !0
} : e, M = /* @__PURE__ */ new Set([
	"completed",
	"failed",
	"cancelled"
]), N = (e, t) => e ? t && t.length > e.length ? t : e : t, xe = (e, t) => {
	if (!e) return t;
	if (!t) return e;
	if (e.id !== t.id) return t.updatedAtMs >= e.updatedAtMs ? t : e;
	let n = M.has(e.status), r = M.has(t.status), i = t.revision > e.revision || t.revision === e.revision && r && !n || t.revision === e.revision && r === n && t.updatedAtMs >= e.updatedAtMs ? t : e, a = N(e.partialText, t.partialText), o = N(e.completedText, t.completedText);
	return {
		...i,
		...a ? { partialText: a } : {},
		...o ? { completedText: o } : {},
		...e.quickAnswerCompleted || t.quickAnswerCompleted ? { quickAnswerCompleted: !0 } : {},
		updatedAtMs: Math.max(e.updatedAtMs, t.updatedAtMs)
	};
}, Se = (e, t, n, r = !1) => {
	let i = n ? e : t, a = n ? t : e;
	return {
		...a,
		...i,
		...e.quickAnswerCompleted || t.quickAnswerCompleted ? { quickAnswerCompleted: !0 } : {},
		advice: {
			...a.advice,
			...i.advice,
			detail: n || r ? N(e.advice.detail, t.advice.detail) ?? i.advice.detail : i.advice.detail
		}
	};
}, P = (e, t, n = {}) => {
	var r;
	let i = n.preferIncomingTask && t.activeAnswerTask && ((r = e.activeAnswerTask) == null ? void 0 : r.id) !== t.activeAnswerTask.id ? t.activeAnswerTask : xe(e.activeAnswerTask, t.activeAnswerTask), a = new Map(e.questions.map((e) => [e.id, e])), o = new Set(t.questions.map((e) => e.id)), s = e.activeAnswerTask, c = t.activeAnswerTask, l = !!(s && c && s.id === c.id), u = !!(s && M.has(s.status)), d = !!(c && M.has(c.status)), f = s && (i == null ? void 0 : i.id) === s.id && (!c || c.id !== s.id || s.revision > c.revision || u && !d || s.revision === c.revision && u === d && s.updatedAtMs > c.updatedAtMs) ? (s == null ? void 0 : s.questionId) ?? null : null, p = l && !(d && !u) ? (s == null ? void 0 : s.questionId) ?? null : null, m = t.questions.map((e) => {
		let t = a.get(e.id);
		return t ? Se(t, e, e.id === f, e.id === p) : e;
	}), ee = e.questions.filter((e) => !o.has(e.id)), h = [...m, ...ee];
	if (i) {
		let e = h.findIndex((e) => e.id === i.questionId);
		e > 0 && h.unshift(...h.splice(e, 1));
	}
	return {
		questions: h,
		activeAnswerTask: i
	};
}, Ce = (e) => e.replace(/\s+/g, "").length > 0, we = (e, t) => {
	var n, r, i;
	let a = e.transcripts.some((e) => e.sessionId !== t) || !!(e.pendingQuestion && e.pendingQuestion.sessionId !== t) || !!(e.autoAnswerQuestion && e.autoAnswerQuestion.sessionId !== t) || !!(e.degradation && e.degradation.sessionId !== t);
	return {
		...e,
		transcripts: e.transcripts.filter((e) => e.sessionId === t),
		pendingQuestion: ((n = e.pendingQuestion) == null ? void 0 : n.sessionId) === t ? e.pendingQuestion : null,
		autoAnswerQuestion: ((r = e.autoAnswerQuestion) == null ? void 0 : r.sessionId) === t ? e.autoAnswerQuestion : null,
		degradation: ((i = e.degradation) == null ? void 0 : i.sessionId) === t ? e.degradation : null,
		runtimeNotice: a ? null : e.runtimeNotice
	};
}, Te = (e, t, n) => {
	let r = n ? we(e, n) : e, i = n ? we(t, n) : t, a = new Map(r.transcripts.filter((e) => Ce(e.text)).map((e) => [e.id, e]));
	for (let e of i.transcripts) Ce(e.text) && ie(a.get(e.id), e) && a.set(e.id, e);
	return {
		...i,
		transcripts: O([...a.values()])
	};
}, Ee = 6e4, De = (e, t) => ke(e) ? Ee : t <= 0 ? 0 : [
	2e3,
	4e3,
	8e3,
	15e3
][Math.min(t - 1, 3)], Oe = (e, t) => t === "stream-snapshot" ? 0 : Math.max(0, e), ke = (e) => e === 401 || e === 403 || e === 404 || e === 409 || e === 410;
//#endregion
//#region \0@oxc-project+runtime@0.137.0/helpers/esm/typeof.js
function F(e) {
	"@babel/helpers - typeof";
	return F = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(e) {
		return typeof e;
	} : function(e) {
		return e && typeof Symbol == "function" && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
	}, F(e);
}
//#endregion
//#region \0@oxc-project+runtime@0.137.0/helpers/esm/toPrimitive.js
function Ae(e, t) {
	if (F(e) != "object" || !e) return e;
	var n = e[Symbol.toPrimitive];
	if (n !== void 0) {
		var r = n.call(e, t || "default");
		if (F(r) != "object") return r;
		throw TypeError("@@toPrimitive must return a primitive value.");
	}
	return (t === "string" ? String : Number)(e);
}
//#endregion
//#region \0@oxc-project+runtime@0.137.0/helpers/esm/toPropertyKey.js
function I(e) {
	var t = Ae(e, "string");
	return F(t) == "symbol" ? t : t + "";
}
//#endregion
//#region \0@oxc-project+runtime@0.137.0/helpers/esm/defineProperty.js
function L(e, t, n) {
	return (t = I(t)) in e ? Object.defineProperty(e, t, {
		value: n,
		enumerable: !0,
		configurable: !0,
		writable: !0
	}) : e[t] = n, e;
}
//#endregion
//#region artifacts/global-written-multi-screen-20261019/web-source/apps/web-global/src/live-session-leader.ts
var je = class {
	constructor(e, t, n = Date.now) {
		L(this, "channel", void 0), L(this, "pageId", void 0), L(this, "now", void 0), L(this, "leader", !1), L(this, "epoch", 0), L(this, "leaderPageId", null), L(this, "leaderEpoch", 0), L(this, "lastLeaderAt", 0), L(this, "eligible", !0), L(this, "electionTimer", null), L(this, "heartbeatTimer", null), L(this, "watchdogTimer", null), L(this, "callbacks", null), L(this, "onMessage", (e) => {
			let t = e.data;
			if (!(!t || t.pageId === this.pageId)) {
				if (t.type === "probe") {
					this.leader && !this.eligible ? (this.post("release"), this.setLeader(!1), this.leaderPageId === this.pageId && (this.leaderPageId = null)) : this.eligible && this.leader && this.post("leader");
					return;
				}
				if (t.type === "release") {
					this.eligible && !this.leader && t.epoch >= this.leaderEpoch && (this.leaderPageId = null, this.leaderEpoch = t.epoch, this.lastLeaderAt = 0, this.becomeLeader());
					return;
				}
				if (t.type === "leader") {
					if (this.eligible && this.leader && this.pageId < t.pageId) {
						this.post("leader");
						return;
					}
					(!this.leader || t.pageId < this.pageId || t.epoch > this.epoch) && (this.leaderPageId = t.pageId, this.leaderEpoch = t.epoch, this.lastLeaderAt = this.now(), this.setLeader(!1));
					return;
				}
				if (t.type === "state") {
					var n;
					if (t.pageId !== this.leaderPageId || t.epoch < this.leaderEpoch || !t.state) return;
					this.lastLeaderAt = this.now(), (n = this.callbacks) == null || n.onState(t.state);
				}
			}
		}), this.channel = e, this.pageId = t, this.now = n;
	}
	start(e, t = !0) {
		this.callbacks = e, this.eligible = t, this.channel.addEventListener("message", this.onMessage), this.eligible && this.requestElection(), this.watchdogTimer = window.setInterval(() => {
			this.eligible && !this.leader && this.now() - this.lastLeaderAt > 5e3 && this.becomeLeader();
		}, 1e3);
	}
	setEligible(e) {
		if (this.eligible !== e) {
			if (this.eligible = e, !e) {
				this.electionTimer !== null && (window.clearTimeout(this.electionTimer), this.electionTimer = null), !this.leader && this.leaderPageId === this.pageId && (this.leaderPageId = null);
				return;
			}
			this.leader || (this.lastLeaderAt = 0, this.requestElection());
		}
	}
	publishState(e) {
		this.leader && this.post("state", e);
	}
	isLeader() {
		return this.leader;
	}
	stop() {
		this.leader && this.post("release"), this.setLeader(!1), this.electionTimer !== null && window.clearTimeout(this.electionTimer), this.watchdogTimer !== null && window.clearInterval(this.watchdogTimer), this.channel.removeEventListener("message", this.onMessage), this.channel.close(), this.callbacks = null;
	}
	becomeLeader() {
		this.eligible && (this.epoch = Math.max(this.epoch + 1, this.now()), this.leaderPageId = this.pageId, this.leaderEpoch = this.epoch, this.lastLeaderAt = this.now(), this.setLeader(!0), this.post("leader"), this.heartbeatTimer !== null && window.clearInterval(this.heartbeatTimer), this.heartbeatTimer = window.setInterval(() => this.post("leader"), 2e3));
	}
	requestElection() {
		this.eligible && (this.post("probe"), this.electionTimer !== null && window.clearTimeout(this.electionTimer), this.electionTimer = window.setTimeout(() => {
			this.electionTimer = null, this.eligible && this.now() - this.lastLeaderAt >= 120 && this.becomeLeader();
		}, 120));
	}
	setLeader(e) {
		var t;
		this.leader !== e && (this.leader = e, !e && this.heartbeatTimer !== null && (window.clearInterval(this.heartbeatTimer), this.heartbeatTimer = null), (t = this.callbacks) == null || t.onLeadershipChange(e));
	}
	post(e, t) {
		this.channel.postMessage({
			type: e,
			pageId: this.pageId,
			epoch: this.epoch,
			sentAt: this.now(),
			...t ? { state: t } : {}
		});
	}
}, Me = (e, t) => typeof BroadcastChannel == "function" ? new je(new BroadcastChannel(e), t) : null, Ne = 15e3, Pe = (e, t) => (e ?? 0) >= t - 5e3, Fe = ({ apply: e, isFirstVisible: t, delayMs: n = 100, schedule: r = (e, t) => window.setTimeout(e, t), cancel: i = (e) => window.clearTimeout(e) }) => {
	let a = null, o = null, s = !1, c = () => {
		if (o !== null && i(o), o = null, a === null) return;
		let t = a;
		a = null, e(t);
	};
	return {
		push: (l, u = !1) => {
			if (!s && t(l)) {
				s = !0, o !== null && i(o), o = null, a = null, e(l);
				return;
			}
			a = l, u ? c() : o === null && (o = r(c, n));
		},
		flush: c,
		dispose: () => {
			o !== null && i(o), o = null, a = null;
		}
	};
}, Ie = [{
	id: "douyin",
	label: "抖音号",
	account: "面试稳AI助手"
}, {
	id: "xiaohongshu",
	label: "小红书号",
	account: "面试稳AI助手"
}], Le = "Use only the current screenshot. Identify the question, code, or system-design task shown and provide a directly usable answer in English. Do not use the live conversation, the interviewer's latest question, or other session context.\n", Re = (e) => e === "written" ? h.writtenExams : h.app, ze = {
	id: "empty-live-question",
	askedAt: "等待中",
	text: "等待面试问题",
	input: "manual",
	status: "listening",
	advice: {
		outline: [],
		detail: "当前还没有来自后端的面试问题记录。",
		sourceTypes: [],
		inference: "",
		uncertain: !0,
		provenance: {
			selectionRevision: 0,
			usedSources: []
		}
	}
}, Be = "未能识别到面试官的问题", Ve = (e) => {
	var t;
	return j(e.transcripts, ((t = e.pendingQuestion) == null ? void 0 : t.text) ?? "");
};
function He() {
	let e = "(min-width: 721px)", [t, n] = b(() => typeof window.matchMedia == "function" ? window.matchMedia(e).matches : window.innerWidth > 720);
	return v(() => {
		var t;
		if (typeof window.matchMedia != "function") {
			let e = () => n(window.innerWidth > 720);
			return window.addEventListener("resize", e), () => window.removeEventListener("resize", e);
		}
		let r = window.matchMedia(e), i = () => n(r.matches);
		return i(), (t = r.addEventListener) == null || t.call(r, "change", i), () => {
			var e;
			return (e = r.removeEventListener) == null ? void 0 : e.call(r, "change", i);
		};
	}, []), t;
}
function Ue() {
	var u, te, ne, x, S, re, C, ie, ae, oe;
	let { id: w = "demo" } = ee(), { state: T, setState: E } = c(), fe = m(), pe = ge(w), [D, O] = b(() => {
		var e;
		return ye(_e(typeof ((e = window.sessionStorage) == null ? void 0 : e.getItem) == "function" ? window.sessionStorage.getItem(pe) : null));
	}), [k, A] = b({
		manualDraft: "",
		screenshotTask: null,
		quickAnswerStatus: "idle",
		quickAnswerMessage: "",
		screenshotAnswerStatus: "idle"
	}), [j, M] = b(""), [N, xe] = b(!1), [Se, Ce] = b([]), [Ee, F] = b(!1), [Ae, I] = b(""), [L, je] = b(!1), [Ue, We] = b(null), [Ge, Ke] = b(""), R = y([]), z = y(null), B = y(0), qe = y(!1), V = y(!1), Je = y([]), Ye = y(null), Xe = y(/* @__PURE__ */ new Set()), H = y(/* @__PURE__ */ new Set()), [Ze, Qe] = b(!1), [$e, et] = b(""), [U, tt] = b("claiming"), [nt, rt] = b(null), [it, at] = b(0), [ot, st] = b(null), [ct, lt] = b(!1), [ut, dt] = b(!1), [ft, pt] = b({
		min: 25,
		max: 75
	}), [mt, ht] = b("answer"), gt = y(null), W = He(), _t = y(/* @__PURE__ */ new Set()), vt = y(/* @__PURE__ */ new Set()), yt = y((u = T.questions[0]) == null ? void 0 : u.id), G = y(null), K = y(null), bt = y(() => void 0), q = y(null), J = y(/* @__PURE__ */ new Set()), xt = y(/* @__PURE__ */ new Set()), Y = y(!1), St = y(Date.now()), Ct = y(((te = globalThis.crypto) == null || (ne = te.randomUUID) == null ? void 0 : ne.call(te)) ?? `page-${Date.now()}-${Math.random().toString(36).slice(2)}`), X = T.interviews.find((e) => e.id === w), Z = (X == null ? void 0 : X.sessionMode) === "written", wt = l(w, Z), Tt = y(!1), Et = (X == null ? void 0 : X.title) ?? "本场面试", Dt = (X == null ? void 0 : X.interviewAudioMode) ?? "computer", Ot = (X == null ? void 0 : X.interviewLanguage) ?? "en-US", kt = ((x = se(Ot)) == null ? void 0 : x.nativeLabel) ?? Ot, At = T.questions[0] ?? ze, Q = k.screenshotTask, $ = (e) => A((t) => ({
		...t,
		screenshotTask: e,
		screenshotAnswerStatus: e ? e.stage === "completed" ? "success" : e.stage === "failed" ? "failed" : e.stage === "cancelled" ? "cancelled" : "processing" : t.screenshotAnswerStatus ?? "idle"
	})), jt = (e) => {
		for (let t of e) _.cancelDesktopShortcutScreenshot(t.requestId).catch(() => void 0);
	}, Mt = (e = !0) => {
		var t, n;
		B.current += 1, (t = z.current) == null || t.abort(), z.current = null, V.current && ((n = G.current) == null || n.abort()), V.current = !1, jt([...R.current, ...Je.current]), R.current = [], Je.current = [], e && (Ce([]), F(!1), I(""), je(!1));
	};
	v(() => (qe.current = !1, xe(!1), () => Mt(!1)), [w]), v(() => {
		U === "replaced" && Mt();
	}, [U]), v(() => {
		if (!Z) return;
		let e = new AbortController();
		return We(null), Ke(""), (async () => {
			try {
				if (!_.getScreenshotCapturePolicy) throw Error("Multi-screen capture is unavailable. Try again shortly.");
				let t = await _.getScreenshotCapturePolicy(e.signal);
				if (!Number.isInteger(t.maxImagesPerTask) || t.maxImagesPerTask < 1) throw Error("Capture limits could not be loaded. Refresh and try again.");
				e.signal.aborted || We(Math.min(4, t.maxImagesPerTask));
			} catch (t) {
				e.signal.aborted || Ke(t instanceof Error ? t.message : "Capture settings could not be loaded. Refresh and try again.");
			}
		})(), () => e.abort();
	}, [w, Z]);
	let Nt = T.contextSelections[w] ?? {
		sessionId: w,
		resumeSourceId: null,
		jobDescriptionSourceId: null,
		knowledgeSourceIds: [],
		revision: 0,
		confirmedAtMs: null
	}, Pt = ue(ce(T.librarySources, T.account.id).filter(le), Nt);
	v(() => {
		var e;
		typeof ((e = window.sessionStorage) == null ? void 0 : e.setItem) == "function" && window.sessionStorage.setItem(pe, ve(D.splitRatio));
	}, [pe, D.splitRatio]), v(() => {
		if (!W) return;
		let e = () => {
			var e;
			let t = ((e = gt.current) == null ? void 0 : e.getBoundingClientRect().width) ?? 0;
			if (!t) return;
			let n = t < 900 ? me(t, 240, 300) : me(t);
			pt(n), O((e) => ({
				...e,
				splitRatio: he(e.splitRatio, n)
			}));
		};
		e(), window.addEventListener("resize", e);
		let t = typeof ResizeObserver == "function" ? new ResizeObserver(e) : null;
		return gt.current && (t == null || t.observe(gt.current)), () => {
			window.removeEventListener("resize", e), t == null || t.disconnect();
		};
	}, [W]), v(() => {
		var e;
		let t = (e = T.questions[0]) == null ? void 0 : e.id;
		!W && yt.current && t && yt.current !== t && ht("answer"), O((e) => be(e, yt.current, t)), yt.current = t;
	}, [W, T.questions]), v(() => {
		!W && T.activeAnswerTask && ["pending", "generating"].includes(T.activeAnswerTask.status) && ht("answer");
	}, [
		W,
		(S = T.activeAnswerTask) == null ? void 0 : S.id,
		(re = T.activeAnswerTask) == null ? void 0 : re.status
	]), v(() => () => {
		var e, t;
		(e = G.current) == null || e.abort(), (t = K.current) == null || t.abort();
	}, []), v(() => {
		E((e) => {
			var t;
			return {
				...e,
				speaker: we(e.speaker, w),
				activeAnswerTask: ((t = e.activeAnswerTask) == null ? void 0 : t.interviewId) === w ? e.activeAnswerTask : null
			};
		});
	}, [w, E]), v(() => {
		let e = new AbortController(), t = !1, n = !1, r = async () => {
			if (!(t || n || document.visibilityState !== "visible")) {
				n = !0;
				try {
					let n = await g((e) => _.loadInterviewWorkspace(w, e), e.signal);
					if (t) return;
					E((e) => ({
						...e,
						...P({
							questions: e.questions,
							activeAnswerTask: e.activeAnswerTask
						}, {
							questions: n.questions.filter((e) => !H.current.has(e.id)),
							activeAnswerTask: n.activeAnswerTask && H.current.has(n.activeAnswerTask.id) ? null : n.activeAnswerTask
						})
					}));
				} catch {} finally {
					n = !1;
				}
			}
		};
		r();
		let i = () => {
			document.visibilityState === "visible" && r();
		};
		return document.addEventListener("visibilitychange", i), window.addEventListener("focus", i), () => {
			t = !0, e.abort(), document.removeEventListener("visibilitychange", i), window.removeEventListener("focus", i);
		};
	}, [w, E]), v(() => {
		if (U === "replaced") return;
		let e = new AbortController(), t = !1, n = async () => {
			try {
				let n = await g((e) => _.getInterviewIdleStatus(w, e), e.signal);
				if (t) return;
				st(n), n.state === "ended" && (E((e) => ({
					...e,
					captureState: "ready",
					interviews: e.interviews.map((e) => e.id === w ? {
						...e,
						status: "ended"
					} : e)
				})), fe(h.review(w), { replace: !0 }));
			} catch {}
		};
		n();
		let r = window.setInterval(() => void n(), 15e3);
		return () => {
			t = !0, e.abort(), window.clearInterval(r);
		};
	}, [
		w,
		fe,
		U,
		E
	]), v(() => {
		if (U === "replaced") return;
		let e = new AbortController(), t = !1, n = !1, r = async () => {
			if (!(t || n || Y.current || document.visibilityState !== "visible")) {
				n = !0;
				try {
					let n = await g((e) => _.loadDesktopShortcutScreenshotUpdates(w, e), e.signal);
					if (t || n.length === 0) return;
					let r = n[n.length - 1], i = J.current.has(r.requestId);
					(r.status === "requested" || r.status === "processing") && !i ? (q.current = r.requestId, $(r.screenshotTask)) : i || (J.current.add(r.requestId), q.current === r.requestId && (q.current = null), r.status === "completed" ? A((e) => ({
						...e,
						screenshotTask: null,
						screenshotAnswerStatus: "success"
					})) : $(r.screenshotTask));
					let a = n.flatMap((e) => e.result && !H.current.has(e.result.task.id) && !H.current.has(e.result.question.id) ? [e.result] : []);
					E((e) => {
						if (a.length === 0) return e;
						let t = a.reduce((e, t) => t.task.updatedAtMs > e.task.updatedAtMs ? t : e);
						return {
							...e,
							...P({
								questions: e.questions,
								activeAnswerTask: e.activeAnswerTask
							}, {
								questions: a.map((e) => e.question),
								activeAnswerTask: t.task
							})
						};
					});
				} catch {} finally {
					n = !1;
				}
			}
		};
		r();
		let i = window.setInterval(() => void r(), Ne);
		return () => {
			t = !0, e.abort(), window.clearInterval(i);
		};
	}, [
		w,
		U,
		E
	]), v(() => {
		let e = !1, t = null, n = null, r = null, i = 0, a = null, o = 0, s = !1, c = !1, l = !1, u = !1, d = null, f = new AbortController(), p = Me(`offersteady:live-session:${T.account.id}:${w}`, Ct.current), m = p === null, ee = (e) => {
			if (typeof e == "object" && e && "status" in e && typeof e.status == "number") return e.status;
			let t = e instanceof Error ? e.message.match(/[（(](\d{3})[）)]/) : null;
			return t ? Number(t[1]) : null;
		}, h = () => {
			var n, r;
			e || (e = !0, Y.current = !1, tt("replaced"), M(""), f.abort(), d == null || d.abort(), (n = K.current) == null || n.abort(), (r = G.current) == null || r.abort(), a !== null && window.clearTimeout(a), t !== null && window.clearInterval(t));
		}, v = (t, n = !0) => {
			if (e) return;
			let r = t.shortcutScreenshotUpdate, i = r == null ? void 0 : r.notificationId;
			if (r && i && !xt.current.has(i) && !J.current.has(r.requestId) && Pe(r.acceptedAtMs, St.current) && (xt.current.add(i), q.current = r.requestId, $(r.screenshotTask)), r && r.acceptedAtMs === void 0) {
				let e = J.current.has(r.requestId);
				(r.status === "requested" || r.status === "processing") && !e ? (q.current = r.requestId, $(r.screenshotTask)) : e || (J.current.add(r.requestId), q.current === r.requestId && (q.current = null), r.status === "completed" ? A((e) => ({
					...e,
					screenshotTask: null,
					screenshotAnswerStatus: "success"
				})) : r.status === "cancelled" ? A((e) => ({
					...e,
					screenshotTask: null,
					screenshotAnswerStatus: "cancelled"
				})) : $(r.screenshotTask));
			}
			E((e) => {
				let n = [t.answerUpdate, r == null ? void 0 : r.result].filter((e) => !!e && !H.current.has(e.task.id) && !H.current.has(e.question.id)), i = n.length > 0 ? n.reduce((e, t) => t.task.updatedAtMs > e.task.updatedAtMs ? t : e) : null, a = i ? P({
					questions: e.questions,
					activeAnswerTask: e.activeAnswerTask
				}, {
					questions: n.map((e) => e.question),
					activeAnswerTask: i.task
				}) : {
					questions: e.questions,
					activeAnswerTask: e.activeAnswerTask
				};
				return {
					...e,
					...a,
					speaker: Te(e.speaker, t.speaker, w),
					...t.captureState ? { captureState: t.captureState } : {}
				};
			}), n && (p == null || p.publishState(t));
		}, y = async () => {
			if (!m) return !1;
			try {
				let e = Date.now();
				if (!n || e - i >= 3e4) {
					let t = await g((e) => _.getDesktopDeviceBinding(w, e));
					t != null && t.bindingId && (n = t.bindingId), i = e;
				}
				let t = await g((e) => _.sendDesktopSessionHeartbeat({
					interviewId: w,
					bindingId: n,
					page: "live",
					pageInstanceId: Ct.current
				}, e));
				return t.pageInstanceId !== Ct.current || t.leaseGeneration < 1 ? (h(), !1) : (r = t.leaseGeneration, tt("active"), !0);
			} catch (e) {
				return ke(ee(e)) ? (h(), !1) : (n = null, !1);
			}
		}, b = async () => {
			if (!m || u || e || document.visibilityState !== "visible" || r === null) return !1;
			u = !0;
			try {
				return v(await g((e) => _.loadRealtimeSession(w, e, {
					pageInstanceId: Ct.current,
					leaseGeneration: r
				}))), !0;
			} catch {
				return !1;
			} finally {
				u = !1;
			}
		}, te = (t = null) => {
			if (e || f.signal.aborted) return;
			a !== null && window.clearTimeout(a), s = ke(t);
			let n = De(t, o);
			o += 1, a = window.setTimeout(() => {
				a = null, s = !1, ne();
			}, n);
		}, ne = async () => {
			if (!m || c || e || f.signal.aborted || r === null) return;
			let t = r, n = new AbortController();
			d = n;
			let i = () => n.abort();
			f.signal.addEventListener("abort", i, { once: !0 }), c = !0;
			try {
				await g((e) => _.subscribeRealtimeSession(w, (e, t) => {
					(t == null ? void 0 : t.type) === "snapshot" && (l = !0, Y.current = !0, s = !1, o = Oe(o, "stream-snapshot"), a !== null && (window.clearTimeout(a), a = null)), v(e);
				}, e, {
					pageInstanceId: Ct.current,
					leaseGeneration: t
				}), n.signal), l = !1, Y.current = !1, !e && !f.signal.aborted && te();
			} catch (t) {
				if (e || f.signal.aborted) return;
				l = !1, Y.current = !1;
				let n = ee(t);
				if (ke(n)) {
					var u;
					(u = window.sessionStorage) == null || u.removeItem(`offersteady:realtime-cursor:${w}`), n === 409 || n === 410 ? h() : (M("当前面试会话已失效，请从面试首页重新进入。"), fe(Re(X == null ? void 0 : X.sessionMode), { replace: !0 }));
					return;
				}
				await b() && (o = Oe(o, "fallback-snapshot")), te(n);
			} finally {
				c = !1, f.signal.removeEventListener("abort", i), d === n && (d = null);
			}
		};
		p == null || p.start({
			onLeadershipChange: (e) => {
				if (m = e, !e) {
					l = !1, Y.current = !1, d == null || d.abort(), d = null, a !== null && (window.clearTimeout(a), a = null);
					return;
				}
				y().then((e) => {
					e && ne();
				});
			},
			onState: (e) => {
				l = !0, Y.current = !0, v(e, !1);
			}
		}, document.visibilityState === "visible"), t = window.setInterval(() => void y(), 15e3);
		let x = () => {
			e || !m || document.visibilityState !== "visible" || (y(), !s && !l && !c && (a !== null && (window.clearTimeout(a), a = null), o = 0, ne()));
		}, S = () => {
			p == null || p.setEligible(document.visibilityState === "visible"), document.visibilityState === "visible" && x();
		}, re = () => p == null ? void 0 : p.setEligible(!1), C = () => {
			p == null || p.setEligible(document.visibilityState === "visible"), document.visibilityState === "visible" && x();
		};
		return document.addEventListener("visibilitychange", S), window.addEventListener("pagehide", re), window.addEventListener("pageshow", C), window.addEventListener("focus", x), window.addEventListener("online", x), m && y().then((t) => {
			!t || e || ne();
		}), () => {
			e = !0, Y.current = !1, f.abort(), d == null || d.abort(), a !== null && window.clearTimeout(a), t !== null && window.clearInterval(t), p == null || p.stop(), document.removeEventListener("visibilitychange", S), window.removeEventListener("pagehide", re), window.removeEventListener("pageshow", C), window.removeEventListener("focus", x), window.removeEventListener("online", x);
		};
	}, [
		w,
		fe,
		it,
		E,
		T.account.id
	]);
	let Ft = {
		...At.advice,
		detail: Pt.length ? At.advice.detail : "当前没有选择个人资料。请使用通用结构组织回答，并只补充你能够核对的真实经历、职责和结果。",
		sourceTypes: Pt.map((e) => e.kind === "resume" ? "简历" : e.kind === "jd" ? "JD" : "知识库"),
		inference: "",
		uncertain: Pt.length === 0,
		provenance: {
			selectionRevision: Nt.revision,
			usedSources: Pt.map((e) => ({
				sourceId: e.id,
				sourceVersion: e.version,
				displayName: e.displayName,
				kind: e.kind
			}))
		}
	}, It = async () => {
		try {
			let e = await _.loadState(void 0, { force: !0 });
			E((t) => ({
				...t,
				billing: e.billing
			}));
		} catch {}
	}, Lt = (e, t) => ({
		id: `answer:${e.id}:${Date.now()}`,
		interviewId: w,
		userId: T.account.id,
		billingUsageId: t,
		questionId: e.id,
		question: e.text,
		revision: 1,
		status: "generating",
		partialText: "正在整理回答结构…",
		updatedAtMs: Date.now()
	}), Rt = (e, t, n = "manual") => ({
		...At,
		id: t,
		text: e,
		input: n,
		askedAt: "Just now",
		status: "generating",
		advice: {
			...Ft,
			detail: "正在调用当前对话模型生成回答…",
			outline: [],
			inference: "",
			uncertain: Pt.length === 0
		}
	}), zt = (e, t = "回答生成失败，请稍后重试。") => ({
		...e,
		status: "failed",
		advice: {
			...e.advice,
			outline: [],
			detail: e.quickAnswerCompleted ? e.advice.detail : t,
			inference: "",
			uncertain: !0
		}
	}), Bt = async (e, t, n) => {
		let r = e.trim();
		if (!r) return;
		let i = (n == null ? void 0 : n.clickedAtMs) ?? Date.now(), a = wt.enabledRef.current, o = new AbortController(), s = (n == null ? void 0 : n.triggerMode) === "auto" ? `auto:${w}:${n.questionId}:${a ? "web" : "standard"}` : `manual:${w}:${r}:${a ? "web" : "standard"}`;
		if (_t.current.has(s)) return;
		_t.current.add(s), M(""), A((e) => ({
			...e,
			quickAnswerStatus: "processing",
			quickAnswerMessage: ""
		}));
		let c = t ?? `manual-pending-${Date.now()}`, l = Rt(r, c, (n == null ? void 0 : n.triggerMode) === "auto" ? "desktop-audio" : "manual"), u = {
			id: `pending:${c}`,
			interviewId: w,
			userId: T.account.id,
			billingUsageId: `pending:${c}`,
			questionId: c,
			question: r,
			revision: 1,
			status: "generating",
			partialText: "正在调用当前对话模型生成回答…",
			clickedAtMs: i,
			updatedAtMs: Date.now()
		};
		E((e) => ({
			...e,
			questions: t ? e.questions.map((e) => e.id === t ? l : e) : [l, ...e.questions],
			activeAnswerTask: u
		})), A((e) => ({
			...e,
			manualDraft: ""
		})), O((e) => ({
			...e,
			viewingAnswerId: null,
			newAnswerAvailable: !1
		}));
		let d, f, p = Fe({
			apply: (e) => {
				if (o.signal.aborted) return;
				f = e.result, E((t) => ({
					...t,
					...P({
						questions: t.questions.filter((t) => t.id !== c && t.id !== e.result.question.id),
						activeAnswerTask: t.activeAnswerTask
					}, {
						questions: [e.result.question],
						activeAnswerTask: e.result.task
					}, { preferIncomingTask: !0 })
				}));
				let t = e.result.task.partialText ?? e.result.task.completedText ?? "";
				if (e.event.type === "chunk" && t.trim() && e.result.task.clickedAtMs && _.acknowledgeAnswerFirstRender) {
					let n = () => {
						var n;
						return (n = _.acknowledgeAnswerFirstRender) == null ? void 0 : n.call(_, {
							interviewId: w,
							taskId: e.result.task.id,
							clickedAtMs: e.result.task.clickedAtMs,
							...e.event.receivedAtMs === void 0 ? {} : { browserEventReceiveAtMs: e.event.receivedAtMs },
							browserRenderAtMs: Date.now(),
							renderedTextLength: t.length,
							timing: e.event.timing
						});
					};
					typeof requestAnimationFrame == "function" ? requestAnimationFrame(() => requestAnimationFrame(n)) : window.setTimeout(n, 0);
				}
			},
			isFirstVisible: (e) => {
				var t;
				return e.event.type === "chunk" && !!((t = e.event.chunk) != null && t.text.trim());
			}
		});
		try {
			var m;
			(m = K.current) == null || m.abort(), K.current = o, Tt.current = a;
			let e = await g((e) => _.submitManualAnswer({
				interviewId: w,
				question: r,
				idempotencyKey: s,
				...n,
				clickedAtMs: i,
				webSearchEnabled: a
			}, e, (e) => {
				if (o.signal.aborted) return;
				d ??= e.event.timing;
				let t = d && !e.event.timing ? {
					...e,
					event: {
						...e.event,
						timing: d
					}
				} : e;
				p.push(t, [
					"quick-completed",
					"completed",
					"failed",
					"cancelled"
				].includes(e.event.type));
			}), o.signal);
			if (o.signal.aborted) return;
			p.flush(), E((t) => ({
				...t,
				...P({
					questions: t.questions.filter((t) => t.id !== c && t.id !== e.question.id),
					activeAnswerTask: t.activeAnswerTask
				}, {
					questions: [e.question],
					activeAnswerTask: e.task
				}, { preferIncomingTask: !0 })
			})), A((t) => ({
				...t,
				quickAnswerStatus: e.task.status === "failed" ? "failed" : e.task.status === "completed" ? "success" : "processing",
				quickAnswerMessage: e.task.status === "failed" ? e.task.partialText ?? "快答失败，可重试" : ""
			})), e.task.status === "completed" && It();
		} catch (e) {
			if (e instanceof DOMException && e.name === "AbortError" || e instanceof Error && e.message === "请求已取消") return;
			p.flush();
			let t = e instanceof Error ? e.message : "回答生成失败，请稍后重试。";
			M(t), A((e) => ({
				...e,
				quickAnswerStatus: "failed",
				quickAnswerMessage: t
			}));
			let n = f == null ? void 0 : f.question.id;
			E((e) => ({
				...e,
				questions: e.questions.map((e) => e.id === c || e.id === n ? zt(e, t) : e),
				activeAnswerTask: e.activeAnswerTask && (e.activeAnswerTask.questionId === c || e.activeAnswerTask.questionId === n) ? {
					...e.activeAnswerTask,
					status: "failed",
					partialText: e.activeAnswerTask.quickAnswerCompleted ? e.activeAnswerTask.partialText ?? (f == null ? void 0 : f.question.advice.detail) ?? "" : t,
					updatedAtMs: Date.now()
				} : e.activeAnswerTask
			}));
		} finally {
			p.dispose(), K.current === o && (K.current = null, Tt.current = !1), _t.current.delete(s);
		}
	};
	v(() => {
		let e = T.speaker.autoAnswerQuestion, t = (X == null ? void 0 : X.autoAnswerEnabledAtMs) ?? null, n = !!(T.activeAnswerTask && ["pending", "generating"].includes(T.activeAnswerTask.status));
		!(X != null && X.autoAnswerEnabled) || !t || !e || (e.createdAtMs ?? 0) < t || e.answerTaskId || e.state !== "auto-confirmed" || T.speaker.mode !== "dual-channel" || !["capturing", "reconnecting"].includes(T.captureState) || U !== "active" || n || vt.current.has(e.id) || (vt.current.add(e.id), Bt(e.text, void 0, {
			questionId: e.id,
			questionRevision: e.revision,
			clickedAtMs: Date.now(),
			prefetchRevision: e.revision,
			triggerMode: "auto"
		}));
	}, [
		X == null ? void 0 : X.autoAnswerEnabled,
		X == null ? void 0 : X.autoAnswerEnabledAtMs,
		U,
		(C = T.activeAnswerTask) == null ? void 0 : C.id,
		(ie = T.activeAnswerTask) == null ? void 0 : ie.status,
		T.captureState,
		(ae = T.speaker.autoAnswerQuestion) == null ? void 0 : ae.id,
		(oe = T.speaker.autoAnswerQuestion) == null ? void 0 : oe.answerTaskId,
		T.speaker.mode
	]);
	let Vt = async (e) => {
		if (!(ut || U === "replaced")) {
			dt(!0), M("");
			try {
				let t = await g((t) => _.updateInterviewAutoAnswer(w, e, t));
				vt.current.clear(), E((e) => ({
					...e,
					interviews: e.interviews.map((e) => e.id === w ? {
						...e,
						...t
					} : e)
				}));
			} catch (e) {
				M(e instanceof Error ? e.message : "自动回答设置保存失败，请稍后重试。");
			} finally {
				dt(!1);
			}
		}
	}, Ht = () => Ve(T.speaker), Ut = Ht(), Wt = () => {
		let e = Ht(), t = k.manualDraft.trim() || e;
		if (!t) {
			M(Be);
			return;
		}
		let n = [...T.speaker.transcripts].reverse().find((e) => e.sourceKind === "system" || e.role === "interviewer"), r = T.speaker.pendingQuestion, i = (r == null ? void 0 : r.revision) ?? (n == null ? void 0 : n.revision), a = (r == null ? void 0 : r.id) ?? (n == null ? void 0 : n.id);
		Bt(t, void 0, a && i ? {
			questionId: a,
			questionRevision: i,
			clickedAtMs: Date.now(),
			prefetchRevision: i
		} : void 0);
	};
	v(() => {
		Ut && j === Be && M("");
	}, [Ut, j]);
	let Gt = (e, t) => E((n) => ({
		...n,
		captureState: e,
		interviews: n.interviews.map((e) => e.id === w ? {
			...e,
			status: t
		} : e)
	})), Kt = async (e) => {
		if (!(nt || U === "replaced")) {
			rt(e), M("");
			try {
				let t = await g((t) => _.controlInterviewCapture(w, e, t));
				Gt(t, t === "paused" ? "paused" : "active");
			} catch (t) {
				M(t instanceof Error ? t.message : e === "pause" ? "暂停收音失败，请稍后重试。" : "恢复收音失败，请稍后重试。");
			} finally {
				rt(null);
			}
		}
	}, qt = async () => {
		if (!ct) {
			lt(!0);
			try {
				st(await g((e) => _.continueInterviewSession(w, e)));
			} finally {
				lt(!1);
			}
		}
	}, Jt = async () => {
		if (window.confirm(Z ? "End this written exam? Its answer history will remain available." : "End this interview? Audio capture will stop and the review will open.")) {
			try {
				await g((e) => _.endInterviewSession(w, e));
			} catch (e) {
				M(e instanceof Error ? e.message : Z ? "结束笔试失败，请稍后重试。" : "结束面试失败，请稍后重试。");
				return;
			}
			Mt(), Gt("ready", "ended"), fe(h.review(w));
		}
	}, Yt = (e, t) => {
		if (t === "generating" && Xe.current.has(e)) {
			I("These captures were submitted. Capture again to generate another answer.");
			return;
		}
		let n = T.questions.find((t) => t.id === e);
		if (n) {
			if (n.status === "cancelled" && t === "generating") {
				if (n.input === "manual") {
					Bt(n.text, e);
					return;
				}
				let r = `retry:${e}:${Date.now()}`, i = {
					id: `answer:${e}:${Date.now()}`,
					interviewId: w,
					userId: T.account.id,
					billingUsageId: r,
					questionId: e,
					question: n.text,
					revision: 1,
					status: "generating",
					partialText: "正在重新整理回答…",
					updatedAtMs: Date.now()
				};
				E((n) => ({
					...n,
					questions: n.questions.map((n) => n.id === e ? {
						...n,
						status: t
					} : n),
					activeAnswerTask: i
				}));
				return;
			}
			E((n) => ({
				...n,
				questions: n.questions.map((n) => n.id === e ? {
					...n,
					status: t
				} : n)
			}));
		}
	}, Xt = (e) => {
		V.current || U === "replaced" || (Mt(), qe.current = e, xe(e));
	}, Zt = async () => {
		if (!Z || !qe.current || U === "replaced" || z.current || V.current || Q && ![
			"completed",
			"failed",
			"cancelled"
		].includes(Q.stage) || !Ue || R.current.length >= Ue) return;
		if (!_.captureScreenshot) {
			I("Multi-screen capture is unavailable. Refresh and try again.");
			return;
		}
		let e = new AbortController(), t = B.current;
		z.current = e, F(!0), I("");
		try {
			let n = await g((n) => _.captureScreenshot({ interviewId: w }, n, (n) => {
				e.signal.aborted || B.current !== t || I(n.stage === "waiting-desktop" ? "Waiting for the Companion…" : n.stage === "uploading" ? "Uploading capture…" : "Capturing the current view…");
			}), e.signal);
			if (e.signal.aborted || B.current !== t || !qe.current) {
				jt([n]);
				return;
			}
			let r = [...R.current, n];
			R.current = r, Ce(r), I("");
		} catch (n) {
			!e.signal.aborted && B.current === t && I(n instanceof Error ? n.message : "Capture failed. Try again.");
		} finally {
			z.current === e && (z.current = null, F(!1));
		}
	}, Qt = (e) => {
		if (z.current || V.current) return;
		let t = R.current.filter((t) => t.requestId === e), n = R.current.filter((t) => t.requestId !== e);
		R.current = n, Ce(n), I(""), jt(t);
	}, $t = async () => {
		if (!Z || !qe.current || U === "replaced" || z.current || V.current || R.current.length === 0 || Q && ![
			"completed",
			"failed",
			"cancelled"
		].includes(Q.stage)) return;
		if (!_.submitScreenshotBatch) {
			I("Multi-screen answers are unavailable. Refresh and try again.");
			return;
		}
		let e = R.current, t = new AbortController(), n = B.current;
		V.current = !0, Je.current = e, Ye.current = null, R.current = [], Ce([]), je(!0), I(""), M(""), G.current = t, $({
			name: `${e.length} captures`,
			stage: "recognizing"
		});
		let r = `shot-batch-pending-${Date.now()}`;
		Xe.current.add(r);
		let i = {
			...ze,
			id: r,
			text: `Answer using ${e.length} captures together`,
			input: "screenshot",
			askedAt: "Just now",
			status: "generating",
			advice: {
				...ze.advice,
				detail: "Reading the captures and preparing an answer…",
				uncertain: !1
			}
		}, a = Lt(i, `screenshot:remote:batch:${Date.now()}`);
		E((e) => ({
			...e,
			questions: [i, ...e.questions],
			activeAnswerTask: a
		})), O((e) => ({
			...e,
			viewingAnswerId: null,
			newAnswerAvailable: !1
		}));
		let o = (e) => {
			t.signal.aborted || B.current !== n || (Ye.current = e.task, Xe.current.add(e.question.id), E((t) => {
				var n;
				return {
					...t,
					...P({
						questions: t.questions.filter((e) => e.id !== r),
						activeAnswerTask: ((n = t.activeAnswerTask) == null ? void 0 : n.questionId) === r ? null : t.activeAnswerTask
					}, {
						questions: [e.question],
						activeAnswerTask: e.task
					}, { preferIncomingTask: !0 })
				};
			}));
		};
		try {
			let r = await g((r) => _.submitScreenshotBatch({
				interviewId: w,
				captureRequestIds: e.map((e) => e.requestId),
				instruction: en
			}, r, (e) => {
				!t.signal.aborted && B.current === n && $(e);
			}, o), t.signal);
			if (t.signal.aborted || B.current !== n) return;
			o(r), A((e) => ({
				...e,
				screenshotTask: null,
				screenshotAnswerStatus: "success"
			})), r.task.status === "completed" && It();
		} catch (e) {
			var s;
			if (t.signal.aborted || B.current !== n) return;
			let i = `${e instanceof Error ? e.message : "Multi-screen answer failed."} Capture again before requesting another answer.`;
			I(i), $(null);
			let a = ((s = Ye.current) == null ? void 0 : s.questionId) ?? r;
			E((e) => ({
				...e,
				questions: e.questions.map((e) => e.id === a ? {
					...e,
					status: "failed",
					advice: {
						...e.advice,
						detail: i,
						uncertain: !0
					}
				} : e),
				activeAnswerTask: e.activeAnswerTask && e.activeAnswerTask.questionId === a ? {
					...e.activeAnswerTask,
					status: "failed",
					partialText: i
				} : e.activeAnswerTask
			})), A((e) => ({
				...e,
				screenshotAnswerStatus: "failed"
			}));
		} finally {
			jt(e), B.current === n && (V.current = !1, Je.current = [], Ye.current = null, je(!1)), G.current === t && (G.current = null);
		}
	}, en = Le.trim(), tn = async () => {
		let e = `screenshot:remote:${Date.now()}`, t = `shot-pending-${Date.now()}`, n = {
			...At,
			id: t,
			text: "请根据当前截图直接回答",
			input: "screenshot",
			askedAt: "Just now",
			status: "generating",
			advice: {
				outline: [],
				detail: "正在识别当前截图并生成回答…",
				sourceTypes: [],
				inference: "",
				uncertain: !1,
				provenance: {
					selectionRevision: 0,
					usedSources: []
				}
			}
		}, r = Lt(n, e);
		E((e) => ({
			...e,
			questions: [n, ...e.questions],
			activeAnswerTask: r
		})), O((e) => ({
			...e,
			viewingAnswerId: null,
			newAnswerAvailable: !1
		}));
		try {
			var i;
			let e = await g((e) => _.submitScreenshotAnswer({
				interviewId: w,
				instruction: en
			}, e, (e) => $(e), (e) => {
				E((n) => {
					var r;
					return {
						...n,
						...P({
							questions: n.questions.filter((e) => e.id !== t),
							activeAnswerTask: ((r = n.activeAnswerTask) == null ? void 0 : r.questionId) === t ? null : n.activeAnswerTask
						}, {
							questions: [e.question],
							activeAnswerTask: e.task
						}, { preferIncomingTask: !0 })
					};
				});
			}), (i = G.current) == null ? void 0 : i.signal);
			E((n) => {
				var r;
				return {
					...n,
					...P({
						questions: n.questions.filter((e) => e.id !== t),
						activeAnswerTask: ((r = n.activeAnswerTask) == null ? void 0 : r.questionId) === t ? null : n.activeAnswerTask
					}, {
						questions: [e.question],
						activeAnswerTask: e.task
					}, { preferIncomingTask: !0 })
				};
			}), A((e) => ({
				...e,
				screenshotTask: null,
				screenshotAnswerStatus: "success"
			})), e.task.status === "completed" && It();
		} catch (e) {
			if (e instanceof DOMException && e.name === "AbortError" || e instanceof Error && e.message === "请求已取消") return;
			let n = e instanceof Error ? e.message : "截屏回答失败，请稍后重试。";
			E((e) => {
				var r;
				return {
					...e,
					questions: e.questions.map((e) => e.id === t ? {
						...e,
						status: "failed",
						advice: {
							...e.advice,
							detail: n,
							uncertain: !0
						}
					} : e),
					activeAnswerTask: ((r = e.activeAnswerTask) == null ? void 0 : r.questionId) === t ? {
						...e.activeAnswerTask,
						status: "failed",
						partialText: n,
						updatedAtMs: Date.now()
					} : e.activeAnswerTask
				};
			}), nn(n, "共享屏幕截取");
		}
	}, nn = (e, t = (Q == null ? void 0 : Q.name) ?? "当前屏幕截取") => {
		$({
			name: t,
			stage: "failed",
			errorMessage: e
		});
	}, rn = (e) => e.stage === "failed" ? "截屏回答失败" : e.stage === "waiting-desktop" ? "等待本地助手" : e.stage === "uploading" ? "正在上传截图" : e.stage === "uploaded" ? "截图已上传" : e.stage === "recognizing" ? "正在识别截图" : e.stage === "generating" ? "正在生成答案" : e.stage === "completed" ? "截屏回答已完成" : e.stage === "cancelled" ? "截屏回答已取消" : "正在截取当前屏幕", an = (e) => e.stage === "failed" ? e.errorMessage || "截屏回答失败，请稍后重试。" : e.stage === "waiting-desktop" ? "网页端已创建截屏任务，正在等待本地助手接收。" : e.stage === "uploading" ? "本地助手已接收任务，正在截取并上传压缩后的全屏截图。" : e.stage === "uploaded" ? "截图已上传到后端，正在准备交给视觉模型识别。" : e.stage === "recognizing" ? "正在识别截图中的题目、代码或系统设计内容。" : e.stage === "generating" ? null : e.stage === "completed" ? "截图回答已完成，答案会显示在右侧回答区。" : e.stage === "cancelled" ? "本次截屏回答已取消。" : "正在截取你选择的共享屏幕，不会跳转到上传页面。", on = (e) => e instanceof DOMException && e.name === "AbortError" ? "" : e instanceof DOMException && e.name === "NotAllowedError" ? "共享屏幕截取未获授权，请检查电脑伴随程序权限后重试。" : e instanceof Error && e.message ? e.message : "共享屏幕暂时无法截取，请重试。", sn = async () => {
		var e;
		if (V.current) {
			let e = Ye.current;
			e && (H.current.add(e.id), H.current.add(e.questionId)), Mt(), A((e) => ({
				...e,
				screenshotTask: null,
				screenshotAnswerStatus: "cancelled"
			})), E((e) => ({
				...e,
				activeAnswerTask: e.activeAnswerTask ? {
					...e.activeAnswerTask,
					status: "cancelled",
					revision: e.activeAnswerTask.revision + 1
				} : null,
				questions: e.questions.map((t) => {
					var n;
					return t.id === ((n = e.activeAnswerTask) == null ? void 0 : n.questionId) ? {
						...t,
						status: "cancelled"
					} : t;
				})
			}));
			return;
		}
		let t = q.current;
		if (t) {
			J.current.add(t), q.current = null, A((e) => ({
				...e,
				screenshotTask: null,
				screenshotAnswerStatus: "cancelled"
			}));
			try {
				await g((e) => _.cancelDesktopShortcutScreenshot(t, e));
			} catch (e) {
				J.current.delete(t), nn(e instanceof Error ? e.message : "取消截屏回答失败，请稍后重试。");
			}
			return;
		}
		(e = G.current) == null || e.abort(), G.current = null, A((e) => ({
			...e,
			screenshotTask: null,
			screenshotAnswerStatus: "cancelled"
		})), E((e) => {
			let t = e.activeAnswerTask;
			return !t || !t.billingUsageId.startsWith("screenshot:remote:") || t.status !== "queued" && t.status !== "generating" ? e : {
				...e,
				activeAnswerTask: {
					...t,
					status: "cancelled",
					revision: t.revision + 1,
					updatedAtMs: Date.now()
				},
				questions: e.questions.map((e) => e.id === t.questionId ? {
					...e,
					status: "cancelled"
				} : e)
			};
		});
	}, cn = () => {
		var e;
		if (Q && Q.stage !== "failed" && Q.stage !== "completed" && Q.stage !== "cancelled") {
			$({ ...Q });
			return;
		}
		M(""), (e = G.current) == null || e.abort();
		let t = new AbortController();
		G.current = t, $({
			name: "共享屏幕截取",
			stage: "capturing"
		}), window.setTimeout(() => {
			Promise.resolve().then(() => {
				if (!t.signal.aborted) return $({
					name: "共享屏幕截取",
					stage: "recognizing"
				}), tn();
			}).then(() => {
				G.current = null;
			}).catch((e) => {
				if (t.signal.aborted || e instanceof DOMException && e.name === "AbortError") {
					G.current = null;
					return;
				}
				G.current = null, nn(on(e));
			});
		}, 0);
	};
	bt.current = Z && N ? () => void Zt() : cn, v(() => {
		let e = (e) => {
			U === "replaced" || e.repeat || e.altKey || e.metaKey || !e.ctrlKey || !e.shiftKey || e.code !== "Space" || (e.preventDefault(), e.stopPropagation(), bt.current());
		};
		return window.addEventListener("keydown", e, { capture: !0 }), () => window.removeEventListener("keydown", e, { capture: !0 });
	}, [U]);
	let ln = () => E((e) => ({
		...e,
		speaker: {
			...e.speaker,
			pendingQuestion: null
		}
	})), un = () => {
		T.speaker.pendingQuestion && E((e) => ({
			...e,
			speaker: {
				...e.speaker,
				pendingQuestion: null
			}
		}));
	}, dn = async () => {
		var e;
		let t = T.activeAnswerTask;
		if (!t || t.status !== "queued" && t.status !== "generating" || Ze) return;
		if (V.current) {
			await sn();
			return;
		}
		let n = (e, t, n) => E((r) => r.billing.activePass ? r : {
			...r,
			billing: {
				...r.billing,
				balance: r.billing.balance + t,
				ledger: [{
					id: `release-${e}`,
					userId: r.account.id,
					kind: "usage_release",
					points: t,
					createdAtMs: Date.now(),
					referenceId: e,
					description: n
				}, ...r.billing.ledger]
			}
		}), r = (e) => {
			var r;
			let i = (r = T.questions.find((e) => e.id === t.questionId)) == null ? void 0 : r.input;
			A((e) => ({
				...e,
				screenshotTask: i === "screenshot" ? null : e.screenshotTask,
				...i === "screenshot" ? { screenshotAnswerStatus: "cancelled" } : {},
				...i === "manual" ? {
					quickAnswerStatus: "cancelled",
					quickAnswerMessage: ""
				} : {}
			})), E((e) => ({
				...e,
				activeAnswerTask: {
					...t,
					status: "cancelled",
					revision: t.revision + 1,
					updatedAtMs: Date.now()
				},
				questions: e.questions.map((e) => e.id === t.questionId ? {
					...e,
					status: "cancelled"
				} : e)
			})), e && n(e.usageId, e.points, e.text);
		};
		if (t.billingUsageId.startsWith("pending:")) {
			var i;
			(i = K.current) == null || i.abort(), r();
			return;
		}
		if (t.billingUsageId.startsWith("screenshot:remote:")) {
			var a;
			(a = G.current) == null || a.abort(), G.current = null, r({
				usageId: t.billingUsageId,
				points: T.billing.rates.screenshotAnswerPoints,
				text: "截图回答已终止，积分预留已释放"
			});
			return;
		}
		(e = K.current) == null || e.abort(), Qe(!0), et("");
		try {
			let e = await g((e) => _.cancelAnswer({
				interviewId: w,
				answerTaskId: t.id,
				expectedRevision: t.revision,
				idempotencyKey: `cancel:${t.id}:${t.revision}`
			}, t, e));
			if (e.outcome === "cancelled" || e.outcome === "already-cancelled") {
				var o;
				let t = (o = T.questions.find((t) => t.id === e.task.questionId)) == null ? void 0 : o.input;
				t === "manual" && A((e) => ({
					...e,
					quickAnswerStatus: "cancelled",
					quickAnswerMessage: ""
				})), t === "screenshot" && A((e) => ({
					...e,
					screenshotTask: null,
					screenshotAnswerStatus: "cancelled"
				})), E((t) => {
					let n = !e.task.billingUsageId.startsWith("live-answer:") && !e.task.billingUsageId.startsWith("pending:");
					return {
						...t,
						activeAnswerTask: e.task,
						questions: t.questions.map((t) => t.id === e.task.questionId ? {
							...t,
							status: "cancelled"
						} : t),
						billing: e.billingReleased && n && !t.billing.activePass ? {
							...t.billing,
							balance: t.billing.balance + t.billing.rates.answerPoints,
							ledger: [{
								id: `release-${e.task.billingUsageId}`,
								userId: t.account.id,
								kind: "usage_release",
								points: t.billing.rates.answerPoints,
								createdAtMs: Date.now(),
								referenceId: e.task.billingUsageId,
								description: "回答已终止，积分预留已释放"
							}, ...t.billing.ledger]
						} : t.billing
					};
				});
			} else et(e.outcome === "stale-revision" ? "回答状态刚刚发生变化，请重试。" : "回答已经完成，无法终止。");
		} catch {
			et("终止回答失败，当前回答状态未改变，请重试。");
		} finally {
			Qe(!1);
		}
	}, fn = () => {
		var e;
		(e = G.current) == null || e.abort(), G.current = null, $(null), E((e) => {
			let t = e.activeAnswerTask;
			return !t || t.status !== "failed" || !t.billingUsageId.startsWith("screenshot:remote:") ? e : {
				...e,
				activeAnswerTask: null
			};
		});
	}, pn = /* @__PURE__ */ d(o, {
		enabled: wt.enabled,
		access: wt.access,
		disabled: U === "replaced" || Ze,
		onChange: (e) => {
			wt.change(e), !e && Tt.current && dn();
		}
	}), mn = j.includes("积分") || j.includes("会员") || j.toLowerCase().includes("billing"), hn = j === Be, gn = T.captureState === "capturing" || T.captureState === "reconnecting", _n = U === "replaced" ? "已在其他页面继续" : gn ? "正在收音" : T.captureState === "paused" ? "收音已暂停" : T.captureState === "permission-required" ? "采集能力不可用" : T.captureState === "error" ? "设备连接异常" : "已连接，未采集", vn = gn ? /* @__PURE__ */ d("button", {
		className: "button warning live-session-control",
		disabled: U === "replaced" || nt !== null,
		onClick: () => void Kt("pause"),
		children: nt === "pause" ? "暂停中…" : "暂停收音"
	}) : /* @__PURE__ */ d("button", {
		className: "button primary live-session-control",
		disabled: U === "replaced" || nt !== null || T.captureState !== "ready" && T.captureState !== "paused",
		onClick: () => T.captureState === "paused" ? void Kt("resume") : Gt("capturing", "active"),
		children: nt === "resume" ? "恢复中…" : T.captureState === "paused" ? "恢复收音" : "开始面试"
	}), yn = (e) => {
		A((t) => ({
			...t,
			manualDraft: e,
			quickAnswerStatus: "idle",
			quickAnswerMessage: ""
		})), e.trim() && j === Be && M("");
	}, bn = /* @__PURE__ */ d(n, {
		state: T,
		interviewAudioMode: Dt,
		onConfirmQuestion: U === "replaced" ? ln : un,
		onDismissQuestion: ln
	}), xn = /* @__PURE__ */ d(t, {
		answers: T.questions,
		viewingAnswerId: D.viewingAnswerId,
		newAnswerAvailable: D.newAnswerAvailable,
		activeTask: T.activeAnswerTask,
		cancelling: Ze,
		cancelError: $e,
		interviewLanguage: Ot,
		onStop: () => void dn(),
		onView: (e) => O((t) => ({
			...t,
			viewingAnswerId: e,
			newAnswerAvailable: e ? t.newAnswerAvailable : !1
		})),
		onRetry: Yt
	});
	return Z ? /* @__PURE__ */ f("main", {
		className: `live-page focused-live-page${W ? " desktop-live-page" : " mobile-live-page"}`,
		children: [
			/* @__PURE__ */ f("header", {
				className: "live-top",
				children: [
					/* @__PURE__ */ d(p, {
						to: h.writtenExams,
						"aria-label": "返回笔试模式",
						children: /* @__PURE__ */ d(r, {})
					}),
					/* @__PURE__ */ f("div", {
						className: "live-session-heading",
						children: [
							/* @__PURE__ */ d("strong", { children: Et }),
							/* @__PURE__ */ f("span", { children: [/* @__PURE__ */ d("i", { className: "online-dot" }), " 桌面助手已连接 · 截屏回答可用"] }),
							/* @__PURE__ */ d("small", {
								className: "live-language-badge",
								children: "笔试模式"
							})
						]
					}),
					/* @__PURE__ */ f("div", {
						className: "live-top-actions",
						children: [
							/* @__PURE__ */ f("div", {
								className: "live-auto-answer",
								children: [/* @__PURE__ */ d("span", { children: "Multi-screen answers" }), /* @__PURE__ */ f("label", {
									className: "switch-control",
									children: [/* @__PURE__ */ d("input", {
										type: "checkbox",
										role: "switch",
										"aria-label": "Multi-screen answers",
										checked: N,
										disabled: L || !Ee && k.screenshotAnswerStatus === "processing" || U === "replaced",
										onChange: (e) => Xt(e.target.checked)
									}), /* @__PURE__ */ d("span", { "aria-hidden": "true" })]
								})]
							}),
							/* @__PURE__ */ d(p, {
								className: "live-balance",
								to: h.billing,
								children: "积分与会员"
							}),
							/* @__PURE__ */ d(e, { compact: !0 }),
							/* @__PURE__ */ d("button", {
								className: "button danger live-session-control",
								disabled: U === "replaced",
								onClick: () => void Jt(),
								children: "结束笔试"
							})
						]
					})
				]
			}),
			j ? /* @__PURE__ */ f("div", {
				className: "global-live-alert",
				role: "alert",
				children: [/* @__PURE__ */ d("strong", { children: j }), /* @__PURE__ */ d("button", {
					type: "button",
					onClick: () => M(""),
					children: "关闭"
				})]
			}) : null,
			U === "replaced" ? /* @__PURE__ */ f("div", {
				className: "global-live-alert replaced-page-alert",
				role: "status",
				children: [/* @__PURE__ */ d("strong", { children: "本场笔试已在其他页面继续" }), /* @__PURE__ */ d(p, {
					className: "button primary",
					to: h.writtenExams,
					children: "返回笔试模式"
				})]
			}) : null,
			/* @__PURE__ */ d("div", {
				className: "written-exam-workspace",
				children: /* @__PURE__ */ f("section", {
					className: "answer-column",
					children: [xn, /* @__PURE__ */ d(de, {
						manualDraft: "",
						screenshotTask: k.screenshotTask,
						screenshotOnly: !0,
						screenshotAnswerStatus: k.screenshotAnswerStatus ?? "idle",
						disabled: U === "replaced" || L,
						onQuickAnswer: () => void 0,
						onScreenshot: N ? () => void Zt() : cn,
						multiScreen: N,
						pendingScreenshots: Se,
						screenshotLimit: Ue ?? 4,
						captureBusy: Ee,
						captureUnavailable: Ue === null,
						captureMessage: Ae || Ge || (Ue === null ? "Loading capture settings…" : ""),
						onBatchAnswer: () => void $t(),
						onRemoveScreenshot: Qt
					})]
				})
			}),
			Q && U !== "replaced" ? /* @__PURE__ */ d("div", {
				className: "sheet-backdrop",
				role: "dialog",
				"aria-modal": "true",
				"aria-labelledby": "screenshot-dialog-title",
				children: /* @__PURE__ */ f("section", {
					className: "sheet",
					children: [
						/* @__PURE__ */ d("h2", {
							id: "screenshot-dialog-title",
							children: rn(Q)
						}),
						an(Q) ? /* @__PURE__ */ d("p", { children: an(Q) }) : null,
						Q.stage === "failed" ? /* @__PURE__ */ f("div", {
							className: "sheet-actions split-actions",
							children: [/* @__PURE__ */ d("button", {
								className: "button ghost full",
								onClick: fn,
								children: "删除本次失败"
							}), /* @__PURE__ */ d("button", {
								className: "button primary full",
								onClick: cn,
								children: "重新截屏"
							})]
						}) : /* @__PURE__ */ d("button", {
							className: "button primary full",
							onClick: () => void sn(),
							children: "取消"
						})
					]
				})
			}) : null,
			/* @__PURE__ */ f("footer", {
				className: "session-bar",
				children: [/* @__PURE__ */ f("div", { children: [/* @__PURE__ */ d("i", { className: "online-dot" }), /* @__PURE__ */ d("strong", { children: "笔试进行中" })] }), /* @__PURE__ */ d("div", { children: /* @__PURE__ */ d("small", { children: "仅在你主动发起时截屏并生成回答" }) })]
			})
		]
	}) : /* @__PURE__ */ f("main", {
		className: `live-page focused-live-page${W ? " desktop-live-page" : " mobile-live-page"}`,
		children: [
			/* @__PURE__ */ f("header", {
				className: "live-top",
				children: [
					/* @__PURE__ */ d(p, {
						to: h.app,
						"aria-label": "返回面试首页",
						children: /* @__PURE__ */ d(r, {})
					}),
					/* @__PURE__ */ f("div", {
						className: "live-session-heading",
						children: [
							/* @__PURE__ */ d("strong", { children: Et }),
							/* @__PURE__ */ f("span", { children: [
								/* @__PURE__ */ d("i", { className: gn ? "recording-dot" : "online-dot" }),
								" ",
								W ? `This device · ${_n}` : _n
							] }),
							/* @__PURE__ */ d("small", {
								className: "live-language-badge",
								children: kt
							})
						]
					}),
					W ? /* @__PURE__ */ f("div", {
						className: "live-top-actions",
						children: [
							pn,
							/* @__PURE__ */ f("div", {
								className: "live-auto-answer",
								children: [/* @__PURE__ */ d("span", { children: "自动回答" }), /* @__PURE__ */ f("label", {
									className: "switch-control",
									children: [/* @__PURE__ */ d("input", {
										type: "checkbox",
										role: "switch",
										"aria-label": "自动回答",
										checked: (X == null ? void 0 : X.autoAnswerEnabled) ?? !1,
										disabled: ut || U === "replaced",
										onChange: (e) => void Vt(e.target.checked)
									}), /* @__PURE__ */ d("span", { "aria-hidden": "true" })]
								})]
							}),
							/* @__PURE__ */ d(p, {
								className: "live-balance",
								to: h.billing,
								children: "积分与会员"
							}),
							/* @__PURE__ */ f("details", {
								className: "live-contact-menu",
								children: [/* @__PURE__ */ d("summary", { children: "联系我们" }), /* @__PURE__ */ d("div", {
									className: "live-contact-popover",
									"aria-label": "官方社交账号",
									children: Ie.map((e) => /* @__PURE__ */ f("p", { children: [/* @__PURE__ */ d("small", { children: e.label }), /* @__PURE__ */ d("strong", { children: e.account })] }, e.id))
								})]
							}),
							/* @__PURE__ */ d("span", { children: "18:24" }),
							/* @__PURE__ */ d(e, { compact: !0 }),
							vn,
							/* @__PURE__ */ d("button", {
								className: "button danger live-session-control",
								disabled: U === "replaced",
								onClick: () => void Jt(),
								children: "结束面试"
							})
						]
					}) : /* @__PURE__ */ f("div", {
						className: "mobile-live-top-actions",
						children: [
							pn,
							/* @__PURE__ */ f("div", {
								className: "live-auto-answer mobile",
								children: [/* @__PURE__ */ d("span", { children: "自动" }), /* @__PURE__ */ f("label", {
									className: "switch-control",
									children: [/* @__PURE__ */ d("input", {
										type: "checkbox",
										role: "switch",
										"aria-label": "自动回答",
										checked: (X == null ? void 0 : X.autoAnswerEnabled) ?? !1,
										disabled: ut || U === "replaced",
										onChange: (e) => void Vt(e.target.checked)
									}), /* @__PURE__ */ d("span", { "aria-hidden": "true" })]
								})]
							}),
							vn,
							/* @__PURE__ */ f("details", {
								className: "mobile-live-more",
								children: [/* @__PURE__ */ d("summary", {
									"aria-label": "更多面试操作",
									children: "•••"
								}), /* @__PURE__ */ f("div", { children: [
									/* @__PURE__ */ d(p, {
										to: h.billing,
										children: "积分与会员"
									}),
									/* @__PURE__ */ d(p, {
										to: h.settings,
										children: "用户设置"
									}),
									/* @__PURE__ */ d("section", {
										className: "mobile-live-contact-list",
										"aria-label": "官方社交账号",
										children: Ie.map((e) => /* @__PURE__ */ f("p", { children: [/* @__PURE__ */ d("small", { children: e.label }), /* @__PURE__ */ d("strong", { children: e.account })] }, e.id))
									}),
									/* @__PURE__ */ d("button", {
										className: "danger",
										disabled: U === "replaced",
										onClick: () => void Jt(),
										children: "结束面试"
									})
								] })]
							})
						]
					})
				]
			}),
			(ot == null ? void 0 : ot.state) === "warning" ? /* @__PURE__ */ f("div", {
				className: "global-live-alert",
				role: "status",
				children: [
					/* @__PURE__ */ d("strong", { children: "本场面试即将因空闲自动结束" }),
					/* @__PURE__ */ d("span", { children: "连续 20 分钟没有音频、回答或截图活动会释放当前设备连接，历史记录仍会保留。" }),
					/* @__PURE__ */ d("button", {
						className: "button primary",
						disabled: ct,
						onClick: () => void qt(),
						children: ct ? "正在继续…" : "继续本场面试"
					})
				]
			}) : null,
			U === "replaced" ? /* @__PURE__ */ f("div", {
				className: "global-live-alert replaced-page-alert",
				role: "status",
				children: [
					/* @__PURE__ */ d("strong", { children: "本场面试已在其他页面继续" }),
					/* @__PURE__ */ d("span", { children: "当前页面已停止收音同步、实时订阅和回答请求；已显示内容仍可查看。关闭此页或返回面试首页即可。" }),
					/* @__PURE__ */ d(p, {
						className: "button primary",
						to: h.app,
						children: "返回面试首页"
					})
				]
			}) : null,
			T.captureState === "permission-required" || T.captureState === "error" ? /* @__PURE__ */ f("div", {
				className: "global-live-alert",
				role: "status",
				children: [
					/* @__PURE__ */ d("strong", { children: T.captureState === "permission-required" ? "助手采集能力不可用" : "桌面设备连接异常" }),
					/* @__PURE__ */ d("span", { children: T.captureState === "permission-required" ? "请在桌面助手中检查首次授权状态；网页不会申请麦克风或屏幕权限，手动输入仍可使用。" : "可以运行诊断，当前仍可使用手动问题和截图。" }),
					/* @__PURE__ */ d("button", {
						onClick: () => T.captureState === "permission-required" ? Gt("ready", "ready") : at((e) => e + 1),
						children: T.captureState === "permission-required" ? "关闭提示" : "重新诊断"
					})
				]
			}) : null,
			j ? /* @__PURE__ */ f("div", {
				className: "global-live-alert",
				role: "status",
				children: [
					/* @__PURE__ */ d("strong", { children: j }),
					/* @__PURE__ */ d("span", { children: hn ? "请等待面试官问题识别完成，或在左侧手动输入问题后再使用快答。" : mn ? "当前任务未启动，请检查积分或会员权益。" : "当前回答没有成功启动，请根据上方原因重试。" }),
					mn ? /* @__PURE__ */ d(p, {
						className: "button primary",
						to: h.billing,
						children: "前往积分与会员"
					}) : null
				]
			}) : null,
			W ? /* @__PURE__ */ f("div", {
				ref: gt,
				className: `live-grid focused-live-grid${U === "replaced" ? " live-grid-readonly" : ""}`,
				style: { gridTemplateColumns: `minmax(240px, ${D.splitRatio}fr) 12px minmax(300px, ${100 - D.splitRatio}fr)` },
				children: [
					/* @__PURE__ */ f("section", {
						className: "conversation-column",
						children: [bn, /* @__PURE__ */ d(i, {
							manualDraft: k.manualDraft,
							disabled: U === "replaced",
							onChange: yn
						})]
					}),
					/* @__PURE__ */ d(s, {
						containerRef: gt,
						ratio: D.splitRatio,
						bounds: ft,
						onChange: (e) => O((t) => ({
							...t,
							splitRatio: e
						}))
					}),
					/* @__PURE__ */ f("section", {
						className: "answer-column",
						children: [xn, /* @__PURE__ */ d(de, {
							manualDraft: k.manualDraft,
							latestInterviewerQuestion: Ut,
							screenshotTask: k.screenshotTask,
							quickAnswerStatus: k.quickAnswerStatus ?? "idle",
							quickAnswerMessage: k.quickAnswerMessage ?? "",
							screenshotAnswerStatus: k.screenshotAnswerStatus ?? "idle",
							disabled: U === "replaced",
							onQuickAnswer: Wt,
							onScreenshot: cn
						})]
					})
				]
			}) : /* @__PURE__ */ f("div", {
				className: `mobile-live-workspace${U === "replaced" ? " live-grid-readonly" : ""}`,
				children: [
					/* @__PURE__ */ f("nav", {
						className: "mobile-live-tabs",
						role: "tablist",
						"aria-label": "面试内容",
						children: [/* @__PURE__ */ f("button", {
							role: "tab",
							"aria-selected": mt === "answer",
							className: mt === "answer" ? "active" : "",
							onClick: () => ht("answer"),
							children: ["回答", T.activeAnswerTask && ["pending", "generating"].includes(T.activeAnswerTask.status) ? /* @__PURE__ */ d("span", { children: "生成中" }) : null]
						}), /* @__PURE__ */ f("button", {
							role: "tab",
							"aria-selected": mt === "conversation",
							className: mt === "conversation" ? "active" : "",
							onClick: () => ht("conversation"),
							children: ["对话", /* @__PURE__ */ d("span", { children: T.speaker.transcripts.length })]
						})]
					}),
					/* @__PURE__ */ d("section", {
						className: `mobile-live-panel ${mt}`,
						role: "tabpanel",
						children: mt === "answer" ? xn : bn
					}),
					/* @__PURE__ */ d(a, {
						manualDraft: k.manualDraft,
						latestInterviewerQuestion: Ut,
						screenshotTask: k.screenshotTask,
						quickAnswerStatus: k.quickAnswerStatus ?? "idle",
						quickAnswerMessage: k.quickAnswerMessage ?? "",
						screenshotAnswerStatus: k.screenshotAnswerStatus ?? "idle",
						disabled: U === "replaced",
						onChange: yn,
						onQuickAnswer: () => {
							ht("answer"), Wt();
						},
						onScreenshot: () => {
							ht("answer"), cn();
						}
					})
				]
			}),
			Q && U !== "replaced" ? /* @__PURE__ */ d("div", {
				className: "sheet-backdrop",
				role: "dialog",
				"aria-modal": "true",
				"aria-labelledby": "screenshot-dialog-title",
				children: /* @__PURE__ */ f("section", {
					className: "sheet",
					children: [
						/* @__PURE__ */ d("h2", {
							id: "screenshot-dialog-title",
							children: rn(Q)
						}),
						an(Q) ? /* @__PURE__ */ d("p", { children: an(Q) }) : null,
						Q.stage === "failed" ? /* @__PURE__ */ f("div", {
							className: "sheet-actions split-actions",
							children: [/* @__PURE__ */ d("button", {
								className: "button ghost full",
								onClick: fn,
								children: "删除本次失败"
							}), /* @__PURE__ */ d("button", {
								className: "button primary full",
								onClick: cn,
								children: "重新截屏"
							})]
						}) : /* @__PURE__ */ d("button", {
							className: "button primary full",
							onClick: () => void sn(),
							children: "取消"
						})
					]
				})
			}) : null,
			W ? /* @__PURE__ */ f("footer", {
				className: "session-bar",
				children: [/* @__PURE__ */ f("div", { children: [/* @__PURE__ */ d("i", { className: gn ? "recording-dot" : "online-dot" }), /* @__PURE__ */ d("strong", { children: gn ? "面试进行中" : T.captureState === "paused" ? "面试已暂停" : "等待开始面试" })] }), /* @__PURE__ */ d("div", { children: /* @__PURE__ */ d("small", { children: gn ? "正在持续接收面试官与我的实时对话" : "开始面试后会在头部右侧管理本场状态" }) })]
			}) : null
		]
	});
}
//#endregion
export { Ue as GlobalWrittenMultiScreenPage };
