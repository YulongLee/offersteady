from __future__ import annotations

import json
import logging
import os
import shutil
import re
from collections import deque
from pathlib import Path
from threading import Lock
from time import monotonic, time
from typing import Any

import redis

from app.core.config import Settings


CAPACITY_KEY = "offersteady:admin:capacity:v1"
REQUEST_WINDOW_MS = 5 * 60 * 1000
DISPLAY_WINDOW_MS = 60 * 60 * 1000
PEAK_PERSISTENCE_WARNING_INTERVAL_MS = 5 * 60 * 1000
REQUEST_BREAKDOWN_ROUTE_LIMIT = 8
logger = logging.getLogger(__name__)


def _now_ms() -> int:
    return int(time() * 1000)


def percentile(values: list[float], fraction: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    index = max(0, min(len(ordered) - 1, int((len(ordered) * fraction + 0.999999)) - 1))
    return ordered[index]


def capacity_level(value: float | int | None, warning: float | int | None, critical: float | int | None) -> str:
    if value is None:
        return "unavailable"
    if critical is not None and value >= critical:
        return "critical"
    if warning is not None and value >= warning:
        return "warning"
    return "healthy"


class RequestWindow:
    def __init__(self) -> None:
        self._events: deque[tuple[int, float, int, str, str]] = deque(maxlen=20_000)
        self._lock = Lock()

    @staticmethod
    def request_class(path: str) -> str:
        path = path.split("?", 1)[0]
        if path.startswith("/api/v1/admin/"):
            return "telemetry"
        if path.startswith("/api/v1/realtime-speech/sessions/") and path.endswith("/snapshot"):
            return "recovery_snapshot"
        if path.endswith("/stream") and (
            path.startswith("/api/v1/realtime-speech/sessions/")
            or path.startswith("/api/v1/screenshot-answer/")
        ):
            return "sse_stream"
        if any(
            marker in path
            for marker in (
                "/performance-ack",
                "/web-heartbeat",
                "/device-status",
                "/heartbeat",
                "/active-connection",
                "/idle-status",
            )
        ):
            return "telemetry"
        return "control_api"

    @staticmethod
    def normalized_route(path: str) -> str:
        """Return a stable route template without query strings or identifiers."""
        clean = path.split("?", 1)[0].split("#", 1)[0]
        segments = clean.split("/")
        dynamic_parent = {
            "sessions",
            "interviews",
            "desktop-devices",
            "capture-requests",
            "materials",
            "documents",
            "tasks",
        }
        normalized: list[str] = []
        for index, segment in enumerate(segments):
            if not segment:
                continue
            previous = segments[index - 1] if index else ""
            if previous in dynamic_parent or re.fullmatch(r"(?:session|device|capture|desktop-binding|task|request)-[A-Za-z0-9_-]+", segment):
                normalized.append("{id}")
            elif re.fullmatch(r"[0-9a-fA-F]{8}-[0-9a-fA-F-]{27,}", segment):
                normalized.append("{id}")
            else:
                normalized.append(segment)
        return "/" + "/".join(normalized)

    @staticmethod
    def _breakdown_class(request_class: str) -> str:
        return {
            "control_api": "user_api",
            "telemetry": "telemetry",
            "recovery_snapshot": "recovery_snapshot",
            "sse_stream": "sse_stream",
        }.get(request_class, "user_api")

    def record(self, *, path: str, elapsed_ms: float, status_code: int) -> None:
        if path in {"/healthz", "/api/v1/admin/capacity", "/api/v1/admin/server-health"}:
            return
        current = _now_ms()
        with self._lock:
            self._events.append((current, elapsed_ms, status_code, self.request_class(path), self.normalized_route(path)))
            self._prune(current)

    def summary(self, current: int | None = None) -> dict[str, float]:
        now = current or _now_ms()
        with self._lock:
            self._prune(now)
            events = list(self._events)
        ordinary_events = [item for item in events if item[3] != "sse_stream"]
        durations = [item[1] for item in ordinary_events]
        errors = sum(1 for item in ordinary_events if item[2] >= 500)
        span_minutes = max(1.0, min(5.0, (now - events[0][0]) / 60_000)) if events else 1.0
        result: dict[str, Any] = {
            "apiP95Ms": round(percentile(durations, 0.95) or 0.0, 2),
            "apiErrorRate": round(errors * 100 / len(ordinary_events), 2) if ordinary_events else 0.0,
            "requestsPerMinute": round(len(events) / span_minutes, 2),
            "userApiP95Ms": round(percentile([item[1] for item in events if self._breakdown_class(item[3]) == "user_api"], 0.95) or 0.0, 2),
            "telemetryP95Ms": round(percentile([item[1] for item in events if self._breakdown_class(item[3]) == "telemetry"], 0.95) or 0.0, 2),
        }
        for request_class, prefix in (
            ("control_api", "controlApi"),
            ("recovery_snapshot", "recoverySnapshot"),
            ("sse_stream", "sseStreamDuration"),
        ):
            classified = [item[1] for item in events if item[3] == request_class]
            result[f"{prefix}P95Ms"] = round(percentile(classified, 0.95) or 0.0, 2)
            result[f"{prefix}RequestCount"] = len(classified)
        class_summary: dict[str, dict[str, float | int]] = {}
        for breakdown_class in ("user_api", "telemetry", "recovery_snapshot", "sse_stream"):
            classified = [item for item in events if self._breakdown_class(item[3]) == breakdown_class]
            class_durations = [item[1] for item in classified]
            error_count = sum(1 for item in classified if item[2] >= 500)
            class_summary[breakdown_class] = {
                "requestCount": len(classified),
                "p95Ms": round(percentile(class_durations, 0.95) or 0.0, 2),
                "errorCount": error_count,
                "errorRate": round(error_count * 100 / len(classified), 2) if classified else 0.0,
            }
        route_groups: dict[tuple[str, str], list[tuple[int, float, int, str, str]]] = {}
        for event in events:
            key = (self._breakdown_class(event[3]), event[4])
            route_groups.setdefault(key, []).append(event)
        slow_routes = []
        for (breakdown_class, route), grouped in route_groups.items():
            route_durations = [item[1] for item in grouped]
            error_count = sum(1 for item in grouped if item[2] >= 500)
            slow_routes.append({
                "route": route,
                "class": breakdown_class,
                "requestCount": len(grouped),
                "p95Ms": round(percentile(route_durations, 0.95) or 0.0, 2),
                "errorCount": error_count,
                "errorRate": round(error_count * 100 / len(grouped), 2),
            })
        result["requestBreakdown"] = {
            "classes": class_summary,
            "slowRoutes": sorted(slow_routes, key=lambda item: (-float(item["p95Ms"]), -int(item["requestCount"])))[:REQUEST_BREAKDOWN_ROUTE_LIMIT],
        }
        # Preserve the existing response fields for older admin clients while
        # exposing the accurate full-connection duration name to new clients.
        result["sseHandshakeP95Ms"] = result["sseStreamDurationP95Ms"]
        result["sseHandshakeRequestCount"] = result["sseStreamDurationRequestCount"]
        return result

    def _prune(self, current: int) -> None:
        while self._events and self._events[0][0] < current - REQUEST_WINDOW_MS:
            self._events.popleft()


class AdminCapacityMonitor:
    def __init__(self, settings: Settings, repository: Any) -> None:
        self.settings = settings
        self.repository = repository
        self.requests = RequestWindow()
        self._samples: deque[dict[str, Any]] = deque(maxlen=720)
        self._lock = Lock()
        self._cpu_lock = Lock()
        self._previous_cpu: tuple[int, float] | None = None
        self._server_cache: dict[str, Any] | None = None
        self._server_cache_at_ms = 0
        self._live_session_cache: set[str] | None = None
        self._live_session_cache_at_ms = 0
        self._last_peak_persistence_warning_at_ms = 0
        self._redis = (
            redis.Redis.from_url(
                settings.redis_url,
                decode_responses=True,
                socket_timeout=settings.redis_socket_timeout_seconds,
                socket_connect_timeout=settings.redis_socket_timeout_seconds,
            )
            if settings.redis_url else None
        )

    def record_request(self, *, path: str, elapsed_ms: float, status_code: int) -> None:
        self.requests.record(path=path, elapsed_ms=elapsed_ms, status_code=status_code)

    def sample(self) -> dict[str, Any]:
        current = _now_ms()
        database = self._safe_database_counts()
        runtime = self._safe_runtime_counts(current)
        resources = self._resource_counts()
        sample = {
            "atMs": current,
            **database,
            **runtime,
            **resources,
            **self.requests.summary(current),
        }
        active_interviews = sample.get("activeInterviews")
        if isinstance(active_interviews, int):
            try:
                self.repository.record_capacity_peak(
                    at_ms=current,
                    active_interviews=active_interviews,
                )
                sample["capacityPeakPersistence"] = "healthy"
            except Exception as exc:
                sample["capacityPeakPersistence"] = "degraded"
                if current - self._last_peak_persistence_warning_at_ms >= PEAK_PERSISTENCE_WARNING_INTERVAL_MS:
                    logger.warning(
                        "admin_capacity_peak_persistence_failed",
                        extra={"error_code": type(exc).__name__},
                    )
                    self._last_peak_persistence_warning_at_ms = current
        with self._lock:
            self._samples.append(sample)
        self._persist(sample)
        return sample

    def report(self) -> dict[str, Any]:
        samples = self._load_samples()
        if not samples:
            samples = [self.sample()]
        current = samples[-1]
        database_limit = current.get("databaseConnectionLimit")
        definitions = [
            ("activeInterviews", "进行中面试", "场", self.settings.admin_capacity_active_interviews_warning, self.settings.admin_capacity_active_interviews_critical, "最近 20 分钟仍有活动的 live 面试。"),
            ("activeWebSessions", "在线面试页面", "页", None, None, "仍在发送有效心跳的实时面试页面。"),
            ("onlineDevices", "在线桌面助手", "台", None, None, "最近 45 秒仍有心跳的桌面助手。"),
            ("activeAudioStreams", "活跃 ASR 音频流", "路", self.settings.admin_capacity_audio_streams_warning, self.settings.admin_capacity_audio_streams_critical, "最近 30 秒收到真实音频帧的去重音轨。"),
            ("cpuPercent", "后端容器 CPU", "%", self.settings.admin_capacity_cpu_warning_percent, self.settings.admin_capacity_cpu_critical_percent, "相对容器 CPU 配额的使用率。"),
            ("memoryPercent", "后端容器内存", "%", self.settings.admin_capacity_memory_warning_percent, self.settings.admin_capacity_memory_critical_percent, "后端进程容器内存使用率；无容器上限时按容器 RSS/主机总内存计算。"),
            ("hostMemoryPercent", "主机内存", "%", None, None, "整台服务器内存使用率，仅用于主机容量参考。"),
            ("diskPercent", "服务器磁盘", "%", 75, 90, "应用所在文件系统的整体使用率，不扫描文件内容。"),
            ("loadAverage1m", "系统 1 分钟负载", "load", None, None, "Linux 系统一分钟平均负载。"),
            ("uptimeSeconds", "服务器运行时长", "s", None, None, "Linux 主机或容器可见的运行时长。"),
            ("apiP95Ms", "API P95（综合）", "ms", self.settings.admin_capacity_api_p95_warning_ms, self.settings.admin_capacity_api_p95_critical_ms, "最近 5 分钟所有普通后端请求的综合 P95；请结合分类指标判断用户请求是否变慢。"),
            ("userApiP95Ms", "用户请求 P95", "ms", self.settings.admin_capacity_api_p95_warning_ms, self.settings.admin_capacity_api_p95_critical_ms, "最近 5 分钟用户业务请求耗时 P95，不包含后台遥测和实时流。"),
            ("telemetryP95Ms", "后台遥测 P95", "ms", None, None, "最近 5 分钟设备连接、heartbeat 等后台遥测请求耗时 P95。"),
            ("apiErrorRate", "API 5xx 错误率", "%", self.settings.admin_capacity_error_rate_warning_percent, self.settings.admin_capacity_error_rate_critical_percent, "最近 5 分钟服务端错误占比。"),
            ("databaseConnections", "数据库连接", "条", database_limit * 0.7 if database_limit else None, database_limit * 0.9 if database_limit else None, "当前数据库连接数及其最大连接配额。"),
        ]
        metrics = []
        for key, label, unit, warning, critical, description in definitions:
            value = current.get(key)
            metrics.append({
                "key": key,
                "label": label,
                "unit": unit,
                "value": value,
                "warning": warning,
                "critical": critical,
                "level": capacity_level(value, warning, critical),
                "description": description,
                "points": [{"atMs": item["atMs"], "value": item.get(key)} for item in samples],
            })
        request_breakdown = dict(current.get("requestBreakdown") or {})
        request_breakdown["series"] = [
            {
                "atMs": int(item["atMs"]),
                "classes": {
                    key: float((item.get("requestBreakdown") or {}).get("classes", {}).get(key, {}).get("p95Ms") or 0.0)
                    for key in ("user_api", "telemetry", "recovery_snapshot", "sse_stream")
                },
            }
            for item in samples
        ]
        return {
            "generatedAtMs": _now_ms(),
            "sampleIntervalSeconds": self.settings.admin_capacity_sample_interval_seconds,
            "windowMinutes": 60,
            "metrics": metrics,
            "supporting": {
                "activeUsers": current.get("activeUsers"),
                "requestsPerMinute": current.get("requestsPerMinute"),
                "containerMemory": {
                    "bytes": current.get("containerMemoryBytes"),
                    "limitBytes": current.get("containerMemoryLimitBytes"),
                    "source": current.get("containerMemorySource"),
                },
                "hostMemoryPercent": current.get("hostMemoryPercent"),
                "requestBreakdown": request_breakdown or {
                    "classes": {
                        "user_api": {"requestCount": 0, "p95Ms": 0.0, "errorCount": 0, "errorRate": 0.0},
                        "telemetry": {"requestCount": 0, "p95Ms": 0.0, "errorCount": 0, "errorRate": 0.0},
                        "recovery_snapshot": {"requestCount": 0, "p95Ms": 0.0, "errorCount": 0, "errorRate": 0.0},
                        "sse_stream": {"requestCount": 0, "p95Ms": 0.0, "errorCount": 0, "errorRate": 0.0},
                    },
                    "slowRoutes": [],
                },
                "requestClasses": {
                    "controlApi": {
                        "p95Ms": current.get("controlApiP95Ms"),
                        "requestCount": current.get("controlApiRequestCount"),
                    },
                    "recoverySnapshot": {
                        "p95Ms": current.get("recoverySnapshotP95Ms"),
                        "requestCount": current.get("recoverySnapshotRequestCount"),
                    },
                    "sseHandshake": {
                        "p95Ms": current.get("sseHandshakeP95Ms"),
                        "requestCount": current.get("sseHandshakeRequestCount"),
                    },
                    "sseStreamDuration": {
                        "p95Ms": current.get("sseStreamDurationP95Ms"),
                        "requestCount": current.get("sseStreamDurationRequestCount"),
                    },
                },
                "databaseConnectionLimit": database_limit,
            },
        }

    def server_report(self) -> dict[str, Any]:
        current_ms = _now_ms()
        with self._lock:
            if self._server_cache is not None and current_ms - self._server_cache_at_ms < 10_000:
                return self._server_cache
        capacity = self.report()
        allowed = {"cpuPercent", "memoryPercent", "hostMemoryPercent", "diskPercent", "loadAverage1m", "uptimeSeconds"}
        resources = [item for item in capacity["metrics"] if item["key"] in allowed]
        current = {item["key"]: item["value"] for item in resources}
        dependencies = self._dependency_health()
        report = {
            "generatedAtMs": _now_ms(),
            "sampleIntervalSeconds": capacity["sampleIntervalSeconds"],
            "windowMinutes": capacity["windowMinutes"],
            "resources": resources,
            "dependencies": dependencies,
            "overall": "critical" if any(item["status"] == "critical" for item in dependencies)
                or any(item["level"] == "critical" for item in resources)
                else "warning" if any(item["status"] in {"warning", "unavailable"} for item in dependencies)
                or any(item["level"] in {"warning", "unavailable"} for item in resources)
                else "healthy",
            "supporting": {
                "uptimeSeconds": current.get("uptimeSeconds"),
                "requestsPerMinute": capacity["supporting"].get("requestsPerMinute"),
                "requestBreakdown": capacity["supporting"].get("requestBreakdown"),
            },
        }
        with self._lock:
            self._server_cache = report
            self._server_cache_at_ms = current_ms
        return report

    def _safe_database_counts(self) -> dict[str, int | None]:
        try:
            return self.repository.capacity_counts()
        except Exception:
            return {
                "activeInterviews": None,
                "activeUsers": None,
                "databaseConnections": None,
                "databaseConnectionLimit": None,
            }

    def _safe_runtime_counts(self, current: int) -> dict[str, int | None]:
        if self._redis is None:
            return {"activeWebSessions": None, "onlineDevices": None, "activeAudioStreams": None}
        try:
            raw = self._redis.get("offersteady:realtime:runtime:v2")
            payload = json.loads(raw) if raw else {}
            devices = payload.get("devices", [])
            heartbeats = payload.get("heartbeats", [])
            receipts = [json.loads(item) for item in self._redis.hvals("offersteady:realtime:runtime:v2:receipts")]
            live_session_ids = self._live_session_ids(current)
            publisher_statuses = {
                str(item.get("publisher_id")): item.get("status")
                for raw_publisher in self._redis.hvals("offersteady:realtime:runtime:v2:publishers")
                for item in [json.loads(raw_publisher)]
                if item.get("publisher_id")
            }
            online_devices = {
                str(item.get("device_id"))
                for item in devices
                if item.get("status") == "online"
                and int(item.get("last_seen_at_ms") or 0) >= current - self.settings.realtime_desktop_heartbeat_ttl_seconds * 1000
            }
            active_web = {
                str(item.get("session_id"))
                for item in heartbeats
                if item.get("page") == "live"
                and int(item.get("lease_expires_at_ms") or 0) >= current
            }
            active_audio = {
                (str(item.get("session_id")), str(item.get("source_kind")), str(item.get("source_id")))
                for item in receipts
                if item.get("source_id") != "diagnostic-pcm-probe"
                and (live_session_ids is None or str(item.get("session_id")) in live_session_ids)
                and (
                    not publisher_statuses
                    or publisher_statuses.get(str(item.get("publisher_id"))) not in {"closed", "failed"}
                )
                and int(item.get("frame_count") or 0) > 0
                and int(item.get("received_at_ms") or 0) >= current - 30_000
                and item.get("asr_status") in {"pending", "accepted"}
            }
            return {
                "activeWebSessions": len(active_web),
                "onlineDevices": len(online_devices),
                "activeAudioStreams": len(active_audio),
            }
        except Exception:
            return {"activeWebSessions": None, "onlineDevices": None, "activeAudioStreams": None}

    def _live_session_ids(self, current: int) -> set[str] | None:
        """Return live interview ids so stale receipts cannot inflate capacity cards."""
        with self._lock:
            if self._live_session_cache is not None and current - self._live_session_cache_at_ms < 10_000:
                return set(self._live_session_cache)
        list_sessions = getattr(self.repository, "list_sessions", None)
        if not callable(list_sessions):
            return None
        try:
            rows = list_sessions(limit=5_000, offset=0)
            live = {
                str(row.get("session_id"))
                for row in rows
                if isinstance(row, dict) and row.get("status") == "live" and row.get("session_id")
            }
        except Exception:
            return None
        with self._lock:
            self._live_session_cache = live
            self._live_session_cache_at_ms = current
        return set(live)

    def _resource_counts(self) -> dict[str, Any]:
        memory = self._memory_stats()
        return {
            "cpuPercent": self._cpu_percent(),
            "memoryPercent": memory["containerPercent"],
            "containerMemoryBytes": memory["containerBytes"],
            "containerMemoryLimitBytes": memory["containerLimitBytes"],
            "containerMemorySource": memory["containerSource"],
            "hostMemoryPercent": memory["hostPercent"],
            "diskPercent": self._disk_percent(),
            "loadAverage1m": self._load_average(),
            "uptimeSeconds": self._uptime_seconds(),
        }

    def _dependency_health(self) -> list[dict[str, Any]]:
        result = [{"key": "backend", "label": "Backend", "status": "healthy", "latencyMs": 0, "detail": "应用进程正在提供服务"}]
        started = monotonic()
        try:
            counts = self.repository.capacity_counts()
            ratio = (counts["databaseConnections"] / counts["databaseConnectionLimit"] * 100) if counts.get("databaseConnectionLimit") else 0
            result.append({
                "key": "postgresql", "label": "PostgreSQL",
                "status": "critical" if ratio >= 90 else "warning" if ratio >= 70 else "healthy",
                "latencyMs": round((monotonic() - started) * 1000, 2),
                "detail": f"连接 {counts['databaseConnections']}/{counts['databaseConnectionLimit']}",
            })
        except Exception:
            result.append({"key": "postgresql", "label": "PostgreSQL", "status": "unavailable", "latencyMs": None, "detail": "数据库探针不可用"})
        if self._redis is None:
            result.append({"key": "redis", "label": "Redis", "status": "unavailable", "latencyMs": None, "detail": "Redis 未配置"})
        else:
            started = monotonic()
            try:
                self._redis.ping()
                result.append({"key": "redis", "label": "Redis", "status": "healthy", "latencyMs": round((monotonic() - started) * 1000, 2), "detail": "只读 PING 正常"})
            except Exception:
                result.append({"key": "redis", "label": "Redis", "status": "unavailable", "latencyMs": None, "detail": "Redis 探针不可用"})
        try:
            health = self.repository.analytics_health(expected_since_ms=_now_ms() - 86_400_000)
            latest = health.get("lastSuccessAtMs")
            delayed = latest is None or int(latest) < _now_ms() - 2 * 60 * 60 * 1000
            result.append({
                "key": "analytics", "label": "运营分析任务", "status": "warning" if delayed else "healthy",
                "latencyMs": None, "detail": "聚合延迟" if delayed else "最近聚合正常", "lastSuccessAtMs": latest,
            })
        except Exception:
            result.append({"key": "analytics", "label": "运营分析任务", "status": "unavailable", "latencyMs": None, "detail": "聚合状态不可用"})
        started = monotonic()
        try:
            payment = self.repository.payment_configuration_health()
            configured = payment["configuredChannels"]
            ready = payment["readyChannels"]
            result.append({
                "key": "payment_config", "label": "支付配置服务",
                "status": "healthy" if configured >= 2 else "warning",
                "latencyMs": round((monotonic() - started) * 1000, 2),
                "detail": f"已配置 {configured} 个渠道 · 可启用 {ready} 个",
            })
        except Exception:
            result.append({"key": "payment_config", "label": "支付配置服务", "status": "unavailable", "latencyMs": None, "detail": "支付配置探针不可用"})
        request_summary = self.requests.summary()
        error_rate = request_summary["apiErrorRate"]
        p95 = request_summary["apiP95Ms"]
        status = "critical" if error_rate >= self.settings.admin_capacity_error_rate_critical_percent or p95 >= self.settings.admin_capacity_api_p95_critical_ms else "warning" if error_rate >= self.settings.admin_capacity_error_rate_warning_percent or p95 >= self.settings.admin_capacity_api_p95_warning_ms else "healthy"
        result.append({"key": "api", "label": "API 质量", "status": status, "latencyMs": p95, "detail": f"5xx {error_rate:.1f}% · P95 {p95:.0f}ms"})
        return result

    @staticmethod
    def _disk_percent() -> float | None:
        try:
            usage = shutil.disk_usage("/")
            return round(usage.used * 100 / usage.total, 2) if usage.total else None
        except OSError:
            return None

    @staticmethod
    def _load_average() -> float | None:
        try:
            return round(float(os.getloadavg()[0]), 2)
        except (OSError, AttributeError):
            return None

    @staticmethod
    def _uptime_seconds() -> float | None:
        try:
            return round(float(Path("/proc/uptime").read_text(encoding="ascii").split()[0]), 0)
        except (OSError, ValueError, IndexError):
            return None

    def _cpu_percent(self) -> float | None:
        try:
            values = {}
            for line in Path("/sys/fs/cgroup/cpu.stat").read_text(encoding="ascii").splitlines():
                key, value = line.split()
                values[key] = int(value)
            quota_text = Path("/sys/fs/cgroup/cpu.max").read_text(encoding="ascii").strip().split()
            quota = float(quota_text[0]) if quota_text[0] != "max" else float(os.cpu_count() or 1) * float(quota_text[1])
            period = float(quota_text[1])
            cores = max(0.01, quota / period)
            usage = int(values["usage_usec"])
            observed = monotonic()
            with self._cpu_lock:
                previous = self._previous_cpu
                self._previous_cpu = (usage, observed)
            if previous is None or observed <= previous[1]:
                return None
            percent = (usage - previous[0]) / ((observed - previous[1]) * 1_000_000 * cores) * 100
            return round(max(0.0, percent), 2)
        except (OSError, KeyError, ValueError):
            return None

    @staticmethod
    def _memory_stats() -> dict[str, float | int | str | None]:
        """Return container memory and host memory separately.

        Docker installations without a memory limit expose ``memory.max`` as
        ``max``. In that case the process RSS is the only container-specific
        usage signal; it is deliberately reported as a percentage of host
        total memory and tagged with its source instead of pretending a host
        percentage is a container percentage.
        """
        current: int | None = None
        maximum: int | None = None
        try:
            current = int(Path("/sys/fs/cgroup/memory.current").read_text(encoding="ascii").strip())
            maximum_text = Path("/sys/fs/cgroup/memory.max").read_text(encoding="ascii").strip()
            if maximum_text != "max":
                maximum = int(maximum_text)
        except (OSError, ValueError):
            current = None

        rss: int | None = None
        try:
            for line in Path("/proc/self/status").read_text(encoding="ascii").splitlines():
                if line.startswith("VmRSS:"):
                    rss = int(line.split()[1]) * 1024
                    break
        except (OSError, ValueError, IndexError):
            pass
        container_bytes = current if current is not None else rss
        if maximum is not None and maximum > 0 and current is not None:
            container_percent = round(current * 100 / maximum, 2)
            container_source = "cgroup"
        else:
            container_percent = None
            container_source = "rss-host-total" if rss is not None else "unavailable"
        try:
            memory = {
                line.split(":", 1)[0]: int(line.split()[1])
                for line in Path("/proc/meminfo").read_text(encoding="ascii").splitlines()
                if ":" in line and len(line.split()) >= 2
            }
            total = memory["MemTotal"]
            available = memory["MemAvailable"]
            host_percent = round((total - available) * 100 / total, 2) if total > 0 else None
            if container_percent is None and rss is not None and total > 0:
                container_percent = round(rss * 100 / (total * 1024), 2)
            return {
                "containerBytes": container_bytes,
                "containerLimitBytes": maximum,
                "containerPercent": container_percent,
                "containerSource": container_source,
                "hostPercent": host_percent,
            }
        except (OSError, KeyError, ValueError):
            return {
                "containerBytes": container_bytes,
                "containerLimitBytes": maximum,
                "containerPercent": container_percent,
                "containerSource": container_source,
                "hostPercent": None,
            }

    @staticmethod
    def _memory_percent() -> float | None:
        """Compatibility helper returning the corrected container percentage."""
        return AdminCapacityMonitor._memory_stats()["containerPercent"]  # type: ignore[return-value]

    def _persist(self, sample: dict[str, Any]) -> None:
        if self._redis is None:
            return
        try:
            encoded = json.dumps(sample, ensure_ascii=True, separators=(",", ":"))
            pipeline = self._redis.pipeline()
            pipeline.zadd(CAPACITY_KEY, {encoded: int(sample["atMs"])})
            pipeline.zremrangebyscore(CAPACITY_KEY, 0, int(sample["atMs"]) - self.settings.admin_capacity_retention_seconds * 1000)
            pipeline.expire(CAPACITY_KEY, self.settings.admin_capacity_retention_seconds)
            pipeline.execute()
        except Exception:
            return

    def _load_samples(self) -> list[dict[str, Any]]:
        cutoff = _now_ms() - DISPLAY_WINDOW_MS
        if self._redis is not None:
            try:
                return [json.loads(item) for item in self._redis.zrangebyscore(CAPACITY_KEY, cutoff, "+inf")]
            except Exception:
                pass
        with self._lock:
            return [item for item in self._samples if int(item["atMs"]) >= cutoff]
