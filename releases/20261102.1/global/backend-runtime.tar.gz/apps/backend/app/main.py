from __future__ import annotations

import asyncio
import os
from contextlib import asynccontextmanager, suppress

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware

from app.api.v1 import api_router
from app.api.admin import admin_router, admin_service
from app.api.admin_promotion import admin_promotion_router
from app.api.admin_global_commerce import admin_global_commerce_router
from app.api.promotion import public_promotion_router
from app.core.config import get_settings
from app.core.logging import configure_logging, utc_now_iso
from app.core.responses import ApiEnvelope, success_response
from app.core.errors import install_exception_handlers
from app.middleware.request_context import RequestContextMiddleware
from app.schemas.foundation import HealthResponse
from app.services.admin_capacity import AdminCapacityMonitor
from app.services.live_answer_stream_executor import LiveAnswerStreamExecutor
from app.services.realtime_event_wait import RealtimeEventWaitExecutor
from app.services.realtime_control_executor import RealtimeControlExecutor
from app.services.screenshot_stream_admission import ScreenshotStreamAdmissionCoordinator


def create_app() -> FastAPI:
    settings = get_settings()
    logger = configure_logging(settings)
    live_answer_stream_executor = LiveAnswerStreamExecutor(
        max_workers=settings.live_answer_stream_worker_count,
        queue_max=settings.live_answer_stream_queue_max,
        event_queue_max=settings.live_answer_stream_event_queue_max,
    )

    @asynccontextmanager
    async def lifespan(application: FastAPI):
        task: asyncio.Task[None] | None = None
        reaper_task: asyncio.Task[None] | None = None
        mock_reaper_task: asyncio.Task[None] | None = None
        mock_runtime_instance = None
        resume_optimizer_runtime = None
        realtime_service_instance = None
        realtime_event_wait_executor = RealtimeEventWaitExecutor(
            max_workers=settings.realtime_event_wait_workers,
        )
        screenshot_event_wait_executor = RealtimeEventWaitExecutor(
            max_workers=settings.screenshot_event_wait_workers,
            thread_name_prefix="screenshot-event-wait",
        )
        screenshot_stream_admission = ScreenshotStreamAdmissionCoordinator(
            max_active=settings.screenshot_stream_max_active,
            reconnect_window_seconds=settings.screenshot_stream_reconnect_window_seconds,
            reconnect_max_accepts=settings.screenshot_stream_reconnect_max_accepts,
            retry_after_seconds=settings.screenshot_stream_retry_after_seconds,
        )
        realtime_control_executor = RealtimeControlExecutor(
            max_workers=settings.realtime_control_worker_count,
            queue_max=settings.realtime_control_queue_max,
        )
        application.state.realtime_event_wait_executor = realtime_event_wait_executor
        application.state.screenshot_event_wait_executor = screenshot_event_wait_executor
        application.state.screenshot_stream_admission = screenshot_stream_admission
        application.state.realtime_control_executor = realtime_control_executor
        application.state.live_answer_stream_executor = live_answer_stream_executor
        if settings.realtime_resource_reaper_enabled:
            try:
                from app.deps import realtime_speech_service

                realtime_service_instance = realtime_speech_service()

                async def reap_realtime_resources() -> None:
                    while True:
                        try:
                            await asyncio.to_thread(realtime_service_instance.reap_idle_sessions)
                        except asyncio.CancelledError:
                            raise
                        except Exception as exc:
                            logger.warning(
                                "realtime_resource_reaper_failed",
                                extra={"errorCode": exc.__class__.__name__},
                            )
                        await asyncio.sleep(max(5, settings.realtime_resource_reaper_interval_seconds))

                reaper_task = asyncio.create_task(reap_realtime_resources())
            except Exception as exc:
                logger.warning(
                    "realtime_resource_reaper_unavailable",
                    extra={"errorCode": exc.__class__.__name__},
                )
        if settings.admin_enabled and settings.database_url:
            try:
                monitor = AdminCapacityMonitor(settings, admin_service().repository)
                application.state.capacity_monitor = monitor

                async def sample_capacity() -> None:
                    while True:
                        try:
                            await asyncio.to_thread(monitor.sample)
                        except Exception:
                            logger.warning("admin_capacity_sample_failed")
                        await asyncio.sleep(max(10, settings.admin_capacity_sample_interval_seconds))

                task = asyncio.create_task(sample_capacity())
            except Exception:
                logger.warning("admin_capacity_monitor_unavailable")
        if (settings.global_mock_interview_enabled if settings.product_edition == "global" else settings.mock_interview_enabled):
            from app.modules.mock_interview import mock_runtime

            if int(os.environ.get("WEB_CONCURRENCY", "1")) != 1:
                raise RuntimeError("Mock interview capture requires a single application worker")
            mock_runtime_instance = await asyncio.to_thread(mock_runtime)

            async def reap_mock_resources():
                while True:
                    try:
                        await mock_runtime_instance.reap()
                    except asyncio.CancelledError:
                        raise
                    except Exception:
                        logger.warning("mock_resource_reaper_failed")
                    await asyncio.sleep(0.25)
            mock_reaper_task = asyncio.create_task(reap_mock_resources())
        if settings.product_edition == "global" and settings.global_resume_optimizer_enabled:
            from app.deps import resume_optimizer_service
            from app.services.resume_optimizer_service import ResumeOptimizerRuntime
            if settings.chat_qwen_api_key and settings.chat_qwen_base_url:
                optimizer_service = await asyncio.to_thread(resume_optimizer_service)
                resume_optimizer_runtime = ResumeOptimizerRuntime(optimizer_service)
                await resume_optimizer_runtime.start()
        try:
            yield
        finally:
            if resume_optimizer_runtime is not None:
                await resume_optimizer_runtime.shutdown()
            from app.deps import realtime_speech_service

            service = realtime_speech_service()
            if mock_reaper_task is not None:
                mock_reaper_task.cancel()
                with suppress(asyncio.CancelledError):
                    await mock_reaper_task
            if mock_runtime_instance is not None:
                await mock_runtime_instance.shutdown()
            stop_reclamation = getattr(service, "stop_reclamation", None)
            if callable(stop_reclamation):
                stop_reclamation()
            if task is not None:
                task.cancel()
                with suppress(asyncio.CancelledError):
                    await task
            if reaper_task is not None:
                reaper_task.cancel()
                with suppress(asyncio.CancelledError):
                    await reaper_task
            # Test clients may create multiple application lifespans while
            # sharing the dependency singleton; keep that singleton reusable
            # during pytest and close it for the real process shutdown.
            if realtime_service_instance is not None and not os.environ.get("PYTEST_CURRENT_TEST"):
                await asyncio.to_thread(realtime_service_instance.shutdown)
            realtime_event_wait_executor.shutdown()
            screenshot_event_wait_executor.shutdown()
            screenshot_stream_admission.shutdown()
            realtime_control_executor.shutdown()
            live_answer_stream_executor.shutdown()
            from app.deps import llm_gateway_port

            if llm_gateway_port.cache_info().currsize:
                gateway = llm_gateway_port()
                close = getattr(gateway, "close", None)
                if callable(close):
                    close()

    application = FastAPI(title=settings.app_name, version=settings.app_version, lifespan=lifespan)
    from app.modules.resume_optimizer import ResumeOptimizerPrivacyMiddleware
    application.add_middleware(ResumeOptimizerPrivacyMiddleware, api_prefix=settings.api_prefix)
    application.state.live_answer_stream_executor = live_answer_stream_executor
    application.add_middleware(
        CORSMiddleware,
        allow_origins=[
            *settings.cors_allowed_origins,
            *(settings.admin_allowed_origins if settings.admin_enabled else []),
        ],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
        expose_headers=[settings.request_id_header, "X-OfferSteady-App-Version", "X-OfferSteady-Environment"],
    )
    application.add_middleware(RequestContextMiddleware, settings=settings, logger=logger)
    install_exception_handlers(application, settings=settings, logger=logger)

    @application.get("/healthz", response_model=ApiEnvelope[HealthResponse])
    async def healthz(request: Request) -> ApiEnvelope[HealthResponse]:
        return success_response(
            request=request,
            data=HealthResponse(
                status="ok",
                service=settings.app_name,
                version=settings.app_version,
                environment=settings.environment,
            ),
            timestamp=utc_now_iso(),
        )

    application.include_router(api_router, prefix=settings.api_prefix)
    application.include_router(admin_router, prefix=settings.api_prefix)
    application.include_router(admin_promotion_router, prefix=settings.api_prefix)
    application.include_router(admin_global_commerce_router, prefix=settings.api_prefix)
    application.include_router(public_promotion_router)
    return application


app = create_app()
