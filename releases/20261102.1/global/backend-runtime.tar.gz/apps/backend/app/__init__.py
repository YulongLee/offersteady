"""OfferSteady backend foundation package."""
