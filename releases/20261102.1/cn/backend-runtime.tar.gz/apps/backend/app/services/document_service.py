from __future__ import annotations

import hashlib
from dataclasses import dataclass, field, replace
from pathlib import PurePath
from time import time
from typing import TYPE_CHECKING, Callable
from uuid import uuid4

from app.core.errors import DomainRequestError
from app.core.config import get_settings
from app.material_formats import (
    MaterialFormatId,
    MaterialKind,
    detect_material_format,
    is_material_mime_allowed,
    material_upload_accept,
    material_upload_formats,
    material_upload_label,
)
from app.ports.commercial_hardening import CommercialHardeningRepository, CommercialJobRecord, MaterialArtifactRecord
from app.ports.document_repository import DocumentRecord, DocumentRepository
from app.ports.storage import FileStoragePort
from app.schemas.document_service import (
    CompleteDocumentUploadResponse,
    DocumentProcessingHandoffResponse,
    DocumentRecordResponse,
    DocumentUploadIntentResponse,
    DocumentValidationPolicyResponse,
)
from app.schemas.material_upload import CreatedKnowledgeCollectionResponse
from app.schemas.material_upload import KnowledgeUploadQuoteResponse
from app.services.material_deletion import InMemoryMaterialDeletionScheduler
from app.services.material_object_keys import MaterialObjectKeyFactory
from app.services.commercial_hardening import artifact_id, job_id
from app.services.knowledge_index_quote import estimate_normalized_markdown_tokens
from app.services.billing_service import KNOWLEDGE_INDEX_QUOTE_TTL_MS

if TYPE_CHECKING:
    from app.services.billing_service import BillingService
    from app.services.document_processing import DocumentProcessingService


def _now_ms() -> int:
    return int(time() * 1000)


@dataclass
class InMemoryKnowledgeCollectionStore:
    collections: dict[str, CreatedKnowledgeCollectionResponse] = field(default_factory=dict)

    def get_collection(self, collection_id: str) -> CreatedKnowledgeCollectionResponse | None:
        return self.collections.get(collection_id)

    def save_collection(self, collection: CreatedKnowledgeCollectionResponse) -> CreatedKnowledgeCollectionResponse:
        self.collections[collection.collection_id] = collection
        return collection

    def delete_collection(self, collection_id: str) -> None:
        self.collections.pop(collection_id, None)


@dataclass
class DocumentService:
    storage: FileStoragePort
    repository: DocumentRepository
    knowledge_store: InMemoryKnowledgeCollectionStore
    processing_service: DocumentProcessingService | None = None
    deletion_scheduler: InMemoryMaterialDeletionScheduler | None = None
    commercial_repository: CommercialHardeningRepository | None = None
    billing_service: BillingService | None = None
    max_file_size_bytes: int = 20 * 1024 * 1024
    optimizer_delete_hook: Callable[[DocumentRecord, int], None] | None = None

    @staticmethod
    def _safe_display_name(value: str) -> str:
        clean = PurePath(value.replace("\\", "/")).name.strip()
        if not clean:
            raise DomainRequestError("document-service", "display-name", "资料名称不能为空。")
        if len(clean) > 160:
            raise DomainRequestError("document-service", "display-name", "资料名称不能超过 160 个字符。")
        return clean

    @staticmethod
    def _numbered_display_name(value: str, number: int) -> str:
        suffix = PurePath(value).suffix
        stem = value[: -len(suffix)] if suffix else value
        return f"{stem} ({number}){suffix}"

    def _unique_display_name(
        self,
        *,
        user_id: str,
        document_kind: MaterialKind,
        requested_name: str,
        exclude_document_id: str | None = None,
    ) -> str:
        clean = self._safe_display_name(requested_name)
        occupied = {
            item.display_name.casefold()
            for item in self.repository.list_for_user(
                user_id=user_id,
                document_kind=document_kind,
                include_deleted=False,
            )
            if item.document_id != exclude_document_id
        }
        if clean.casefold() not in occupied:
            return clean
        number = 2
        while self._numbered_display_name(clean, number).casefold() in occupied:
            number += 1
        return self._numbered_display_name(clean, number)

    def validation_policy(self) -> DocumentValidationPolicyResponse:
        formats = material_upload_formats()
        return DocumentValidationPolicyResponse(
            maxFileSizeBytes=self.max_file_size_bytes,
            acceptedExtensions=[extension for item in formats for extension in item["extensions"]],
            acceptedMimeTypes=[mime for item in formats for mime in item["mimeTypes"]],
            label=material_upload_label(),
        )

    def _validate_file(self, *, filename: str, content_type: str, size_bytes: int) -> MaterialFormatId:
        if size_bytes > self.max_file_size_bytes:
            raise DomainRequestError("document-service", "create-upload-intent", f"文件大小不能超过 {self.max_file_size_bytes // (1024 * 1024)} MB。")
        file_kind = detect_material_format(filename)
        if file_kind is None or not is_material_mime_allowed(file_kind, content_type):
            raise DomainRequestError("document-service", "create-upload-intent", f"当前仅支持 {material_upload_label()} 文件上传。")
        return file_kind

    def create_upload_intent(
        self,
        *,
        user_id: str,
        document_kind: MaterialKind,
        filename: str,
        content_type: str,
        size_bytes: int,
        knowledge_collection_id: str | None = None,
    ) -> DocumentUploadIntentResponse:
        file_kind = self._validate_file(filename=filename, content_type=content_type, size_bytes=size_bytes)
        reservation = self.storage.create_upload_intent(
            user_id=user_id,
            material_kind=document_kind,
            filename=filename,
            file_kind=file_kind,
            content_type=content_type,
        )
        return DocumentUploadIntentResponse(
            intentId=reservation.intent_id,
            userId=reservation.user_id,
            documentKind=reservation.material_kind,
            filename=reservation.filename,
            fileKind=reservation.file_kind,
            contentType=reservation.content_type,
            objectKey=reservation.object_key,
            uploadMethod=reservation.upload_method,
            uploadUrl=reservation.upload_url,
            uploadFields=reservation.upload_fields,
            issuedAtMs=reservation.issued_at_ms,
            expiresAtMs=reservation.expires_at_ms,
        )

    def save_upload_bytes(
        self,
        *,
        user_id: str,
        intent_id: str,
        object_key: str,
        content_type: str,
        payload: bytes,
    ) -> dict[str, int | str]:
        if len(payload) > self.max_file_size_bytes:
            raise DomainRequestError("document-service", "proxy-upload", f"文件大小不能超过 {self.max_file_size_bytes // (1024 * 1024)} MB。")
        confirmed = self.storage.save_intent_object(
            user_id=user_id,
            intent_id=intent_id,
            object_key=object_key,
            content_type=content_type,
            payload=payload,
            etag=f"proxy:{len(payload)}",
        )
        return {"objectKey": confirmed.object_key, "sizeBytes": confirmed.size_bytes, "etag": confirmed.etag or ""}

    def complete_upload(
        self,
        *,
        user_id: str,
        intent_id: str,
        object_key: str,
        content_type: str,
        size_bytes: int,
        etag: str | None,
        content_sha256: str | None = None,
        knowledge_collection_id: str | None = None,
        confirm_index_charge: bool = False,
        quote_id: str | None = None,
    ) -> CompleteDocumentUploadResponse:
        confirmed = self.storage.confirm_uploaded_object(
            user_id=user_id,
            intent_id=intent_id,
            object_key=object_key,
            content_type=content_type,
            size_bytes=size_bytes,
            etag=etag,
            content_sha256=content_sha256,
        )
        if confirmed.material_kind == "knowledge":
            self._require_collection_access(user_id=user_id, collection_id=knowledge_collection_id)
            if not confirm_index_charge:
                raise DomainRequestError("knowledge", "complete-upload", "请先确认知识资料索引报价。", 400)
        prequoted_document: DocumentRecord | None = None
        if confirmed.document_id:
            existing = self.repository.get_by_id(confirmed.document_id)
            if existing is not None:
                if existing.owner_user_id != user_id:
                    raise DomainRequestError("document-service", "complete-upload", "不能确认其他用户的文档。", 403)
                if existing.status != "uploaded":
                    return CompleteDocumentUploadResponse(document=self._to_response(existing))
                prequoted_document = existing
        now_ms = confirmed.confirmed_at_ms
        document_record = DocumentRecord(
            document_id=confirmed.document_id or f"document-{uuid4().hex}",
            owner_user_id=user_id,
            document_kind=confirmed.material_kind,
            display_name=self._unique_display_name(
                user_id=user_id,
                document_kind=confirmed.material_kind,
                requested_name=confirmed.filename,
                exclude_document_id=confirmed.document_id,
            ),
            file_kind=confirmed.file_kind,
            content_type=confirmed.content_type,
            size_bytes=confirmed.size_bytes,
            object_key=confirmed.object_key,
            status="processing_requested",
            knowledge_collection_id=knowledge_collection_id,
            processing_requested_at_ms=now_ms,
            deleted_at_ms=None,
            created_at_ms=now_ms,
            updated_at_ms=now_ms,
            summary="文件已上传，后台正在建立可供 AI 使用的文档索引。",
            object_id=confirmed.object_id,
            document_version_id=confirmed.document_version_id,
            version=1,
            content_fingerprint=confirmed.content_fingerprint,
            original_filename=confirmed.filename,
            index_state="queued",
        )
        if prequoted_document is not None:
            document_record = replace(
                prequoted_document,
                status="processing_requested",
                processing_requested_at_ms=now_ms,
                updated_at_ms=now_ms,
                summary="文件已上传，后台正在建立可供 AI 使用的文档索引。",
                index_state="queued",
            )
        billing_quote_id: str | None = None
        if confirmed.material_kind == "knowledge":
            if self.billing_service is None or not confirmed.document_version_id:
                raise DomainRequestError("knowledge", "index-billing", "知识资料计费服务暂不可用，请稍后重试。", 503)
            quote = self.billing_service.quote_knowledge_index(
                user_id=user_id,
                document_version_id=confirmed.document_version_id,
                token_estimate=self._knowledge_token_estimate(document=document_record),
                idempotency_key=f"knowledge-index:{confirmed.document_version_id}:legacy",
            ) if quote_id is None else self.billing_service.knowledge_index_quote(
                user_id=user_id,
                quote_id=quote_id,
                document_version_id=confirmed.document_version_id,
            )
            if quote_id is None:
                rates = self.billing_service.rates()
                legacy_tokens = max(1, (confirmed.size_bytes + 3) // 4)
                legacy_points = max(
                    int(rates["knowledgeIndexMinimumPoints"]),
                    ((legacy_tokens + 4999) // 5000) * int(rates["knowledgeIndexPointsPer1000Tokens"]) * 5,
                )
                if quote.points_required > legacy_points:
                    raise DomainRequestError("knowledge", "index-billing", "服务端最终报价高于旧版页面估算，请刷新页面后重新确认。", 409)
            reservation = self.billing_service.reserve_knowledge_index_for_quote(
                user_id=user_id,
                quote_id=quote.quote_id,
                document_version_id=confirmed.document_version_id,
            )
            if reservation.status != "reserved":
                raise DomainRequestError("knowledge", "index-billing", "积分或会员知识资料额度不足，文件尚未开始建立索引。", 402)
            billing_quote_id = quote.quote_id
        try:
            document = self.repository.save(document_record)
            self._record_original_artifact(document=document, verified_at_ms=now_ms)
            if self.processing_service is not None:
                self.processing_service.submit_document(document, billing_quote_id=billing_quote_id)
        except Exception:
            if confirmed.material_kind == "knowledge" and confirmed.document_version_id and self.billing_service is not None:
                self.billing_service.release_knowledge_index_for_document(
                    user_id=user_id,
                    document_version_id=confirmed.document_version_id,
                )
            raise
        return CompleteDocumentUploadResponse(document=self._to_response(document))

    def quote_knowledge_upload(
        self,
        *,
        user_id: str,
        intent_id: str,
        object_key: str,
        content_type: str,
        size_bytes: int,
        etag: str | None,
        content_sha256: str | None,
        knowledge_collection_id: str,
    ) -> KnowledgeUploadQuoteResponse:
        self._require_collection_access(user_id=user_id, collection_id=knowledge_collection_id)
        if self.billing_service is None or self.processing_service is None:
            raise DomainRequestError("knowledge", "quote-upload", "知识资料报价服务暂不可用，请稍后重试。", 503)
        confirmed = self.storage.confirm_uploaded_object(
            user_id=user_id,
            intent_id=intent_id,
            object_key=object_key,
            content_type=content_type,
            size_bytes=size_bytes,
            etag=etag,
            content_sha256=content_sha256,
        )
        if confirmed.material_kind != "knowledge" or not confirmed.document_version_id:
            raise DomainRequestError("knowledge", "quote-upload", "当前上传对象不是有效的知识资料。", 409)
        document = self._document_from_confirmed_upload(
            user_id=user_id,
            confirmed=confirmed,
            knowledge_collection_id=knowledge_collection_id,
            status="uploaded",
            summary="文件已上传，等待确认服务端索引报价。",
        )
        existing = self.repository.get_by_id(document.document_id)
        if existing is not None:
            if existing.owner_user_id != user_id:
                raise DomainRequestError("knowledge", "quote-upload", "不能为其他用户的资料创建报价。", 403)
            document = existing
        else:
            document = self.repository.save(document)
            self._record_original_artifact(document=document, verified_at_ms=confirmed.confirmed_at_ms)
        token_estimate = self._knowledge_token_estimate(document=document)
        quote = self.billing_service.quote_knowledge_index(
            user_id=user_id,
            document_version_id=confirmed.document_version_id,
            token_estimate=token_estimate,
            idempotency_key=f"knowledge-index:{confirmed.document_version_id}:preview:{_now_ms() // KNOWLEDGE_INDEX_QUOTE_TTL_MS}",
        )
        state = self.billing_service.state_for_user(user_id=user_id)
        active_pass = state.active_pass or {}
        allowance_remaining = max(
            0,
            int(active_pass.get("knowledgeAllowanceGranted", 0))
            - int(active_pass.get("knowledgeAllowanceUsed", 0))
            - int(active_pass.get("knowledgeAllowanceLocked", 0)),
        )
        return KnowledgeUploadQuoteResponse(
            quoteId=quote.quote_id,
            documentVersionId=quote.document_version_id,
            contentFingerprint=confirmed.content_fingerprint or confirmed.etag or confirmed.document_version_id,
            tokenCount=quote.token_estimate,
            billableUnits=(quote.token_estimate + 4999) // 5000,
            pointCost=quote.points_required,
            entitlementSource="pass_allowance" if allowance_remaining > 0 else "points",
            allowanceRemaining=allowance_remaining,
            catalogVersion=quote.catalog_version,
            tokenizerVersion=quote.tokenizer_version,
            createdAtMs=quote.created_at_ms,
            expiresAtMs=quote.created_at_ms + KNOWLEDGE_INDEX_QUOTE_TTL_MS,
            projectedBalance=quote.projected_balance,
        )

    def _knowledge_token_estimate(self, *, document: DocumentRecord) -> int:
        if self.processing_service is None:
            raise DomainRequestError("knowledge", "quote-upload", "知识资料解析服务暂不可用，请稍后重试。", 503)
        markdown = self.processing_service.parse_document_for_quote(document=document)
        token_estimate = estimate_normalized_markdown_tokens(markdown)
        if token_estimate <= 0:
            raise DomainRequestError("knowledge", "quote-upload", "文件中没有可建立索引的文字内容，不会扣除积分。", 422)
        return token_estimate

    def _document_from_confirmed_upload(
        self,
        *,
        user_id: str,
        confirmed,
        knowledge_collection_id: str | None,
        status: str,
        summary: str,
    ) -> DocumentRecord:
        now_ms = confirmed.confirmed_at_ms
        return DocumentRecord(
            document_id=confirmed.document_id or f"document-{uuid4().hex}",
            owner_user_id=user_id,
            document_kind=confirmed.material_kind,
            display_name=self._unique_display_name(
                user_id=user_id,
                document_kind=confirmed.material_kind,
                requested_name=confirmed.filename,
                exclude_document_id=confirmed.document_id,
            ),
            file_kind=confirmed.file_kind,
            content_type=confirmed.content_type,
            size_bytes=confirmed.size_bytes,
            object_key=confirmed.object_key,
            status=status,
            knowledge_collection_id=knowledge_collection_id,
            processing_requested_at_ms=now_ms if status == "processing_requested" else None,
            deleted_at_ms=None,
            created_at_ms=now_ms,
            updated_at_ms=now_ms,
            summary=summary,
            object_id=confirmed.object_id,
            document_version_id=confirmed.document_version_id,
            version=1,
            content_fingerprint=confirmed.content_fingerprint,
            original_filename=confirmed.filename,
            index_state="queued" if status == "processing_requested" else "not_indexed",
        )

    def list_documents(
        self,
        *,
        user_id: str,
        document_kind: MaterialKind | None = None,
        knowledge_collection_id: str | None = None,
        include_deleted: bool = False,
    ) -> list[DocumentRecordResponse]:
        records = self._list_document_records(
            user_id=user_id,
            document_kind=document_kind,
            knowledge_collection_id=knowledge_collection_id,
            include_deleted=include_deleted,
        )
        return self._document_list_responses(records)

    def list_documents_with_records(
        self,
        *,
        user_id: str,
        document_kind: MaterialKind | None = None,
        knowledge_collection_id: str | None = None,
        include_deleted: bool = False,
    ) -> tuple[list[DocumentRecordResponse], dict[str, DocumentRecord]]:
        """Return one read's views and raw records for request-local reuse only."""
        records = self._list_document_records(
            user_id=user_id,
            document_kind=document_kind,
            knowledge_collection_id=knowledge_collection_id,
            include_deleted=include_deleted,
        )
        # Keep display-name disambiguation out of the authoritative raw records.
        snapshot = {
            record.document_id: replace(record)
            for record in records
            if record.owner_user_id == user_id
        }
        return self._document_list_responses(records), snapshot

    def _list_document_records(
        self,
        *,
        user_id: str,
        document_kind: MaterialKind | None,
        knowledge_collection_id: str | None,
        include_deleted: bool,
    ) -> list[DocumentRecord]:
        if knowledge_collection_id is not None:
            self._require_collection_access(user_id=user_id, collection_id=knowledge_collection_id)
        return self.repository.list_for_user(
            user_id=user_id,
            document_kind=document_kind,
            knowledge_collection_id=knowledge_collection_id,
            include_deleted=include_deleted,
        )

    def _document_list_responses(self, records: list[DocumentRecord]) -> list[DocumentRecordResponse]:
        display_names = self._disambiguated_display_names(records)
        return [self._to_response(record, display_name=display_names[record.document_id]) for record in records]

    def _disambiguated_display_names(self, records: list[DocumentRecord]) -> dict[str, str]:
        reserved = {self._safe_display_name(item.display_name).casefold() for item in records}
        used: set[str] = set()
        result: dict[str, str] = {}
        for record in sorted(records, key=lambda item: (item.created_at_ms, item.document_id)):
            clean = self._safe_display_name(record.display_name)
            candidate = clean
            if candidate.casefold() in used:
                number = 2
                while True:
                    numbered = self._numbered_display_name(clean, number)
                    if numbered.casefold() not in used and numbered.casefold() not in reserved:
                        candidate = numbered
                        break
                    number += 1
            result[record.document_id] = candidate
            used.add(candidate.casefold())
        return result

    def get_document(self, *, user_id: str, document_id: str) -> DocumentRecordResponse:
        record = self.repository.get_by_id(document_id)
        if record is None:
            raise DomainRequestError("document-service", "get-document", "文档不存在。", 404)
        if record.owner_user_id != user_id:
            raise DomainRequestError("document-service", "get-document", "不能查看其他用户的文档。", 403)
        return self._to_response(record)

    def rename_document(self, *, user_id: str, document_id: str, display_name: str) -> DocumentRecordResponse:
        record = self.repository.get_by_id(document_id)
        if record is None or record.status == "deleted":
            raise DomainRequestError("document-service", "rename-document", "文档不存在。", 404)
        if record.owner_user_id != user_id:
            raise DomainRequestError("document-service", "rename-document", "不能修改其他用户的文档。", 403)
        unique_name = self._unique_display_name(
            user_id=user_id,
            document_kind=record.document_kind,
            requested_name=display_name,
            exclude_document_id=document_id,
        )
        if unique_name == record.display_name:
            return self._to_response(record)
        updated = replace(record, display_name=unique_name, updated_at_ms=_now_ms())
        return self._to_response(self.repository.save(updated))

    def download_document(self, *, user_id: str, document_id: str) -> tuple[bytes, str, str]:
        record = self.repository.get_by_id(document_id)
        if record is None or record.status == "deleted":
            raise DomainRequestError("document-service", "download-document", "文档不存在。", 404)
        if record.owner_user_id != user_id:
            raise DomainRequestError("document-service", "download-document", "不能下载其他用户的文档。", 403)
        try:
            payload = self.storage.load_object_bytes(object_key=record.object_key)
        except Exception as exc:
            raise DomainRequestError("document-service", "download-document", "原文件暂时不可下载，请稍后重试。", 404) from exc
        filename = self._safe_display_name(record.original_filename or record.display_name)
        return payload, filename, record.content_type or "application/octet-stream"

    def set_document_enabled(self, *, user_id: str, document_id: str, enabled: bool) -> DocumentRecordResponse:
        record = self.repository.get_by_id(document_id)
        if record is None:
            raise DomainRequestError("document-service", "set-document-availability", "文档不存在。", 404)
        if record.owner_user_id != user_id:
            raise DomainRequestError("document-service", "set-document-availability", "不能修改其他用户的文档。", 403)
        if record.status == "deleted" or record.index_state == "deleted":
            raise DomainRequestError("document-service", "set-document-availability", "已删除的资料不能重新启用。", 409)

        target_index_state = "indexed" if enabled else "disabled"
        if record.index_state == target_index_state:
            return self._to_response(record)
        if record.status != "ready" or record.index_state not in {"indexed", "disabled"}:
            raise DomainRequestError(
                "document-service",
                "set-document-availability",
                "只有已完成索引的资料可以启用或停用。",
                409,
            )

        now_ms = _now_ms()
        updated = DocumentRecord(
            **{
                **record.__dict__,
                "index_state": target_index_state,
                "updated_at_ms": now_ms,
                "summary": "已恢复使用，可在面试准备中选择。" if enabled else "已停用，不参与后续面试检索。",
            }
        )
        return self._to_response(self.repository.save(updated))

    def delete_document(self, *, user_id: str, document_id: str) -> DocumentRecordResponse:
        record = self.repository.get_by_id(document_id)
        if record is None:
            raise DomainRequestError("document-service", "delete-document", "文档不存在。", 404)
        if record.owner_user_id != user_id:
            raise DomainRequestError("document-service", "delete-document", "不能删除其他用户的文档。", 403)
        if record.status == "deleted":
            return self._to_response(record)
        deleting = DocumentRecord(
            **{**record.__dict__, "status": "deleted", "deleted_at_ms": _now_ms(), "updated_at_ms": _now_ms(), "summary": "文档已删除，不再用于面试或后续处理。"}
        )
        if self.optimizer_delete_hook is not None:
            self.optimizer_delete_hook(deleting, deleting.deleted_at_ms or _now_ms())
        saved = self.repository.save(deleting)
        if self.processing_service is not None:
            self.processing_service.release_document_index_reservation(document_id=saved.document_id, user_id=user_id)
        self._enqueue_deletion_job(document=saved, deleted_at_ms=saved.deleted_at_ms or _now_ms())
        if self.deletion_scheduler is not None:
            self.deletion_scheduler.schedule_document_deletion(document=saved, deleted_at_ms=saved.deleted_at_ms or _now_ms())
        else:
            self.storage.delete_object(object_key=saved.object_key)
        return self._to_response(saved)

    def list_processing_handoffs(self, *, user_id: str | None = None) -> list[DocumentProcessingHandoffResponse]:
        records = self.repository.list_for_user(user_id=user_id, include_deleted=False) if user_id else list(self.repository.documents.values())  # type: ignore[attr-defined]
        handoffs = [record for record in records if record.status in {"processing_requested", "processing", "ready", "failed"}]
        return [
            DocumentProcessingHandoffResponse(
                documentId=record.document_id,
                ownerUserId=record.owner_user_id,
                documentKind=record.document_kind,
                objectKey=record.object_key,
                status=record.status,  # type: ignore[arg-type]
                requestedAtMs=record.processing_requested_at_ms,
            )
            for record in handoffs
        ]

    def create_knowledge_collection(self, *, user_id: str, name: str) -> CreatedKnowledgeCollectionResponse:
        now_ms = _now_ms()
        collection = CreatedKnowledgeCollectionResponse(
            collectionId=f"collection-{uuid4().hex}",
            ownerUserId=user_id,
            name=name,
            createdAtMs=now_ms,
            updatedAtMs=now_ms,
        )
        if hasattr(self.knowledge_store, "save_collection"):
            self.knowledge_store.save_collection(collection)  # type: ignore[attr-defined]
        else:
            self.knowledge_store.collections[collection.collection_id] = collection
        return collection

    def rename_knowledge_collection(self, *, user_id: str, collection_id: str, name: str) -> CreatedKnowledgeCollectionResponse:
        collection = self._owned_collection(user_id=user_id, collection_id=collection_id)
        clean_name = name.strip()
        if not clean_name:
            raise DomainRequestError("knowledge", "rename-collection", "资料库名称不能为空。")
        renamed = CreatedKnowledgeCollectionResponse(
            collectionId=collection.collection_id,
            ownerUserId=collection.owner_user_id,
            name=clean_name,
            createdAtMs=collection.created_at_ms,
            updatedAtMs=_now_ms(),
        )
        return self.knowledge_store.save_collection(renamed)  # type: ignore[attr-defined]

    def delete_knowledge_collection(self, *, user_id: str, collection_id: str) -> CreatedKnowledgeCollectionResponse:
        collection = self._owned_collection(user_id=user_id, collection_id=collection_id)
        documents = self.repository.list_for_user(
            user_id=user_id,
            document_kind="knowledge",
            knowledge_collection_id=collection_id,
            include_deleted=False,
        )
        for document in documents:
            self.delete_document(user_id=user_id, document_id=document.document_id)
        self.knowledge_store.delete_collection(collection_id)  # type: ignore[attr-defined]
        return collection

    def create_pasted_job_description(self, *, user_id: str, text: str, display_name: str | None) -> CompleteDocumentUploadResponse:
        cleaned_text = text.strip()
        if not cleaned_text:
            raise DomainRequestError("job-description", "create-text", "JD 文本不能为空。")
        now_ms = _now_ms()
        document_id = f"document-{uuid4().hex}"
        document_version_id = f"version-{uuid4().hex}"
        key_factory = MaterialObjectKeyFactory(get_settings())
        object_id = key_factory.new_object_id()
        title = (display_name or cleaned_text.splitlines()[0][:48] or "职位 JD 文本").strip()
        title = self._unique_display_name(
            user_id=user_id,
            document_kind="job_description",
            requested_name=title,
        )
        markdown = f"# {title}\n\n{cleaned_text}\n"
        payload = markdown.encode("utf-8")
        object_key = key_factory.original_key(
            owner_user_id=user_id,
            document_kind="job_description",
            document_id=document_id,
            document_version_id=document_version_id,
            object_id=object_id,
            file_kind="md",
        )
        self.storage.save_object_bytes(
            object_key=object_key,
            payload=payload,
            content_type="text/markdown; charset=utf-8",
        )
        document = self.repository.save(
            DocumentRecord(
                document_id=document_id,
                owner_user_id=user_id,
                document_kind="job_description",
                display_name=title,
                file_kind="md",
                content_type="text/markdown; charset=utf-8",
                size_bytes=len(payload),
                object_key=object_key,
                status="processing_requested",
                knowledge_collection_id=None,
                processing_requested_at_ms=now_ms,
                deleted_at_ms=None,
                created_at_ms=now_ms,
                updated_at_ms=now_ms,
                summary="文本已保存，等待提取岗位职责与技能要求。",
                object_id=object_id,
                document_version_id=document_version_id,
                version=1,
                content_fingerprint=hashlib.sha256(payload).hexdigest(),
                original_filename=f"{title[:80]}.md",
                index_state="queued",
            )
        )
        self._record_original_artifact(document=document, verified_at_ms=now_ms)
        if self.processing_service is not None:
            self.processing_service.submit_document(document)
        return CompleteDocumentUploadResponse(document=self._to_response(document))

    def create_optimized_resume(self, *, user_id: str, markdown: str, stable_id: str) -> DocumentRecordResponse:
        """Explicit independent optimizer copy; deterministic ids make retries safe."""
        document_id = f"document-opt-{stable_id}"
        version_id = f"version-opt-{stable_id}"
        existing = self.repository.get_by_id(document_id)
        if existing is not None:
            if existing.owner_user_id != user_id or existing.deleted_at_ms is not None or existing.status == "deleted":
                raise DomainRequestError("resume-optimizer", "save-as", "已另存的简历已失效，请重新选择或编辑后再保存。", 409,
                                         error_code="resume_optimizer_source_unavailable")
            document = existing
        else:
            current_ms = _now_ms()
            payload = markdown.encode("utf-8")
            key_factory = MaterialObjectKeyFactory(get_settings())
            key = key_factory.original_key(owner_user_id=user_id, document_kind="resume", document_id=document_id,
                document_version_id=version_id, object_id=stable_id, file_kind="md")
            self.storage.save_object_bytes(object_key=key, payload=payload, content_type="text/markdown; charset=utf-8")
            document = self.repository.save(DocumentRecord(
                document_id=document_id, owner_user_id=user_id, document_kind="resume",
                display_name=self._unique_display_name(user_id=user_id, document_kind="resume", requested_name="优化后简历.md"),
                file_kind="md", content_type="text/markdown; charset=utf-8", size_bytes=len(payload), object_key=key,
                status="processing_requested", knowledge_collection_id=None, processing_requested_at_ms=current_ms,
                deleted_at_ms=None, created_at_ms=current_ms, updated_at_ms=current_ms,
                summary="优化稿已另存，正在准备为可选面试资料。", object_id=stable_id,
                document_version_id=version_id, version=1, content_fingerprint=hashlib.sha256(payload).hexdigest(),
                original_filename="优化后简历.md", index_state="queued"))
            self._record_original_artifact(document=document, verified_at_ms=current_ms)
        if self.processing_service is not None and document.status == "processing_requested":
            task_id = f"task-{version_id}"
            if self.processing_service.task_repository.get_task(task_id) is None:
                self.processing_service.submit_document(document)
        return self._to_response(document)

    def _record_original_artifact(self, *, document: DocumentRecord, verified_at_ms: int) -> None:
        if self.commercial_repository is None or not document.document_version_id:
            return
        self.commercial_repository.save_artifact(
            MaterialArtifactRecord(
                artifact_id=artifact_id(),
                owner_user_id=document.owner_user_id,
                document_id=document.document_id,
                document_version_id=document.document_version_id,
                document_kind=document.document_kind,
                artifact_kind="original",
                object_key=document.object_key,
                sync_status="synced",
                required=True,
                content_type=document.content_type,
                size_bytes=document.size_bytes,
                sha256=document.content_fingerprint,
                verified_at_ms=verified_at_ms,
                created_at_ms=verified_at_ms,
                updated_at_ms=verified_at_ms,
            )
        )

    def _enqueue_deletion_job(self, *, document: DocumentRecord, deleted_at_ms: int) -> None:
        if self.commercial_repository is None:
            return
        object_keys = [document.object_key]
        if document.document_version_id:
            key_factory = MaterialObjectKeyFactory(get_settings())
            object_keys.extend(
                [
                    key_factory.processed_artifact_key(
                        owner_user_id=document.owner_user_id,
                        document_kind=document.document_kind,
                        document_id=document.document_id,
                        document_version_id=document.document_version_id,
                        artifact_kind="normalized_markdown",
                    ),
                    key_factory.processed_artifact_key(
                        owner_user_id=document.owner_user_id,
                        document_kind=document.document_kind,
                        document_id=document.document_id,
                        document_version_id=document.document_version_id,
                        artifact_kind="chunk_manifest",
                    ),
                ]
            )
        self.commercial_repository.enqueue_deletion_job(
            CommercialJobRecord(
                job_id=job_id("deletion"),
                owner_user_id=document.owner_user_id,
                job_kind="deletion",
                status="queued",
                stage="DELETE_REQUESTED",
                document_id=document.document_id,
                document_version_id=document.document_version_id,
                max_retries=3,
                payload={"objectKeys": list(dict.fromkeys(object_keys))},
                created_at_ms=deleted_at_ms,
                updated_at_ms=deleted_at_ms,
                scheduled_after_ms=deleted_at_ms,
            )
        )

    def _require_collection_access(self, *, user_id: str, collection_id: str | None) -> None:
        if not collection_id:
            raise DomainRequestError("knowledge", "document-service", "知识资料上传必须指定资料库。")
        collection = self.knowledge_store.get_collection(collection_id) if hasattr(self.knowledge_store, "get_collection") else self.knowledge_store.collections.get(collection_id)  # type: ignore[attr-defined]
        if collection is None:
            raise DomainRequestError("knowledge", "document-service", "资料库不存在。", 404)
        if collection.owner_user_id != user_id:
            raise DomainRequestError("knowledge", "document-service", "不能把资料写入其他用户的资料库。", 403)

    def _owned_collection(self, *, user_id: str, collection_id: str) -> CreatedKnowledgeCollectionResponse:
        collection = self.knowledge_store.get_collection(collection_id)  # type: ignore[attr-defined]
        if collection is None:
            raise DomainRequestError("knowledge", "collection", "资料库不存在。", 404)
        if collection.owner_user_id != user_id:
            raise DomainRequestError("knowledge", "collection", "不能管理其他用户的资料库。", 403)
        return collection

    def _to_response(self, record: DocumentRecord, *, display_name: str | None = None) -> DocumentRecordResponse:
        return DocumentRecordResponse(
            documentId=record.document_id,
            ownerUserId=record.owner_user_id,
            documentKind=record.document_kind,
            displayName=display_name or record.display_name,
            fileKind=record.file_kind,
            contentType=record.content_type,
            sizeBytes=record.size_bytes,
            objectKey=record.object_key,
            status=record.status,
            knowledgeCollectionId=record.knowledge_collection_id,
            processingRequestedAtMs=record.processing_requested_at_ms,
            deletedAtMs=record.deleted_at_ms,
            createdAtMs=record.created_at_ms,
            updatedAtMs=record.updated_at_ms,
            summary=record.summary,
            objectId=record.object_id,
            documentVersionId=record.document_version_id,
            version=record.version,
            contentFingerprint=record.content_fingerprint,
            originalFilename=record.original_filename,
            indexState=record.index_state,
        )
