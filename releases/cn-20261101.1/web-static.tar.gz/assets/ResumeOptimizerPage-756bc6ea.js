import { n as e, t } from "./jsx-runtime-2Zwg-L3c.js";
import { A as n, F as r, I as i, a, k as o } from "./main-edf518ca.js";
import { n as s, t as c } from "./src-D3iT3zfr.js";
import { a as l, t as u } from "./auth-client-CpBLJDBI.js";
var { useEffect: d, useRef: f, useState: p } = e();
//#endregion
//#region artifacts/cn-resume-optimizer-20261018-release/web/module-src/router.ts
function ee() {
	return [new URLSearchParams(i().search)];
}
//#endregion
//#region artifacts/cn-resume-optimizer-20261018-release/web/module-src/library-processing-polling.ts
var m = /* @__PURE__ */ new Set([
	"ready",
	"failed",
	"deleted",
	"disabled"
]), h = (e, t) => new Promise((n, r) => {
	let i = window.setTimeout(() => {
		t.removeEventListener("abort", a), n();
	}, e), a = () => {
		window.clearTimeout(i), t.removeEventListener("abort", a), r(new DOMException("The operation was aborted", "AbortError"));
	};
	if (t.aborted) {
		a();
		return;
	}
	t.addEventListener("abort", a, { once: !0 });
});
async function te({ documentId: e, loadState: t, signal: n, maxAttempts: r = 45, sleep: i = h }) {
	for (let a = 0; a < r; a += 1) {
		await i(a === 0 ? 800 : 2e3, n);
		let r = await t(n), o = r.librarySources.find((t) => t.id === e), s = r.knowledgeDocuments.find((t) => t.id === e), c = (o == null ? void 0 : o.status) ?? (s == null ? void 0 : s.status);
		if (c && m.has(c)) return {
			kind: "settled",
			state: r
		};
	}
	return { kind: "timeout" };
}
//#endregion
//#region artifacts/cn-resume-optimizer-20261018-release/web/module-src/runtime-config.ts
function g() {
	return { apiBaseUrl: "/" };
}
//#endregion
//#region \0@oxc-project+runtime@0.137.0/helpers/esm/typeof.js
function _(e) {
	"@babel/helpers - typeof";
	return _ = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(e) {
		return typeof e;
	} : function(e) {
		return e && typeof Symbol == "function" && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
	}, _(e);
}
//#endregion
//#region \0@oxc-project+runtime@0.137.0/helpers/esm/toPrimitive.js
function v(e, t) {
	if (_(e) != "object" || !e) return e;
	var n = e[Symbol.toPrimitive];
	if (n !== void 0) {
		var r = n.call(e, t || "default");
		if (_(r) != "object") return r;
		throw TypeError("@@toPrimitive must return a primitive value.");
	}
	return (t === "string" ? String : Number)(e);
}
//#endregion
//#region \0@oxc-project+runtime@0.137.0/helpers/esm/toPropertyKey.js
function y(e) {
	var t = v(e, "string");
	return _(t) == "symbol" ? t : t + "";
}
//#endregion
//#region \0@oxc-project+runtime@0.137.0/helpers/esm/defineProperty.js
function b(e, t, n) {
	return (t = y(t)) in e ? Object.defineProperty(e, t, {
		value: n,
		enumerable: !0,
		configurable: !0,
		writable: !0
	}) : e[t] = n, e;
}
//#endregion
//#region artifacts/cn-resume-optimizer-20261018-release/web/module-src/resume-optimizer-client.ts
var ne = {
	resume_optimizer_insufficient_balance: "可用积分不足 100，请充值或开通时间会员后刷新报价。",
	resume_optimizer_points_confirmation_required: "请明确确认本次 100 积分费用后再开始。",
	resume_optimizer_disabled: "简历优化暂时不可用，请稍后重试。",
	resume_optimizer_membership_required: "请刷新本次优化报价后重试。",
	resume_optimizer_daily_limit: "今日免费次数已用完，请刷新报价后确认是否使用积分。",
	resume_optimizer_busy: "简历优化正在忙碌，请稍后重试。",
	resume_optimizer_not_found: "这次优化已不可用，源资料可能已删除。",
	resume_optimizer_source_unavailable: "所选资料已变化或尚未解析完成，请刷新资料并选择当前版本。",
	resume_optimizer_source_markup_unsupported: "简历或岗位描述含不支持的格式，请上传不含 HTML 标记的纯文本或 Markdown 版本后重试。本次未扣费或占用免费次数。",
	resume_optimizer_idempotency_conflict: "提交内容已变化，请核对输入后重新提交。",
	resume_optimizer_revision_conflict: "其他页面已保存更新版本。已保留你的本地编辑，请重新载入已保存稿后继续。",
	resume_optimizer_not_completed: "请等待优化完成后再编辑或下载。",
	resume_optimizer_invalid_draft: "请填写字数范围内的纯文本或 Markdown，不支持 HTML 和脚本。",
	resume_optimizer_provider_unconfigured: "简历优化暂时不可用，请稍后重试。",
	resume_optimizer_export_unavailable: "暂时无法生成此格式。可尝试 Word，或移除不支持的字符后重试。已保存稿不受影响。",
	resume_optimizer_quote_changed: "本次报价已变化，请核对最新免费次数和积分费用后重新确认。"
}, x = class extends Error {
	constructor(e, t) {
		super(ne[e] ?? (t === 401 ? "登录已过期，请重新登录。" : t >= 500 ? "简历优化暂时不可用，请稍后重试。" : "操作未完成，请刷新后重试。")), b(this, "code", void 0), b(this, "status", void 0), this.code = e, this.status = t, this.name = "ResumeOptimizerError";
	}
}, S = new class {
	constructor(e, t = (e, t) => globalThis.fetch(e, t)) {
		b(this, "baseUrl", void 0), b(this, "fetchImpl", void 0), this.baseUrl = e, this.fetchImpl = t;
	}
	async response(e, t = {}, n) {
		let r = u.readStoredSession(), i = new Headers(t.headers);
		r && i.set("Authorization", `Bearer ${r.accessToken}`), typeof t.body == "string" && i.set("Content-Type", "application/json"), i.set("Accept", e.includes("/export?") ? "application/octet-stream" : "application/json");
		let a;
		try {
			a = await this.fetchImpl(l(this.baseUrl, `/api/v1/resume-optimizer${e}`), {
				...t,
				headers: i,
				cache: "no-store",
				...n ? { signal: n } : {}
			});
		} catch (e) {
			throw n != null && n.aborted || e instanceof DOMException && e.name === "AbortError" ? e : Error("无法连接简历优化服务，请检查网络后重试。");
		}
		if (!a.ok) {
			let e = "";
			try {
				var o, s;
				let t = await a.json();
				e = (t == null || (o = t.error) == null || (o = o.details) == null ? void 0 : o.errorCode) ?? (t == null || (s = t.error) == null ? void 0 : s.code) ?? "";
			} catch {}
			throw new x(e, a.status);
		}
		return a;
	}
	async json(e, t = {}, n) {
		var r;
		let i = await (await this.response(e, t, n)).json();
		if (i.success === !1 || i.data == null) throw new x((i == null || (r = i.error) == null || (r = r.details) == null ? void 0 : r.errorCode) ?? "", 500);
		return i.data;
	}
	capabilities(e) {
		return this.json("/capabilities", {}, e);
	}
	list(e) {
		return this.json("/jobs", {}, e);
	}
	get(e, t) {
		return this.json(`/jobs/${encodeURIComponent(e)}`, {}, t);
	}
	create(e, t) {
		return this.json("/jobs", {
			method: "POST",
			body: JSON.stringify(e)
		}, t);
	}
	cancel(e, t) {
		return this.json(`/jobs/${encodeURIComponent(e)}/cancel`, { method: "POST" }, t);
	}
	remove(e, t) {
		return this.json(`/jobs/${encodeURIComponent(e)}`, { method: "DELETE" }, t);
	}
	saveDraft(e, t, n, r) {
		return this.json(`/jobs/${encodeURIComponent(e)}/draft`, {
			method: "PATCH",
			body: JSON.stringify({
				expectedRevision: t,
				markdown: n
			})
		}, r);
	}
	saveAs(e, t, n) {
		return this.json(`/jobs/${encodeURIComponent(e)}/save-as`, {
			method: "POST",
			body: JSON.stringify({
				expectedRevision: t,
				confirmIndependentCopy: !0,
				factsConfirmed: !0
			})
		}, n);
	}
	async download(e, t, n, r) {
		var i, a;
		let o = await this.response(`/jobs/${encodeURIComponent(e)}/export?${new URLSearchParams({
			format: t,
			expectedRevision: String(n),
			factsConfirmed: "true"
		})}`, {}, r), s = t === "pdf" ? "application/pdf" : "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
		if (((i = o.headers.get("Content-Type")) == null || (i = i.split(";")[0]) == null ? void 0 : i.trim().toLowerCase()) !== s) throw Error("未收到有效的简历文件，请重试下载。");
		let c = await o.blob(), l = new Uint8Array(await c.slice(0, 5).arrayBuffer());
		if (!(t === "pdf" ? new TextDecoder().decode(l) === "%PDF-" : l[0] === 80 && l[1] === 75 && l[2] === 3 && l[3] === 4)) throw Error("未收到有效的简历文件，请重试下载。");
		let u = (a = o.headers.get("Content-Disposition")) == null || (a = a.match(/filename\*=UTF-8''([^;]+)/i)) == null ? void 0 : a[1], d = `优化后的简历.${t}`;
		if (u) try {
			d = decodeURIComponent(u);
		} catch {}
		return d = d.replace(/[\u0000-\u001f\u007f\u202a-\u202e\u2066-\u2069\\/]/g, "-").slice(0, 180), d.toLowerCase().endsWith(`.${t}`) || (d = `优化后的简历.${t}`), {
			blob: c,
			filename: d
		};
	}
}(g({
	BASE_URL: "/",
	DEV: !1,
	MODE: "production",
	PROD: !0,
	SSR: !1
}).apiBaseUrl);
function re({ blob: e, filename: t }) {
	let n = URL.createObjectURL(e), r = document.createElement("a");
	try {
		r.href = n, r.download = t, r.style.display = "none", document.body.appendChild(r), r.click();
	} finally {
		r.remove(), window.setTimeout(() => URL.revokeObjectURL(n), 1e3);
	}
}
//#endregion
//#region artifacts/cn-resume-optimizer-20261018-release/web/module-src/jsx-runtime.ts
var { jsx: C, jsxs: w, Fragment: ie } = t(), ae = (e) => !!(e && (e.status === "queued" || e.status === "running")), T = (e) => e.status === "ready" && e.syncStatus !== "missing_artifacts" && e.selectable !== !1 && !!e.documentVersionId, oe = {
	completeness: "信息完整度",
	impact: "经历与成果依据",
	clarity: "表达清晰度",
	structure: "结构与可读性",
	roleMatch: "岗位匹配度"
}, se = {
	ready: "已就绪",
	processing: "解析中",
	processing_requested: "待解析",
	uploaded: "待解析",
	failed: "解析失败",
	disabled: "已停用"
}, ce = {
	queued: "排队中",
	running: "正在优化",
	completed: "已完成",
	failed: "优化失败",
	cancelled: "已取消"
}, le = (e) => e instanceof Error ? e.message : "操作未完成，请稍后重试。", ue = (e) => new Intl.DateTimeFormat("zh-CN", {
	dateStyle: "medium",
	timeStyle: "short",
	timeZone: "Asia/Shanghai"
}).format(e), de = 120;
function fe({ items: e }) {
	return /* @__PURE__ */ C("div", {
		className: "resume-evidence",
		children: e.map((e, t) => /* @__PURE__ */ w("blockquote", { children: [/* @__PURE__ */ C("small", { children: e.source === "jd" ? "解析后的岗位描述" : "解析后的简历" }), /* @__PURE__ */ C("p", { children: e.quote })] }, t))
	});
}
function E({ state: e, setState: t }) {
	let [i] = ee(), [l, u] = p(null), [m, h] = p([]), [g, _] = p(null), [v, y] = p(i.get("source") ?? ""), [b, de] = p(""), [E, pe] = p("none"), [me, he] = p(""), [D, ge] = p(""), [_e, O] = p(!1), [k, A] = p(null), [j, M] = p("create"), [N, P] = p(!1), [ve, ye] = p(!1), [F, I] = p(""), [L, be] = p(!1), [xe, Se] = p(!0), [R, Ce] = p(""), [we, z] = p(""), [Te, B] = p(""), [Ee, De] = p(!1), V = f(null), Oe = f(!1), H = f(0), ke = f(/* @__PURE__ */ new Set()), Ae = f(0), U = f(null), je = f(null), Me = f(null), Ne = f(null), Pe = f(null), Fe = f(!1), Ie = e.librarySources.filter((t) => t.ownerUserId === e.account.id && t.kind === "resume" && t.status !== "deleted"), Le = e.librarySources.filter((t) => t.ownerUserId === e.account.id && t.kind === "jd" && t.status !== "deleted"), W = Ie.find((e) => e.id === v || e.documentId === v), G = Le.find((e) => e.id === me), K = (g == null ? void 0 : g.status) === "completed" && F !== g.draftMarkdown, q = ae(g) || !!(l != null && l.activeJobId), Re = (l == null ? void 0 : l.billingClass) === "points", ze = f(null), Be = (e) => {
		let t = JSON.stringify([
			e.quotaDay,
			e.billingClass,
			e.entryPoints
		]);
		ze.current !== t && (O(!1), A(null)), ze.current = t, u(e);
	};
	d(() => {
		var e;
		if (!k || !Me.current) return;
		let t = Me.current;
		return typeof t.showModal == "function" ? t.showModal() : t.setAttribute("open", ""), (e = Ne.current) == null || e.focus(), () => {
			t.open && typeof t.close == "function" && t.close(), Fe.current = !0;
		};
	}, [k]), d(() => {
		if (k || R || !Fe.current) return;
		Fe.current = !1;
		let e = Pe.current;
		e && !e.disabled && !e.closest("[hidden]") && e.focus();
	}, [k, R]);
	let J = () => {
		var e;
		return (e = V.current) == null ? void 0 : e.signal;
	}, Y = () => !!(V.current && !V.current.signal.aborted), X = (e, t = !0) => {
		_(e), De(!1), h((t) => [e, ...t.filter((t) => t.jobId !== e.jobId)].slice(0, 30)), t && (I(e.draftMarkdown ?? ""), be(!1), P(!1), ye(!1));
	}, Z = async () => {
		let e = J(), [t, n] = await Promise.all([S.capabilities(e), S.list(e)]);
		if (!(e != null && e.aborted || !Y())) return Be(t), h(n.jobs), t;
	}, Ve = async (e) => {
		let t = ++H.current, n = await S.get(e, J());
		Y() && t === H.current && X(n);
	}, He = async () => {
		Se(!0), B("");
		try {
			let e = await S.capabilities(J());
			if (!Y()) return;
			if (Be(e), e.enabled) {
				let t = await S.list(J());
				if (!Y()) return;
				h(t.jobs), e.activeJobId && (await Ve(e.activeJobId), Y() && M("history"));
			}
		} catch (e) {
			Y() && B(le(e));
		} finally {
			Y() && Se(!1);
		}
	};
	d(() => {
		let e = new AbortController();
		return V.current = e, He(), () => {
			e.abort(), H.current += 1, V.current = null;
		};
	}, []), d(() => {
		if (!g || g.billingClass !== "points") return;
		let r = `${g.jobId}:${g.billingStatus === "released" ? "refunded" : "charged"}`;
		if (ke.current.has(r)) return;
		ke.current.add(r);
		let i = ++Ae.current, a = J();
		n.getBillingState(a).then((n) => {
			!Y() || a != null && a.aborted || i !== Ae.current || t((t) => t.account.id === e.account.id ? {
				...t,
				billing: n
			} : t);
		}).catch(() => {
			ke.current.delete(r), Y() && i === Ae.current && z("优化状态已更新，积分明细暂未同步；本页可用积分以最新报价为准，可到积分与会员页刷新。");
		});
	}, [
		g == null ? void 0 : g.jobId,
		g == null ? void 0 : g.billingClass,
		g == null ? void 0 : g.billingStatus
	]), d(() => {
		O(!1), A(null);
	}, [
		W == null ? void 0 : W.documentVersionId,
		G == null ? void 0 : G.documentVersionId,
		b,
		E,
		D
	]), d(() => {
		var e;
		if (!g || !ae(g) || Ee) return;
		let t = new AbortController(), n = () => t.abort();
		(e = V.current) == null || e.signal.addEventListener("abort", n, { once: !0 });
		let r = H.current, i, a = 0, o = async () => {
			try {
				let e = await S.get(g.jobId, t.signal);
				if (t.signal.aborted || r !== H.current) return;
				if (_(e), h((t) => t.map((t) => t.jobId === e.jobId ? e : t)), !ae(e)) {
					X(e), await Z();
					return;
				}
				if (a += 1, a >= 120) {
					De(!0), z("任务仍在处理中，已暂停自动查询。可点击“刷新进度”查看最新结果。");
					return;
				}
				i = window.setTimeout(() => void o(), 2e3);
			} catch (e) {
				if (t.signal.aborted || r !== H.current) return;
				De(!0), B(le(e)), e instanceof x && e.status === 404 && (_(null), I(""), P(!1), Z().catch(() => void 0));
			}
		};
		return i = window.setTimeout(() => void o(), 2e3), () => {
			var e;
			t.abort(), i !== void 0 && window.clearTimeout(i), (e = V.current) == null || e.signal.removeEventListener("abort", n);
		};
	}, [
		g == null ? void 0 : g.jobId,
		g == null ? void 0 : g.status,
		Ee
	]), d(() => {
		if (!(l != null && l.enabled)) return;
		let e = Math.max(100, Math.min(l.resetAtMs - l.nowMs + 100, 2147e6)), t = () => {
			Z().catch((e) => {
				Y() && B(le(e));
			});
		}, n = () => {
			document.visibilityState === "visible" && t();
		}, r = window.setTimeout(t, e);
		return window.addEventListener("focus", t), document.addEventListener("visibilitychange", n), () => {
			window.clearTimeout(r), window.removeEventListener("focus", t), document.removeEventListener("visibilitychange", n);
		};
	}, [
		l == null ? void 0 : l.resetAtMs,
		l == null ? void 0 : l.nowMs,
		l == null ? void 0 : l.enabled
	]);
	let Q = async (e, t) => {
		if (!Oe.current) {
			Oe.current = !0, Ce(e), B(""), z("");
			try {
				await t();
			} catch (e) {
				Y() && B(le(e));
			} finally {
				Oe.current = !1, Y() && Ce("");
			}
		}
	}, $ = async (e = J()) => {
		let r = await n.loadState(e);
		return Y() && !(e != null && e.aborted) && t(r), r;
	}, Ue = (t) => void Q("upload", async () => {
		if (!c(t.name)) throw Error("请选择 PDF、DOCX、DOC、TXT 或 Markdown 简历。");
		if (t.size > 20 * 1024 * 1024) throw Error("请选择不超过 20 MB 的简历。");
		let n = await a.uploadResume(e.account.id, t, J());
		if (!Y() || (await $(), !Y())) return;
		y(n.source.sourceId), O(!1), z("简历已上传，正在解析，完成后即可优化。");
		let r = await te({
			documentId: n.source.sourceId,
			signal: J(),
			loadState: $
		});
		Y() && z(r.kind === "timeout" ? "资料仍在解析中，稍后刷新资料即可查看状态。" : "资料处理已结束，请选择解析完成的简历继续。");
	}), We = (e = !1) => void Q("create", async () => {
		var t;
		let n = l ? JSON.stringify([
			l.quotaDay,
			l.billingClass,
			l.entryPoints
		]) : null;
		if (!(l != null && l.enabled) || !l.canStart || q || !W || !T(W) || !_e || Re && (!e || k !== n)) return;
		let r = {
			sourceDocumentId: W.documentId ?? W.id,
			sourceVersionId: W.documentVersionId,
			targetRole: b.trim(),
			jdDocumentId: E === "material" ? (G == null ? void 0 : G.documentId) ?? (G == null ? void 0 : G.id) ?? null : null,
			jdVersionId: E === "material" ? (G == null ? void 0 : G.documentVersionId) ?? null : null,
			jdText: E === "text" ? D.trim() : "",
			quotedQuotaDay: l.quotaDay,
			quotedBillingClass: l.billingClass,
			quotedPoints: l.entryPoints,
			confirmPointsCharge: Re && e,
			confirmProcessing: !0
		};
		if (E === "material" && (!G || !T(G))) throw Error("请选择已解析完成的岗位描述后继续。");
		let { quotedQuotaDay: i, quotedBillingClass: a, quotedPoints: o, confirmPointsCharge: s, confirmProcessing: c, ...u } = r, d = JSON.stringify(u);
		((t = U.current) == null ? void 0 : t.fingerprint) !== d && (U.current = {
			fingerprint: d,
			key: crypto.randomUUID()
		});
		try {
			let e = await S.create({
				...r,
				idempotencyKey: U.current.key
			}, J());
			if (!Y()) return;
			X(e), M("history"), U.current = null, O(!1), A(null), await Z();
		} catch (e) {
			throw Y() && A(null), Y() && e instanceof x && ((e.code === "resume_optimizer_quote_changed" || e.code === "resume_optimizer_insufficient_balance") && (O(!1), A(null), U.current = null), await Z().catch(() => void 0)), e;
		}
	}), Ge = () => {
		Re && l ? A(JSON.stringify([
			l.quotaDay,
			l.billingClass,
			l.entryPoints
		])) : We();
	}, Ke = (e) => {
		K && !window.confirm("放弃尚未保存的本地修改，并打开这次优化？") || Q("open", () => Ve(e));
	}, qe = async (e) => {
		if (e instanceof x && e.code === "resume_optimizer_revision_conflict" && g) {
			let e = await S.get(g.jobId, J());
			Y() && (X(e, !1), be(!0), P(!1));
		} else e instanceof x && e.status === 404 && Y() && (_(null), I(""), P(!1));
		throw e;
	}, Je = () => {
		g && Q("draft", async () => {
			try {
				let e = await S.saveDraft(g.jobId, g.revision, F, J());
				Y() && (X(e), z("草稿已保存，原简历和 AI 初稿保留。"));
			} catch (e) {
				await qe(e);
			}
		});
	}, Ye = (e) => {
		!g || !N || K || L || Q(e, async () => {
			try {
				let t = await S.download(g.jobId, e, g.revision, J());
				Y() && (re(t), z(`${e === "docx" ? "Word" : "PDF"}已开始下载，内容来自已保存稿。`));
			} catch (e) {
				await qe(e);
			}
		});
	};
	return /* @__PURE__ */ w("main", {
		className: "app-page resume-optimizer-page",
		children: [
			/* @__PURE__ */ w("header", {
				className: "page-header",
				children: [/* @__PURE__ */ w("div", { children: [/* @__PURE__ */ C("h1", { children: "简历优化" }), /* @__PURE__ */ C("p", { children: "让你的经历，表达得更清楚。" })] }), /* @__PURE__ */ C(r, {
					className: "button ghost",
					to: o.library,
					children: "我的资料"
				})]
			}),
			Te ? /* @__PURE__ */ C("div", {
				className: "inline-error",
				role: "alert",
				children: Te
			}) : null,
			we ? /* @__PURE__ */ C("div", {
				className: "billing-notice",
				role: "status",
				children: we
			}) : null,
			xe ? /* @__PURE__ */ C("section", {
				className: "panel resume-loading",
				role: "status",
				children: "正在加载…"
			}) : l ? l.enabled ? /* @__PURE__ */ w(ie, { children: [
				/* @__PURE__ */ w("div", {
					className: "resume-tabs",
					role: "tablist",
					"aria-label": "简历优化工作区",
					onKeyDown: (e) => {
						var t;
						if (![
							"ArrowLeft",
							"ArrowRight",
							"Home",
							"End"
						].includes(e.key)) return;
						e.preventDefault();
						let n = e.key === "Home" ? "create" : e.key === "End" || j === "create" ? "history" : "create";
						M(n), (t = e.currentTarget.querySelector(`#resume-${n}-tab`)) == null || t.focus();
					},
					children: [/* @__PURE__ */ C("button", {
						id: "resume-create-tab",
						role: "tab",
						tabIndex: j === "create" ? 0 : -1,
						"aria-selected": j === "create",
						"aria-controls": "resume-create-panel",
						onClick: () => M("create"),
						children: "新建优化"
					}), /* @__PURE__ */ w("button", {
						id: "resume-history-tab",
						role: "tab",
						tabIndex: j === "history" ? 0 : -1,
						"aria-selected": j === "history",
						"aria-controls": "resume-history-panel",
						onClick: () => M("history"),
						children: ["我的优化记录", m.length ? /* @__PURE__ */ C("span", {
							"aria-hidden": "true",
							children: m.length
						}) : null]
					})]
				}),
				/* @__PURE__ */ w("section", {
					id: "resume-create-panel",
					role: "tabpanel",
					"aria-labelledby": "resume-create-tab",
					hidden: j !== "create",
					className: "panel resume-create",
					children: [
						/* @__PURE__ */ w("div", {
							className: "resume-form-heading",
							children: [/* @__PURE__ */ C("h2", { children: "从一份简历开始" }), /* @__PURE__ */ C("p", { children: "获取评分、修改建议与可下载的优化稿。原文件会保留。" })]
						}),
						/* @__PURE__ */ w("div", {
							className: "resume-field",
							children: [
								/* @__PURE__ */ w("div", {
									className: "resume-field-heading",
									children: [/* @__PURE__ */ C("label", {
										htmlFor: "optimizer-resume",
										children: "选择简历"
									}), /* @__PURE__ */ C("button", {
										type: "button",
										className: "resume-text-button",
										disabled: !!R,
										onClick: () => void Q("materials", async () => {
											await $(), Y() && z("资料已刷新。");
										}),
										children: "刷新资料"
									})]
								}),
								/* @__PURE__ */ w("div", {
									className: "resume-input-row",
									children: [
										/* @__PURE__ */ w("select", {
											id: "optimizer-resume",
											value: (W == null ? void 0 : W.id) ?? v,
											disabled: !!R || q,
											onChange: (e) => {
												y(e.target.value), O(!1), A(null);
											},
											children: [/* @__PURE__ */ C("option", {
												value: "",
												children: "请选择简历"
											}), Ie.map((e) => /* @__PURE__ */ w("option", {
												value: e.id,
												disabled: !T(e),
												children: [
													e.displayName,
													" · ",
													T(e) ? e.version : e.status === "ready" ? "请刷新版本" : se[e.status] ?? "暂不可用"
												]
											}, e.id))]
										}),
										/* @__PURE__ */ C("button", {
											className: "button ghost",
											disabled: !!R || q,
											onClick: () => {
												var e;
												return (e = je.current) == null ? void 0 : e.click();
											},
											children: R === "upload" ? "正在处理…" : "上传简历"
										}),
										/* @__PURE__ */ C("input", {
											ref: je,
											type: "file",
											accept: s,
											"aria-label": "上传简历文件",
											hidden: !0,
											onChange: (e) => {
												var t;
												let n = (t = e.target.files) == null ? void 0 : t[0];
												e.target.value = "", n && Ue(n);
											}
										})
									]
								}),
								Ie.length ? null : /* @__PURE__ */ C("p", {
									className: "resume-muted",
									children: "支持 PDF、Word、TXT 和 Markdown。"
								}),
								W && !T(W) ? /* @__PURE__ */ C("p", {
									className: "resume-muted",
									children: "这份简历尚未就绪，请解析完成后刷新资料。"
								}) : null
							]
						}),
						/* @__PURE__ */ w("div", {
							className: "resume-field",
							children: [/* @__PURE__ */ w("label", {
								htmlFor: "optimizer-role",
								children: ["目标岗位 ", /* @__PURE__ */ C("span", { children: "选填" })]
							}), /* @__PURE__ */ C("input", {
								id: "optimizer-role",
								value: b,
								maxLength: l.limits.targetRoleCharacters,
								placeholder: "例如：后端工程师",
								disabled: !!R || q,
								onChange: (e) => {
									de(e.target.value), O(!1);
								}
							})]
						}),
						/* @__PURE__ */ w("details", {
							className: "resume-jd",
							children: [/* @__PURE__ */ w("summary", { children: ["添加岗位描述 ", /* @__PURE__ */ C("span", { children: "可选，让建议更有针对性" })] }), /* @__PURE__ */ w("div", {
								className: "resume-jd-content",
								children: [
									/* @__PURE__ */ C("label", {
										className: "sr-only",
										htmlFor: "optimizer-jd-mode",
										children: "岗位描述"
									}),
									/* @__PURE__ */ w("select", {
										id: "optimizer-jd-mode",
										value: E,
										disabled: !!R || q,
										onChange: (e) => {
											pe(e.target.value), O(!1);
										},
										children: [
											/* @__PURE__ */ C("option", {
												value: "none",
												children: "通用简历诊断，不提供 JD"
											}),
											/* @__PURE__ */ C("option", {
												value: "text",
												children: "粘贴岗位描述"
											}),
											/* @__PURE__ */ C("option", {
												value: "material",
												children: "选择资料库中的 JD"
											})
										]
									}),
									E === "text" ? /* @__PURE__ */ w(ie, { children: [
										/* @__PURE__ */ C("label", {
											className: "sr-only",
											htmlFor: "optimizer-jd-text",
											children: "岗位描述正文"
										}),
										/* @__PURE__ */ C("textarea", {
											id: "optimizer-jd-text",
											rows: 6,
											value: D,
											maxLength: l.limits.jdCharacters,
											disabled: !!R || q,
											onChange: (e) => {
												ge(e.target.value), O(!1);
											},
											placeholder: "粘贴岗位职责和要求"
										}),
										/* @__PURE__ */ w("small", {
											className: "resume-muted",
											children: [
												D.length.toLocaleString(),
												" / ",
												l.limits.jdCharacters.toLocaleString(),
												" 字"
											]
										})
									] }) : E === "material" ? /* @__PURE__ */ w("select", {
										"aria-label": "资料库中的 JD",
										value: me,
										disabled: !!R || q,
										onChange: (e) => {
											he(e.target.value), O(!1), A(null);
										},
										children: [/* @__PURE__ */ C("option", {
											value: "",
											children: "请选择已解析完成的岗位描述"
										}), Le.map((e) => /* @__PURE__ */ w("option", {
											value: e.id,
											disabled: !T(e),
											children: [
												e.displayName,
												" · ",
												T(e) ? e.version : se[e.status] ?? "暂不可用"
											]
										}, e.id))]
									}) : /* @__PURE__ */ C("p", {
										className: "resume-muted",
										children: "未提供 JD 时进行通用简历诊断，不评估岗位匹配度。"
									})
								]
							})]
						}),
						/* @__PURE__ */ w("div", {
							className: "resume-start-footer",
							children: [
								/* @__PURE__ */ w("label", {
									className: "resume-check",
									children: [/* @__PURE__ */ C("input", {
										type: "checkbox",
										checked: _e,
										disabled: !!R || q,
										onChange: (e) => O(e.target.checked)
									}), /* @__PURE__ */ C("span", { children: "我同意使用 AI 处理所选资料并保存优化结果。" })]
								}),
								/* @__PURE__ */ w("details", {
									className: "resume-disclosure",
									children: [
										/* @__PURE__ */ C("summary", { children: "处理与使用说明" }),
										/* @__PURE__ */ C("p", { children: "所选简历和岗位描述将发送至配置的 AI 服务。输入快照、建议和草稿随任务保存，直到你删除任务；删除引用的源资料也会清理对应优化内容。" }),
										/* @__PURE__ */ C("p", { children: "有效时间会员每日免费 3 次，与模拟面试次数独立。编辑、下载和另存不再收费。未完成任务失败或取消时，退还原创建日次数或原扣积分一次；已完成后删除不退还。" })
									]
								}),
								/* @__PURE__ */ C("button", {
									ref: Pe,
									className: "button primary full",
									disabled: !!R || q || !Re && !l.canStart || !W || !T(W) || !_e || E === "material" && (!G || !T(G)) || E === "text" && !D.trim(),
									onClick: Ge,
									children: R === "create" ? "正在开始优化…" : q ? "已有优化任务处理中" : "开始优化"
								})
							]
						})
					]
				}),
				/* @__PURE__ */ w("section", {
					id: "resume-history-panel",
					role: "tabpanel",
					"aria-labelledby": "resume-history-tab",
					hidden: j !== "history",
					className: "resume-history",
					children: [/* @__PURE__ */ w("div", {
						className: "resume-history-heading",
						children: [/* @__PURE__ */ C("h2", { children: "优化记录" }), /* @__PURE__ */ C("button", {
							className: "resume-text-button",
							disabled: !!R,
							onClick: () => void Q("refresh", async () => {
								await Z();
							}),
							children: "刷新"
						})]
					}), m.length ? /* @__PURE__ */ C("ul", { children: m.map((e) => /* @__PURE__ */ C("li", { children: /* @__PURE__ */ w("button", {
						className: (g == null ? void 0 : g.jobId) === e.jobId ? "selected" : "",
						disabled: !!R,
						onClick: () => Ke(e.jobId),
						children: [/* @__PURE__ */ w("span", { children: [/* @__PURE__ */ C("strong", { children: e.sourceDisplayName }), /* @__PURE__ */ w("small", { children: [
							e.targetRole || "通用简历诊断",
							" · ",
							ue(e.createdAtMs)
						] })] }), /* @__PURE__ */ C("span", {
							className: `resume-status ${e.status}`,
							children: ce[e.status]
						})]
					}) }, e.jobId)) }) : /* @__PURE__ */ w("div", {
						className: "resume-empty",
						children: [
							/* @__PURE__ */ C("h3", { children: "还没有优化记录" }),
							/* @__PURE__ */ C("p", { children: "完成第一次优化后，在这里查看。" }),
							/* @__PURE__ */ C("button", {
								className: "resume-text-button",
								onClick: () => M("create"),
								children: "选择一份简历开始"
							})
						]
					})]
				}),
				k ? /* @__PURE__ */ w("dialog", {
					ref: Me,
					className: "resume-payment-dialog",
					"aria-labelledby": "resume-payment-title",
					"aria-describedby": "resume-payment-description",
					onCancel: (e) => {
						e.preventDefault(), R || A(null);
					},
					children: [
						/* @__PURE__ */ C("h2", {
							id: "resume-payment-title",
							children: "确认本次优化"
						}),
						/* @__PURE__ */ w("p", {
							id: "resume-payment-description",
							children: [
								"本次开始优化将扣除 ",
								/* @__PURE__ */ C("strong", { children: "100 积分" }),
								"。"
							]
						}),
						/* @__PURE__ */ w("p", {
							className: "resume-payment-balance",
							children: ["可用积分 ", /* @__PURE__ */ C("strong", { children: l.availablePoints })]
						}),
						/* @__PURE__ */ C("p", {
							className: "resume-muted",
							children: "未完成任务失败或取消，积分将原路退还。编辑和下载不再收费。"
						}),
						l.availablePoints < 100 ? /* @__PURE__ */ w("div", {
							className: "resume-payment-insufficient",
							role: "status",
							children: [/* @__PURE__ */ C("p", { children: "积分不足 100，请充值或开通会员后重试。" }), /* @__PURE__ */ C(r, {
								to: o.billing,
								children: "充值 / 开通会员"
							})]
						}) : null,
						/* @__PURE__ */ w("div", {
							className: "resume-actions",
							children: [/* @__PURE__ */ C("button", {
								ref: Ne,
								className: "button ghost",
								disabled: !!R,
								onClick: () => A(null),
								children: "取消"
							}), /* @__PURE__ */ C("button", {
								className: "button primary",
								disabled: !!R || !l.canStart || l.availablePoints < 100,
								onClick: () => We(!0),
								children: R === "create" ? "正在开始…" : "确认并开始"
							})]
						})
					]
				}) : null,
				g ? /* @__PURE__ */ w("section", {
					className: "resume-result",
					"aria-label": "当前简历优化",
					children: [/* @__PURE__ */ w("header", {
						className: "resume-result-header",
						children: [/* @__PURE__ */ w("div", { children: [
							/* @__PURE__ */ C("span", {
								className: "kicker",
								children: ce[g.status]
							}),
							/* @__PURE__ */ C("h2", { children: g.sourceDisplayName }),
							/* @__PURE__ */ w("p", { children: [
								g.targetRole || "通用简历诊断",
								" · ",
								g.hasJd ? "已提供岗位描述" : "未提供 JD",
								" · 稿件版本 ",
								g.revision
							] }),
							/* @__PURE__ */ w("p", { children: [
								g.billingClass === "points" ? `本次 ${g.pointsCharged} 积分` : "本次会员免费",
								" · ",
								g.billingStatus === "reserved" ? g.billingClass === "points" ? "已扣积分，等待结果" : "免费次数已占用" : g.billingStatus === "released" ? "已原路退还" : "已完成结算"
							] })
						] }), /* @__PURE__ */ C("button", {
							className: "button danger",
							disabled: !!R,
							onClick: () => {
								!g || !window.confirm("删除本次优化及其输入快照、建议和草稿？已经另存的新简历将保留。已完成的优化不会退还积分或恢复免费次数。") || Q("delete", async () => {
									H.current += 1, await S.remove(g.jobId, J()), Y() && (H.current += 1, _(null), I(""), P(!1), await Z(), Y() && z("本次优化及草稿已删除，已另存的新简历仍保留在资料库。"));
								});
							},
							children: R === "delete" ? "正在删除…" : "删除优化"
						})]
					}), ae(g) ? /* @__PURE__ */ w("div", {
						className: "panel resume-progress",
						role: "status",
						children: [
							/* @__PURE__ */ C("div", {
								className: "resume-progress-dot",
								"aria-hidden": "true"
							}),
							/* @__PURE__ */ C("h3", { children: g.status === "queued" ? "优化任务正在排队" : "正在根据原文整理改进建议" }),
							/* @__PURE__ */ C("p", { children: g.status === "queued" ? "任务按顺序处理，你可以离开页面，稍后回来查看。" : "正在核对依据、诊断简历并生成优化稿，请稍候。" }),
							/* @__PURE__ */ w("div", {
								className: "resume-actions",
								children: [/* @__PURE__ */ C("button", {
									className: "button ghost",
									disabled: !!R,
									onClick: () => void Q("status", () => Ve(g.jobId)),
									children: "刷新进度"
								}), /* @__PURE__ */ C("button", {
									className: "button danger",
									disabled: !!R,
									onClick: () => void Q("cancel", async () => {
										H.current += 1;
										let e = await S.cancel(g.jobId, J());
										Y() && (X(e), await Z());
									}),
									children: R === "cancel" ? "正在取消…" : "取消优化"
								})]
							})
						]
					}) : g.status === "failed" || g.status === "cancelled" ? /* @__PURE__ */ w("div", {
						className: "panel resume-empty",
						children: [
							/* @__PURE__ */ C("h3", { children: g.status === "cancelled" ? "本次优化已取消" : "本次优化未完成" }),
							/* @__PURE__ */ C("p", { children: g.status === "failed" ? ne[g.errorCode ?? ""] ?? "未生成可用优化稿，原简历保留。" : "系统不会自动开始新的优化。" }),
							/* @__PURE__ */ C("p", { children: g.allowanceStatus === "released" ? g.billingClass === "points" ? "本次扣除的 100 积分已原路退还。" : "已退还原创建日的免费次数，跨日不会增加今日额度。" : "请刷新最新次数和费用后重新开始。" }),
							/* @__PURE__ */ C("button", {
								className: "button primary",
								disabled: !!R,
								onClick: () => {
									var e;
									g && (y(g.sourceDocumentId), de(g.targetRole), pe(g.jdDocumentId ? "material" : g.jdText ? "text" : "none"), he(((e = Le.find((e) => e.documentId === g.jdDocumentId || e.id === g.jdDocumentId)) == null ? void 0 : e.id) ?? ""), ge(g.jdText), O(!1), A(null), U.current = null, _(null), M("create"), I(""), P(!1), z("请核对资料，重新确认后再开始。系统不会自动重试或收费。"));
								},
								children: "核对输入并重试"
							})
						]
					}) : g.review ? /* @__PURE__ */ w(ie, { children: [
						/* @__PURE__ */ w("div", {
							className: "resume-review-layout",
							children: [/* @__PURE__ */ w("section", {
								className: "panel resume-score",
								children: [
									/* @__PURE__ */ C("span", {
										className: "kicker",
										children: "参考评分"
									}),
									/* @__PURE__ */ w("div", {
										className: "resume-score-number",
										children: [/* @__PURE__ */ C("strong", { children: g.review.overallScore }), /* @__PURE__ */ C("span", { children: "/ 100" })]
									}),
									/* @__PURE__ */ C("p", { children: g.review.disclaimer }),
									/* @__PURE__ */ C("small", { children: "各维度等权计算" }),
									g.review.roleMatchingAssessed ? null : /* @__PURE__ */ C("p", {
										className: "resume-muted",
										children: "未提供岗位描述，岗位匹配度未评估。"
									})
								]
							}), /* @__PURE__ */ w("section", {
								className: "panel resume-dimensions",
								children: [/* @__PURE__ */ C("h3", { children: "评分维度与依据" }), g.review.dimensions.map((e) => /* @__PURE__ */ w("article", { children: [
									/* @__PURE__ */ w("div", { children: [/* @__PURE__ */ C("strong", { children: oe[e.key] ?? e.key }), /* @__PURE__ */ w("span", { children: [e.score, " / 100"] })] }),
									/* @__PURE__ */ C("meter", {
										min: 0,
										max: 100,
										value: e.score,
										"aria-label": `${oe[e.key] ?? e.key}评分`,
										children: e.score
									}),
									/* @__PURE__ */ C("p", { children: e.reason }),
									/* @__PURE__ */ C(fe, { items: e.evidence })
								] }, e.key))]
							})]
						}),
						/* @__PURE__ */ w("section", {
							className: "panel resume-suggestions",
							children: [
								/* @__PURE__ */ C("h3", { children: "修改建议" }),
								g.review.suggestions.map((e, t) => /* @__PURE__ */ w("article", { children: [
									/* @__PURE__ */ C("span", {
										className: `resume-priority ${e.priority}`,
										children: {
											high: "优先修改",
											medium: "建议修改",
											low: "可选完善"
										}[e.priority]
									}),
									/* @__PURE__ */ C("h4", { children: e.title }),
									/* @__PURE__ */ C("p", { children: e.explanation }),
									/* @__PURE__ */ C(fe, { items: e.evidence }),
									/* @__PURE__ */ w("p", {
										className: "resume-recommendation",
										children: [/* @__PURE__ */ C("strong", { children: "建议修改方式" }), e.recommendation]
									})
								] }, t)),
								g.review.missingFacts.length ? /* @__PURE__ */ w("aside", {
									className: "resume-missing",
									children: [
										/* @__PURE__ */ C("h4", { children: "需要你补充的信息" }),
										/* @__PURE__ */ C("p", { children: "仅补充真实且可核实的信息，这些内容未被虚构到优化稿中。" }),
										/* @__PURE__ */ C("ul", { children: g.review.missingFacts.map((e, t) => /* @__PURE__ */ C("li", { children: e }, t)) })
									]
								}) : null
							]
						}),
						/* @__PURE__ */ w("section", {
							className: "panel resume-comparison",
							children: [
								/* @__PURE__ */ C("div", {
									className: "panel-heading",
									children: /* @__PURE__ */ w("div", { children: [/* @__PURE__ */ C("h3", { children: "对照原文，编辑优化稿" }), /* @__PURE__ */ C("p", { children: "解析原文只读，原文件保留。修改后请先保存，再下载或另存新简历。" })] })
								}),
								/* @__PURE__ */ w("div", {
									className: "resume-comparison-grid",
									children: [/* @__PURE__ */ w("section", { children: [
										/* @__PURE__ */ C("h4", { children: "解析后的原简历" }),
										/* @__PURE__ */ C("p", {
											className: "resume-muted",
											children: "展示解析文本，表格已转为简化文本。"
										}),
										/* @__PURE__ */ C("pre", { children: g.sourceText })
									] }), /* @__PURE__ */ w("section", { children: [
										/* @__PURE__ */ C("label", {
											htmlFor: "optimizer-draft",
											children: "可编辑优化稿"
										}),
										/* @__PURE__ */ C("textarea", {
											id: "optimizer-draft",
											rows: 22,
											value: F,
											maxLength: l.limits.draftCharacters,
											disabled: !!R,
											onChange: (e) => {
												I(e.target.value), P(!1), ye(!1);
											}
										}),
										/* @__PURE__ */ w("small", { children: [
											F.length.toLocaleString(),
											" / ",
											l.limits.draftCharacters.toLocaleString(),
											" 字 · ",
											K ? "尚未保存" : "已保存"
										] })
									] })]
								}),
								/* @__PURE__ */ w("details", { children: [/* @__PURE__ */ C("summary", { children: "查看 AI 初稿" }), /* @__PURE__ */ C("pre", { children: g.initialDraftMarkdown })] }),
								L ? /* @__PURE__ */ w("div", {
									className: "inline-error",
									role: "alert",
									children: ["服务端已有更新版本，已保留上方的本地编辑。请先复制需要保留的内容，再载入已保存稿。", /* @__PURE__ */ C("button", {
										className: "resume-text-button",
										onClick: () => {
											window.confirm("用最新已保存稿替换尚未保存的本地修改？") && (I(g.draftMarkdown ?? ""), be(!1), P(!1));
										},
										children: "载入已保存稿"
									})]
								}) : null,
								/* @__PURE__ */ w("div", {
									className: "resume-actions",
									children: [/* @__PURE__ */ C("button", {
										className: "button primary",
										disabled: !!R || !K || L || !F.trim(),
										onClick: Je,
										children: R === "draft" ? "正在保存…" : "保存草稿"
									}), /* @__PURE__ */ C("span", {
										className: "resume-muted",
										children: "支持纯文本或 Markdown，不支持 HTML。"
									})]
								}),
								/* @__PURE__ */ w("div", {
									className: "resume-export-area",
									children: [
										/* @__PURE__ */ C("h4", { children: "下载或另存简历" }),
										/* @__PURE__ */ C("p", { children: "导出使用统一简洁模板，不保留原文件排版。使用前请核对每项经历、日期、技能和成果。" }),
										/* @__PURE__ */ w("label", {
											className: "resume-check",
											children: [/* @__PURE__ */ C("input", {
												type: "checkbox",
												checked: N,
												disabled: !!R || K || L,
												onChange: (e) => P(e.target.checked)
											}), /* @__PURE__ */ C("span", { children: "我已核对这份已保存稿，确认事实准确。" })]
										}),
										K ? /* @__PURE__ */ C("p", {
											className: "resume-muted",
											children: "请先保存修改，再确认事实并下载。"
										}) : null,
										/* @__PURE__ */ w("div", {
											className: "resume-actions",
											children: [l.exports.includes("docx") ? /* @__PURE__ */ C("button", {
												className: "button primary",
												disabled: !!R || K || L || !N,
												onClick: () => Ye("docx"),
												children: R === "docx" ? "正在生成 Word…" : "下载 Word"
											}) : null, l.exports.includes("pdf") ? /* @__PURE__ */ C("button", {
												className: "button ghost",
												disabled: !!R || K || L || !N,
												onClick: () => Ye("pdf"),
												children: R === "pdf" ? "正在生成 PDF…" : "下载 PDF"
											}) : null]
										}),
										/* @__PURE__ */ w("label", {
											className: "resume-check",
											children: [/* @__PURE__ */ C("input", {
												type: "checkbox",
												checked: ve,
												disabled: !!R || K || L,
												onChange: (e) => ye(e.target.checked)
											}), /* @__PURE__ */ C("span", { children: "在资料库另存一份独立新简历。原简历和既有面试选择保留，删除本次优化时新简历仍保留。" })]
										}),
										/* @__PURE__ */ C("button", {
											className: "button ghost",
											disabled: !!R || K || L || !N || !ve,
											onClick: () => {
												!g || !N || !ve || K || L || Q("copy", async () => {
													try {
														if (await S.saveAs(g.jobId, g.revision, J()), !Y()) return;
														await Ve(g.jobId), await $(), Y() && z("已在资料库另存一份新简历，解析完成后可用于面试。原简历和既有面试选择保留。");
													} catch (e) {
														await qe(e);
													}
												});
											},
											children: R === "copy" ? "正在另存简历…" : g.savedDocumentId ? "刷新已另存状态" : "另存为新简历"
										}),
										g.savedDocumentId ? /* @__PURE__ */ w("p", {
											className: "resume-muted",
											children: ["此稿件版本已另存为新简历。 ", /* @__PURE__ */ C(r, {
												to: o.library,
												children: "打开资料库 →"
											})]
										}) : null,
										/* @__PURE__ */ C("p", {
											className: "resume-muted",
											children: "编辑、下载和另存不会再次收费或占用次数。任务及源资料保留时，会员到期后仍可使用已完成结果。"
										})
									]
								})
							]
						})
					] }) : /* @__PURE__ */ C("section", {
						className: "panel",
						role: "alert",
						children: "本次优化尚无可用结果，请刷新进度。"
					})]
				}) : null
			] }) : /* @__PURE__ */ w("section", {
				className: "panel resume-empty",
				children: [
					/* @__PURE__ */ C("h2", { children: "简历优化暂时不可用" }),
					/* @__PURE__ */ C("p", { children: "请稍后再试，也可继续使用面试和资料。" }),
					/* @__PURE__ */ C(r, {
						to: o.library,
						children: "管理资料 →"
					})
				]
			}) : /* @__PURE__ */ w("section", {
				className: "panel",
				children: [/* @__PURE__ */ C("p", { children: "暂时无法读取简历优化。" }), /* @__PURE__ */ C("button", {
					className: "button primary",
					onClick: () => void He(),
					children: "重试"
				})]
			})
		]
	});
}
//#endregion
export { de as RESUME_OPTIMIZER_POLL_LIMIT, E as ResumeOptimizerPage };
