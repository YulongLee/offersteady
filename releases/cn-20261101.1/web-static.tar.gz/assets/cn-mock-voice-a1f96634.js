const MOCK_WAVEFORM_BARS = 21;
const idlePlayback = { playing: false, levels: Array(MOCK_WAVEFORM_BARS).fill(0) };
export class MockPlaybackError extends Error {
    constructor() { super("网页声音尚未就绪，请点击朗读问题恢复播放。"); }
}
export class MockVoicePlayer {
    constructor() {
        this.onIdle = null;
        this.onPlaybackUnavailable = null;
        this.context = null;
        this.sources = new Set();
        this.cursor = 0;
        this.bytes = 0;
        this.ended = null;
        this.analyser = null;
        this.samples = new Float32Array(1024);
        this.observers = new Set();
        this.animation = null;
        this.lastFrameAt = -Infinity;
        this.playbackStartsAt = Infinity;
        this.visualizationUnavailable = false;
        this.pendingUnlocks = new Set();
        this.playbackUnavailableNotified = false;
    }
    subscribePlayback(observer) {
        this.observers.add(observer);
        observer(idlePlayback);
        this.startVisualization();
        return () => {
            this.observers.delete(observer);
            if (!this.observers.size)
                this.stopVisualization();
        };
    }
    stopVisualization() {
        if (this.animation !== null)
            cancelAnimationFrame(this.animation);
        this.animation = null;
        this.lastFrameAt = -Infinity;
        this.samples.fill(0);
        this.observers.forEach(observer => observer(idlePlayback));
    }
    startVisualization() {
        const context = this.context;
        if (!context || context.state !== "running" || !this.observers.size || !this.sources.size || this.animation !== null || this.visualizationUnavailable)
            return;
        if (!this.analyser) {
            try {
                this.analyser = context.createAnalyser();
                this.analyser.fftSize = this.samples.length;
                for (const source of this.sources)
                    source.connect(this.analyser);
            }
            catch {
                this.visualizationUnavailable = true;
                this.analyser = null;
                return;
            }
        }
        const tick = (time) => {
            if (time - this.lastFrameAt >= 40) {
                this.lastFrameAt = time;
                const playing = context.currentTime >= this.playbackStartsAt;
                try {
                    this.analyser.getFloatTimeDomainData(this.samples);
                }
                catch {
                    this.visualizationUnavailable = true;
                    this.stopVisualization();
                    return;
                }
                const stride = Math.floor(this.samples.length / MOCK_WAVEFORM_BARS);
                const levels = Array.from({ length: MOCK_WAVEFORM_BARS }, (_, bar) => {
                    let power = 0;
                    for (let i = bar * stride; i < (bar + 1) * stride; i++)
                        power += this.samples[i] ** 2;
                    const rms = Math.sqrt(power / stride);
                    return playing && rms > 0.002 ? Math.min(1, Math.sqrt(rms) * 1.8) : 0;
                });
                this.observers.forEach(observer => observer({ playing, levels }));
            }
            this.animation = requestAnimationFrame(tick);
        };
        this.animation = requestAnimationFrame(tick);
    }
    async unlock() {
        if (this.context?.state === "closed")
            this.close();
        if (!this.context) {
            const context = this.context = new AudioContext();
            context.onstatechange = () => {
                if (this.context !== context)
                    return;
                if (context.state === "running") {
                    this.playbackUnavailableNotified = false;
                    this.startVisualization();
                }
                else {
                    this.stopVisualization();
                    if (this.sources.size && this.onPlaybackUnavailable && !this.playbackUnavailableNotified) {
                        this.playbackUnavailableNotified = true;
                        this.onPlaybackUnavailable();
                    }
                }
            };
        }
        const context = this.context;
        let resumed;
        try {
            resumed = context.resume();
        }
        catch {
            throw new MockPlaybackError();
        }
        let timer;
        let cancel;
        const deadline = new Promise((_resolve, reject) => {
            cancel = () => reject(new MockPlaybackError());
            timer = setTimeout(cancel, 3000);
            this.pendingUnlocks.add(cancel);
        });
        try {
            await Promise.race([resumed, deadline]);
            if (this.context !== context || context.state !== "running")
                throw new MockPlaybackError();
        }
        catch {
            throw new MockPlaybackError();
        }
        finally {
            clearTimeout(timer);
            this.pendingUnlocks.delete(cancel);
        }
    }
    append(encoded) {
        const context = this.context;
        if (!context || context.state !== "running")
            throw new MockPlaybackError();
        const raw = atob(encoded);
        this.bytes += raw.length;
        if (raw.length % 2 || this.bytes > 24000 * 2 * 90)
            throw new Error("本题音频格式异常或超过时长上限。");
        const data = context.createBuffer(1, raw.length / 2, 24000);
        const channel = data.getChannelData(0);
        for (let i = 0; i < channel.length; i++) {
            const value = raw.charCodeAt(i * 2) | (raw.charCodeAt(i * 2 + 1) << 8);
            channel[i] = (value >= 32768 ? value - 65536 : value) / 32768;
        }
        const source = context.createBufferSource();
        source.buffer = data;
        source.connect(context.destination);
        if (this.analyser)
            source.connect(this.analyser);
        const wasIdle = this.sources.size === 0;
        if (wasIdle)
            this.playbackUnavailableNotified = false;
        this.sources.add(source);
        source.onended = () => {
            this.sources.delete(source);
            source.disconnect();
            source.buffer = null;
            if (this.sources.size === 0) {
                this.playbackStartsAt = Infinity;
                this.stopVisualization();
                this.onIdle?.();
            }
            if (this.sources.size === 0 && this.ended) {
                const callback = this.ended;
                this.ended = null;
                callback();
            }
        };
        this.cursor = Math.max(this.cursor, context.currentTime + 0.04);
        if (wasIdle)
            this.playbackStartsAt = this.cursor;
        source.start(this.cursor);
        this.cursor += data.duration;
        this.startVisualization();
    }
    finish(onEnd) {
        this.ended = onEnd;
        if (!this.sources.size) {
            this.ended = null;
            onEnd();
        }
    }
    stop() {
        this.ended = null;
        this.playbackUnavailableNotified = false;
        this.stopVisualization();
        this.playbackStartsAt = Infinity;
        for (const source of this.sources) {
            source.onended = null;
            source.stop();
            source.disconnect();
            source.buffer = null;
        }
        this.sources.clear();
        this.cursor = 0;
        this.bytes = 0;
    }
    close() {
        for (const cancel of this.pendingUnlocks)
            cancel();
        this.pendingUnlocks.clear();
        this.stop();
        const context = this.context;
        this.context = null;
        this.analyser?.disconnect();
        this.analyser = null;
        this.visualizationUnavailable = false;
        if (context)
            context.onstatechange = null;
        if (context && context.state !== "closed")
            void context.close();
    }
}
