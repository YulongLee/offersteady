import { invalidateStateReads, stateReadCancelled, stateReadGeneration } from './cn-state-read-scope-310b172c.js';
export function installStateReadOptimization(adapter, authClient, authHeaders) {
    class StateReadMethods {
        waitForStateRead(flight, signal) {
            if (signal?.aborted)
                return Promise.reject(stateReadCancelled());
            return new Promise((resolve, reject) => {
                let done = false;
                flight.consumers += 1;
                const cleanup = () => {
                    signal?.removeEventListener("abort", onAbort);
                    flight.consumers -= 1;
                    if (!flight.settled && flight.consumers === 0) {
                        if (this.stateReadsInFlight.get(flight.key) === flight)
                            this.stateReadsInFlight.delete(flight.key);
                        flight.controller.abort();
                    }
                };
                const onAbort = () => {
                    if (done)
                        return;
                    done = true;
                    cleanup();
                    reject(stateReadCancelled());
                };
                signal?.addEventListener("abort", onAbort, { once: true });
                flight.promise.then(value => {
                    if (done)
                        return;
                    done = true;
                    cleanup();
                    resolve(value);
                }, error => {
                    if (done)
                        return;
                    done = true;
                    cleanup();
                    reject(error);
                });
                if (signal?.aborted)
                    onAbort();
            });
        }
        async loadScopedState(scope, auth, signal, retries) {
            if (signal?.aborted || !authClient.isCurrentScope(scope))
                throw stateReadCancelled();
            const current = authClient.readScope();
            const generation = stateReadGeneration();
            const contextKey = JSON.stringify([current.generation, current.userId, current.accessToken, current.refreshToken, generation]);
            const key = JSON.stringify([contextKey, auth]);
            for (const [oldKey, pending] of this.stateReadsInFlight) {
                if (pending.contextKey !== contextKey)
                    this.stateReadsInFlight.delete(oldKey);
            }
            let flight = this.stateReadsInFlight.get(key);
            if (!flight || flight.controller.signal.aborted) {
                const controller = new AbortController();
                const pending = {
                    key, contextKey, generation, controller, consumers: 0, settled: false,
                    promise: this.client.request("/api/v1/web/state", { headers: auth ? authHeaders() : {} }, controller.signal).finally(() => {
                        pending.settled = true;
                        if (this.stateReadsInFlight.get(key) === pending)
                            this.stateReadsInFlight.delete(key);
                    }),
                };
                void pending.promise.catch(() => undefined);
                this.stateReadsInFlight.set(key, pending);
                flight = pending;
            }
            let value;
            try {
                value = await this.waitForStateRead(flight, signal);
            }
            catch (error) {
                if (signal?.aborted || !authClient.isCurrentScope(scope))
                    throw stateReadCancelled();
                if (flight.generation !== stateReadGeneration()) {
                    if (retries >= 1)
                        throw stateReadCancelled();
                    return this.loadScopedState(scope, auth, signal, retries + 1);
                }
                throw error;
            }
            if (signal?.aborted || !authClient.isCurrentScope(scope))
                throw stateReadCancelled();
            if (flight.generation !== stateReadGeneration()) {
                if (retries >= 1)
                    throw stateReadCancelled();
                return this.loadScopedState(scope, auth, signal, retries + 1);
            }
            return typeof structuredClone === "function" ? structuredClone(value) : JSON.parse(JSON.stringify(value));
        }
        async loadState(signal, options) {
            if (signal?.aborted)
                throw stateReadCancelled();
            if (options?.forceRefresh)
                invalidateStateReads();
            return this.loadScopedState(authClient.readScope(), options?.auth !== false, signal, 0);
        }
    }
    adapter.stateReadsInFlight = new Map();
    for (const name of ['waitForStateRead', 'loadScopedState', 'loadState'])
        Object.defineProperty(adapter, name, { value: StateReadMethods.prototype[name], writable: true, configurable: true });
}