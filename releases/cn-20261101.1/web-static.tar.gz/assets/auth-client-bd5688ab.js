import {beginStateMutation as __cnBeginStateMutation,stateReadCancelled as __cnStateReadCancelled,isStateReadCancelled as __cnIsStateReadCancelled} from './cn-state-read-scope-310b172c.js';
function e(t){"@babel/helpers - typeof";return e=typeof Symbol==`function`&&typeof Symbol.iterator==`symbol`?function(e){return typeof e}:function(e){return e&&typeof Symbol==`function`&&e.constructor===Symbol&&e!==Symbol.prototype?`symbol`:typeof e},e(t)}function t(t,n){if(e(t)!=`object`||!t)return t;var r=t[Symbol.toPrimitive];if(r!==void 0){var i=r.call(t,n||`default`);if(e(i)!=`object`)return i;throw TypeError(`@@toPrimitive must return a primitive value.`)}return(n===`string`?String:Number)(t)}function n(n){var r=t(n,`string`);return e(r)==`symbol`?r:r+``}function r(e,t,r){return(t=n(t))in e?Object.defineProperty(e,t,{value:r,enumerable:!0,configurable:!0,writable:!0}):e[t]=r,e}var i=class extends Error{constructor(e,t){super(t),r(this,`code`,void 0),this.code=e,this.name=`AppError`}},a=e=>e instanceof i?e:e instanceof DOMException&&e.name===`AbortError`?new i(`aborted`,`请求已取消`):typeof e==`object`&&e&&`status`in e&&e.status===501?new i(`not-implemented`,`该功能正在接入后端基础工程`):e instanceof Error&&e.message?new i(`unknown`,e.message):new i(`unknown`,`暂时无法完成操作，请稍后重试`),o=class extends Error{constructor(e,t,n=`API request failed with status ${e}`){super(n),r(this,`status`,void 0),r(this,`payload`,void 0),this.status=e,this.payload=t,this.name=`ApiResponseError`}},s=e=>typeof e==`object`&&!!e&&`success`in e&&`requestId`in e&&`meta`in e,c=e=>e.replace(/\/+$/,``).replace(/\/api\/v1$/,``),l=(e,t)=>`${c(e)}${t.startsWith(`/`)?t:`/${t}`}`,u=(e,t)=>globalThis.fetch(e,t),d=(function(){const AppError=i;const ApiResponseError=o;const isEnvelope=s;const withBaseUrl=l;const defaultFetch=u;const beginStateMutation=__cnBeginStateMutation;
return (({ baseUrl, fetchImpl = defaultFetch }) => ({
    async request(path, init, signal) {
        const finishMutation = beginStateMutation(path, init?.method);
        try {
            let response;
            const resolvedSignal = signal ?? init?.signal ?? null;
            const providedHeaders = new Headers(init?.headers);
            const shouldUseJsonContentType = typeof init?.body === "string" && !providedHeaders.has("Content-Type");
            const headers = {
                Accept: "application/json",
                ...(shouldUseJsonContentType ? { "Content-Type": "application/json" } : {}),
                ...(init?.headers ?? {}),
            };
            try {
                response = await fetchImpl(withBaseUrl(baseUrl, path), {
                    ...init,
                    signal: resolvedSignal,
                    headers,
                });
            }
            catch (error) {
                if (error instanceof DOMException && error.name === "AbortError")
                    throw error;
                throw new AppError("network", "无法连接后端基础服务");
            }
            const payload = response.headers.get("content-type")?.includes("application/json") ? await response.json() : null;
            if (!response.ok) {
                if (isEnvelope(payload) && payload.error?.message) {
                    throw new AppError("validation", payload.error.message);
                }
                throw new ApiResponseError(response.status, payload);
            }
            if (isEnvelope(payload)) {
                if (!payload.success || payload.data == null) {
                    throw new AppError("validation", payload.error?.message ?? "后端返回了空结果");
                }
                return payload.data;
            }
            return payload;
        }
        finally {
            finishMutation();
        }
    },
}));})(),f=async(e,t)=>{let n=t?null:new AbortController;try{return await e(t??n.signal)}catch(e){throw a(e)}},p=e=>e===`test`||e===`staging`||e===`production`?e:`development`,m=(e,t=`http://127.0.0.1:8000`)=>(e??t).replace(/\/+$/,``).replace(/\/api\/v1$/,``),h=e=>{var t;return{appEnv:p(e.VITE_APP_ENV),apiBaseUrl:m(e.VITE_API_BASE_URL),appVersion:((t=e.VITE_PUBLIC_APP_VERSION)==null?void 0:t.trim())||`0.1.0`}},g=e=>h(e),_=d({baseUrl:g({BASE_URL:`/`,DEV:!1,MODE:`production`,PROD:!0,SSR:!1,VITE_API_BASE_URL:`/`,VITE_APP_ENV:`production`,VITE_PUBLIC_APP_VERSION:`pricing-copy-hourly-20261011.1`}).apiBaseUrl}),v=`offersteady.auth.access_token`,y=`offersteady.auth.refresh_token`,b=`offersteady.auth.account`,x=`offersteady.promotion.claim_key`,S={id:`admin`,displayName:`admin`,createdAtMs:1719e9,bindings:[{id:`prototype-admin-binding`,provider:`prototype`,displayName:`本地 admin 身份`,status:`active`,boundAtMs:1719e9,canUnbind:!1}]},C=()=>window.localStorage,w=()=>!1,T=e=>{let t=C();return typeof(t==null?void 0:t.getItem)==`function`?t.getItem(e):null},E=(e,t)=>{let n=C();typeof(n==null?void 0:n.setItem)==`function`&&n.setItem(e,t)},D=e=>{let t=C();typeof(t==null?void 0:t.removeItem)==`function`&&t.removeItem(e)},O=e=>{E(b,JSON.stringify(e)),E(`offersteady.prototype.auth`,`true`)},k=e=>{if(e&&e.id!==S.id||(e==null?void 0:e.id)===S.id)return e;if(!w())throw new i(`validation`,`当前没有登录态`);return D(v),D(y),O(S),S},A=e=>({id:e.userId,displayName:e.displayName,createdAtMs:e.createdAtMs,bindings:e.bindings.map(e=>({id:e.bindingId,provider:e.provider===`wechat`?`wechat`:e.provider===`sms`?`sms`:`prototype`,displayName:e.displayName??(e.provider===`wechat`?`微信账号`:e.provider===`sms`?`手机号`:`账号`),status:e.status===`active`?`active`:e.status===`revoked`?`revoked`:`recovery-required`,boundAtMs:e.boundAtMs,canUnbind:!1}))}),j=e=>{let t={accessToken:e.tokens.accessToken,refreshToken:e.tokens.refreshToken,account:A(e.user)};return E(v,t.accessToken),E(y,t.refreshToken),E(b,JSON.stringify(t.account)),E(`offersteady.prototype.auth`,`true`),N(t.accessToken),t},M=e=>({Authorization:`Bearer ${e}`}),N=e=>{let t=T(x);if(!t){var n;t=typeof((n=crypto)==null?void 0:n.randomUUID)==`function`?crypto.randomUUID():`claim-${Date.now()}-${Math.random().toString(36).slice(2)}`,E(x,t)}_.request(`/api/v1/promotion/claim`,{method:`POST`,headers:M(e),body:JSON.stringify({claimKey:t})}).catch(()=>void 0)},P=(function(){const client=_;const AppError=i;const readStorageItem=T;const writeStorageItem=E;const removeStorageItem=D;const accountKey=b;const accessTokenKey=v;const refreshTokenKey=y;const persistPrototypeAccount=O;const normalizePrototypeAccount=k;const prototypeAuthEnabled=w;const toSafeAccountSummary=A;const authorizationHeaders=M;const queuePromotionClaim=N;const stateReadCancelled=__cnStateReadCancelled;const isStateReadCancelled=__cnIsStateReadCancelled;"use strict";
let authGeneration = 0;
let observedAuthFingerprint;
const storedAuthSnapshot = () => {
    try {
        const userId = JSON.parse(readStorageItem(accountKey) ?? "null")?.id ?? null;
        return { userId, accessToken: readStorageItem(accessTokenKey), refreshToken: readStorageItem(refreshTokenKey) };
    }
    catch {
        return { userId: null, accessToken: null, refreshToken: null };
    }
};
const authFingerprint = (snapshot = storedAuthSnapshot()) => JSON.stringify([snapshot.userId, snapshot.accessToken, snapshot.refreshToken]);
const transitionAuthScope = () => {
    authGeneration += 1;
    observedAuthFingerprint = authFingerprint();
};
const readAuthScope = () => {
    const snapshot = storedAuthSnapshot();
    const fingerprint = authFingerprint(snapshot);
    if (observedAuthFingerprint !== undefined && observedAuthFingerprint !== fingerprint)
        authGeneration += 1;
    observedAuthFingerprint = fingerprint;
    return { generation: authGeneration, ...snapshot };
};
const isCurrentAuthScope = (scope) => {
    const current = readAuthScope();
    return current.generation === scope.generation && current.userId === scope.userId;
};
const confirmRefreshScope = (scope) => {
    const current = storedAuthSnapshot();
    if (authGeneration !== scope.generation || current.userId !== scope.userId
        || !current.accessToken || !current.refreshToken)
        return false;
    observedAuthFingerprint = authFingerprint(current);
    return true;
};
if (typeof window !== "undefined") {
    window.addEventListener("storage", event => {
        if (event.key === null || [accountKey, accessTokenKey, refreshTokenKey].includes(event.key))
            transitionAuthScope();
    });
}
const storeSession=((result, preserveLifecycle = false) => {
    const session = {
        accessToken: result.tokens.accessToken,
        refreshToken: result.tokens.refreshToken,
        account: toSafeAccountSummary(result.user),
    };
    writeStorageItem(accessTokenKey, session.accessToken);
    writeStorageItem(refreshTokenKey, session.refreshToken);
    writeStorageItem(accountKey, JSON.stringify(session.account));
    writeStorageItem("offersteady.prototype.auth", "true");
    if (preserveLifecycle)
        observedAuthFingerprint = authFingerprint();
    else
        transitionAuthScope();
    queuePromotionClaim(session.accessToken);
    return session;
});
return ({
    readScope: readAuthScope,
    isCurrentScope: isCurrentAuthScope,
    confirmRefreshScope,
    readStoredAccount() {
        try {
            const accountRaw = readStorageItem(accountKey);
            if (!accountRaw)
                return null;
            return normalizePrototypeAccount(JSON.parse(accountRaw));
        }
        catch {
            return null;
        }
    },
    readStoredSession() {
        try {
            const accessToken = readStorageItem(accessTokenKey);
            const refreshToken = readStorageItem(refreshTokenKey);
            const accountRaw = readStorageItem(accountKey);
            if (!accessToken || !refreshToken || !accountRaw)
                return null;
            const account = JSON.parse(accountRaw);
            return { accessToken, refreshToken, account };
        }
        catch {
            return null;
        }
    },
    clear() {
        removeStorageItem(accessTokenKey);
        removeStorageItem(refreshTokenKey);
        removeStorageItem(accountKey);
        removeStorageItem("offersteady.prototype.auth");
        transitionAuthScope();
    },
    bootstrapPrototypeIdentity(account) {
        if (!prototypeAuthEnabled())
            return;
        persistPrototypeAccount(normalizePrototypeAccount(account));
        transitionAuthScope();
    },
    async sendSmsCode(phoneNumber, signal) {
        return client.request("/api/v1/auth/sms/send-code", {
            method: "POST",
            body: JSON.stringify({ phoneNumber, clientLabel: "web" }),
        }, signal);
    },
    async verifySmsLogin(input, signal) {
        const result = await client.request("/api/v1/auth/sms/verify-login", {
            method: "POST",
            body: JSON.stringify({ phoneNumber: input.phoneNumber, challengeId: input.challengeId, code: input.code, clientLabel: "web" }),
        }, signal);
        return storeSession(result);
    },
    async createWechatAuthorizationSession(signal) {
        return client.request("/api/v1/auth/wechat/authorization-sessions", {
            method: "POST",
            body: JSON.stringify({ clientLabel: "web" }),
        }, signal);
    },
    async getWechatAuthorizationSession(authRequestId, signal) {
        return client.request(`/api/v1/auth/wechat/authorization-sessions/${authRequestId}`, undefined, signal);
    },
    async simulateScan(authRequestId, signal) {
        return client.request(`/api/v1/auth/wechat/authorization-sessions/${authRequestId}/scan`, { method: "POST" }, signal);
    },
    async simulateAuthorize(authRequestId, signal) {
        return client.request(`/api/v1/auth/wechat/authorization-sessions/${authRequestId}/authorize`, { method: "POST" }, signal);
    },
    acceptAuthorizedResult(result) {
        return storeSession(result);
    },
    async refresh(signal) {
        const scope = readAuthScope();
        const existing = this.readStoredSession();
        if (!existing)
            throw new AppError("validation", "当前没有可恢复的登录会话");
        const refreshed = await client.request("/api/v1/auth/refresh", {
            method: "POST",
            body: JSON.stringify({ refreshToken: existing.refreshToken }),
        }, signal);
        const current = this.readStoredSession();
        if (!isCurrentAuthScope(scope) || current?.refreshToken !== existing.refreshToken
            || refreshed.user.userId !== existing.account.id)
            throw stateReadCancelled();
        return storeSession(refreshed, true);
    },
    async currentUser(signal) {
        const scope = readAuthScope();
        const existing = this.readStoredSession();
        if (!existing)
            throw new AppError("validation", "当前没有登录态");
        const user = await client.request("/api/v1/auth/me", {
            headers: authorizationHeaders(existing.accessToken),
        }, signal);
        const account = toSafeAccountSummary(user);
        if (!isCurrentAuthScope(scope) || account.id !== existing.account.id)
            throw stateReadCancelled();
        writeStorageItem(accountKey, JSON.stringify(account));
        return account;
    },
    async restore(signal) {
        try {
            const current = await this.currentUser(signal);
            const existing = this.readStoredSession();
            if (!existing)
                throw new AppError("validation", "当前没有登录态");
            return { ...existing, account: current };
        }
        catch (error) {
            if (signal?.aborted || isStateReadCancelled(error))
                throw error;
            return this.refresh(signal);
        }
    },
    async logout(signal) {
        const existing = this.readStoredSession();
        if (!existing) {
            this.clear();
            return;
        }
        transitionAuthScope();
        const scope = readAuthScope();
        try {
            await client.request("/api/v1/auth/logout", {
                method: "POST",
                headers: authorizationHeaders(existing.accessToken),
                body: JSON.stringify({ logoutAllDevices: false }),
            }, signal);
        }
        finally {
            if (isCurrentAuthScope(scope))
                this.clear();
        }
    },
});})();export{l as a,f as i,g as n,i as o,d as r,r as s,P as t};