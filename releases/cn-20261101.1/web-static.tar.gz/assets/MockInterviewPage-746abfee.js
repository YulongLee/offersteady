import {MockVoicePlayer as __cnMockVoicePlayer,MockPlaybackError as __cnMockPlaybackError} from './cn-mock-voice-a1f96634.js';
import { n as e, t } from "./jsx-runtime-2Zwg-L3c.js";
import { F as n, L as r, R as i, S as a, b as o, x as s } from "./main-48f3fcb5.js";
import { t as c } from "./auth-client-bd5688ab.js";
import { n as l, t as ee } from "./mock-interview-report-CtmMBUmT.js";
var { useCallback: te, useEffect: u, useState: d, useRef: f } = e();
//#endregion
//#region artifacts/cn-mock-flat-billing-20261015/web/module-src/mock-interview-client.ts
function ne(e) {
	let t = Date.parse(`${e.quotaDay}T00:00:00+08:00`) + 864e5 - e.nowMs;
	return Number.isFinite(t) ? Math.max(100, t + 100) : 6e4;
}
//#endregion
//#region artifacts/cn-mock-flat-billing-20261015/web/module-src/jsx-runtime.ts
var { jsx: p, jsxs: m, Fragment: h } = t(), g = {
	playing: !1,
	levels: Array(21).fill(0)
};
function re({ player: e, phase: t }) {
	let [n, r] = d(g), [i, a] = d(!1);
	u(() => {
		var e, t;
		let n = (e = (t = window).matchMedia) == null ? void 0 : e.call(t, "(prefers-reduced-motion: reduce)"), r = () => a((n == null ? void 0 : n.matches) ?? !1);
		return r(), n == null || n.addEventListener("change", r), () => n == null ? void 0 : n.removeEventListener("change", r);
	}, []), u(() => e.subscribePlayback((e) => {
		r(i ? (t) => t.playing === e.playing ? t : {
			...g,
			playing: e.playing
		} : e);
	}), [e, i]);
	let o = t === "speaking" && n.playing, s = o ? "面试官正在提问" : t === "speaking" ? "等待语音播放" : t === "paused" ? "语音播放已暂停" : t === "listening" ? "正在聆听你的回答" : "等待面试官提问";
	return /* @__PURE__ */ m("div", {
		className: `mock-playback ${o ? "is-active" : ""} ${i ? "is-reduced-motion" : ""}`,
		children: [/* @__PURE__ */ p("div", {
			className: "mock-waveform",
			"aria-hidden": "true",
			children: n.levels.map((e, t) => /* @__PURE__ */ p("span", { style: { transform: `scaleY(${o && !i ? .12 + e * .88 : .12})` } }, t))
		}), /* @__PURE__ */ m("span", {
			className: "mock-playback-label",
			role: "status",
			children: [/* @__PURE__ */ p("i", { "aria-hidden": "true" }), s]
		})]
	});
}
//#endregion
//#region artifacts/cn-mock-flat-billing-20261015/web/module-src/MockInterviewPage.tsx
var _ = {
	preparing: "面试准备",
	generating_question: "面试官正在出题",
	speaking: "听听面试官的问题",
	listening: "轮到你回答",
	paused: "已暂停",
	generating_report: "正在整理面试报告",
	completed: "本场练习已结束"
}, v = (e) => e instanceof Error ? e.message : "操作暂时不可用，请重试。";
function ie() {
const useCallback=te;
const useEffect=u;
const useState=d;
const useRef=f;
const Link=n;
const useNavigate=r;
const useParams=i;
const authClient=c;
const mockRequest=s;
const mockSocketUrl=a;
const nextMockQuoteRefreshDelay=ne;
const MockVoicePlayer=__cnMockVoicePlayer;
const MockPlaybackError=__cnMockPlaybackError;
const MockPlaybackIndicator=re;
const mockPhaseLabel=_;
const MockReportView=ae;
const __cnJsx=e().createElement;
const __cnFragment=h;
const errorText=(error) => error instanceof Error ? error.message : "操作暂时不可用，请重试。";
const playbackRecoveryMessage=(phase) => phase === "preparing"
    ? "网页声音尚未就绪，请再次点击开始模拟面试重试。"
    : phase === "paused" ? "网页声音已暂停，请点击继续本题后恢复朗读。"
        : new MockPlaybackError().message;

    const { id } = useParams();
    const navigate = useNavigate();
    const [sessions, setSessions] = useState([]);
    const [quote, setQuote] = useState(null);
    const [session, setSession] = useState(null);
    const [resumes, setResumes] = useState([]);
    const [target, setTarget] = useState("");
    const [machineCode, setMachineCode] = useState("");
    const [desktopConnected, setDesktopConnected] = useState(false);
    const [preparation, setPreparation] = useState(null);
    const [bindingNotice, setBindingNotice] = useState("");
    const [microphoneCheckExpired, setMicrophoneCheckExpired] = useState(false);
    const [rechecking, setRechecking] = useState(false);
    const recheckTimer = useRef(undefined);
    const recheckLocked = useRef(false);
    const readinessError = useRef(null);
    const desktopReady = useRef(false);
    const [playbackNotice, setPlaybackNotice] = useState("");
    const playbackRecoveryNeeded = useRef(false);
    const [playbackUnlocking, setPlaybackUnlocking] = useState(null);
    const playbackSequence = useRef(0);
    const playbackAttempt = useRef(null);
    const [waitingForMicrophone, setWaitingForMicrophone] = useState(false);
    const [settlingAudio, setSettlingAudio] = useState(false);
    const settleTimer = useRef(undefined);
    const microphoneReady = useRef(false);
    const pendingListen = useRef(null);
    const [connected, setConnected] = useState(false);
    const [draft, setDraft] = useState("");
    const [editing, setEditing] = useState(false);
    const [error, setError] = useState("");
    const [busy, setBusy] = useState(false);
    const actionGeneration = useRef(0);
    const [enabled, setEnabled] = useState(null);
    const [playing, setPlaying] = useState(false);
    const socket = useRef(null);
    const current = useRef(null);
    const edited = useRef(false);
    const draftText = useRef("");
    const capturePrefix = useRef("");
    const voice = useRef(new MockVoicePlayer());
    const createKey = useRef(null);
    const quoteRequest = useRef(0);
    const answerId = useRef(null);
    const playingQuestion = useRef(null);
    const playbackAcknowledged = useRef(false);
    const [reconnect, setReconnect] = useState(0);
    const cancelPlaybackIntent = () => {
        playbackSequence.current++;
        playbackAttempt.current = null;
        setPlaybackUnlocking(null);
    };
    const cancelListeningIntent = () => {
        clearTimeout(settleTimer.current);
        settleTimer.current = undefined;
        pendingListen.current = null;
        setWaitingForMicrophone(false);
        setSettlingAudio(false);
    };
    const invalidateActions = () => {
        actionGeneration.current++;
        setBusy(false);
    };
    const update = (row) => {
        const old = current.current;
        if (old?.sessionId !== row.sessionId || old?.state.phase !== row.state.phase || old?.state.rounds.at(-1)?.question_id !== row.state.rounds.at(-1)?.question_id || old?.resumeId !== row.resumeId || old?.resumeVersion !== row.resumeVersion) {
            cancelPlaybackIntent();
            setPlaybackNotice(row.state.phase === "paused" && playbackRecoveryNeeded.current ? playbackRecoveryMessage("paused") : "");
            if (row.state.phase !== "paused")
                playbackRecoveryNeeded.current = false;
        }
        if (old?.state.rounds.at(-1)?.question_id !== row.state.rounds.at(-1)?.question_id) {
            voice.current.stop();
            setPlaying(false);
            playingQuestion.current = null;
            playbackAcknowledged.current = false;
            setDraft("");
            edited.current = false;
            setEditing(false);
            answerId.current = null;
            draftText.current = "";
            capturePrefix.current = "";
        }
        if (row.state.capture_epoch && row.state.capture_epoch !== old?.state.capture_epoch) {
            capturePrefix.current = draftText.current;
        }
        if (row.state.phase !== "speaking") {
            voice.current.stop();
            setPlaying(false);
            playingQuestion.current = null;
            pendingListen.current = null;
            setWaitingForMicrophone(false);
            clearTimeout(settleTimer.current);
            setSettlingAudio(false);
        }
        current.current = row;
        setSession(row);
    };
    const command = (action, extra = {}) => {
        const row = current.current;
        if (!row || socket.current?.readyState !== WebSocket.OPEN) {
            setError("连接已断开，请重新连接后操作。");
            return;
        }
        if (["pause", "end", "listen", "replay", "resume", "submit"].includes(action)) {
            cancelPlaybackIntent();
            cancelListeningIntent();
            invalidateActions();
        }
        setError("");
        readinessError.current = null;
        socket.current.send(JSON.stringify({ action, version: row.state.version,
            ...(["listen", "replay", "speak", "playback_started", "playback_waiting", "submit"].includes(action) ? { questionId: row.state.rounds.at(-1)?.question_id } : {}), ...extra }));
    };
    const requestPlayback = (action, manual) => {
        const row = current.current;
        const connection = socket.current;
        const phase = action === "start" ? "preparing" : "speaking";
        if (!row || row.state.phase !== phase || connection?.readyState !== WebSocket.OPEN)
            return;
        const questionId = row.state.rounds.at(-1)?.question_id;
        const pending = playbackAttempt.current;
        if (pending?.manual && pending.action === action && pending.questionId === questionId)
            return;
        const sequence = ++playbackSequence.current;
        playbackAttempt.current = { sequence, manual, questionId, action };
        playbackRecoveryNeeded.current = false;
        setPlaybackUnlocking(manual ? "manual" : "auto");
        setPlaybackNotice(manual ? "" : "正在准备网页声音。如果没有播放，请点击朗读问题恢复。");
        if (action === "speak") {
            pendingListen.current = null;
            playingQuestion.current = questionId ?? null;
            voice.current.stop();
            playbackAcknowledged.current = false;
            setPlaying(false);
        }
        const valid = () => sequence === playbackSequence.current && socket.current === connection
            && connection.readyState === WebSocket.OPEN && current.current?.sessionId === row.sessionId
            && current.current.state.phase === phase && current.current.state.rounds.at(-1)?.question_id === questionId
            && (action !== "start" || (current.current.resumeId === row.resumeId && current.current.resumeVersion === row.resumeVersion));
        void voice.current.unlock().then(() => {
            if (!valid())
                return;
            playbackAttempt.current = null;
            setPlaybackUnlocking(null);
            setPlaybackNotice("");
            if (action === "start" && (!desktopReady.current || !current.current?.resumeId))
                return;
            if (action === "speak")
                setPlaying(true);
            command(action);
        }).catch(() => {
            if (!valid())
                return;
            playbackAttempt.current = null;
            setPlaybackUnlocking(null);
            setPlaying(false);
            playbackRecoveryNeeded.current = true;
            setPlaybackNotice(playbackRecoveryMessage(phase));
        });
    };
    const beginListening = (questionId) => {
        if (current.current?.state.phase !== "speaking" || current.current.state.rounds.at(-1)?.question_id !== questionId)
            return;
        pendingListen.current = questionId;
        setWaitingForMicrophone(!microphoneReady.current);
        if (microphoneReady.current) {
            pendingListen.current = null;
            command("listen");
        }
    };
    const prepareListening = (questionId) => {
        clearTimeout(settleTimer.current);
        pendingListen.current = null;
        setSettlingAudio(true);
        if (playbackAcknowledged.current) {
            playbackAcknowledged.current = false;
            command("playback_waiting");
        }
        settleTimer.current = setTimeout(() => {
            setSettlingAudio(false);
            beginListening(questionId);
        }, 1500);
    };
    voice.current.onIdle = () => {
        if (playbackAcknowledged.current && current.current?.state.phase === "speaking") {
            playbackAcknowledged.current = false;
            command("playback_waiting");
        }
    };
    voice.current.onPlaybackUnavailable = () => {
        const row = current.current;
        if (row?.state.phase !== "speaking" || !playingQuestion.current
            || playingQuestion.current !== row.state.rounds.at(-1)?.question_id)
            return;
        voice.current.stop();
        setPlaying(false);
        playingQuestion.current = null;
        playbackAcknowledged.current = false;
        playbackRecoveryNeeded.current = true;
        command("pause");
        setPlaybackNotice(playbackRecoveryMessage("paused"));
    };
    const reload = useCallback(async () => {
        const request = ++quoteRequest.current;
        const data = await mockRequest("/mock-interviews");
        if (request !== quoteRequest.current)
            return;
        setSessions(data.sessions);
        setQuote(data.quote);
    }, []);
    useEffect(() => {
        if (id || enabled !== true)
            return;
        let disposed = false;
        const refresh = () => { void reload().catch(cause => { if (!disposed)
            setError(errorText(cause)); }); };
        const timer = quote ? setTimeout(refresh, nextMockQuoteRefreshDelay(quote)) : undefined;
        const recover = () => { if (document.visibilityState === "visible")
            refresh(); };
        document.addEventListener("visibilitychange", recover);
        return () => { disposed = true; clearTimeout(timer); document.removeEventListener("visibilitychange", recover); };
    }, [id, enabled, quote, reload]);
    useEffect(() => {
        let disposed = false;
        setError("");
        readinessError.current = null;
        void mockRequest("/mock-interviews/capabilities").then(async (capability) => {
            if (disposed)
                return;
            setEnabled(capability.enabled);
            if (!capability.enabled)
                return;
            if (id) {
                const row = await mockRequest(`/mock-interviews/${encodeURIComponent(id)}`);
                if (disposed)
                    return;
                update(row);
                if (row.state.phase === "preparing") {
                    const docs = await mockRequest("/documents?documentKind=resume");
                    if (!disposed)
                        setResumes(docs.filter(doc => doc.status === "ready" && doc.indexState === "indexed" && doc.documentVersionId));
                }
            }
            else
                await reload();
        }).catch(cause => { if (!disposed)
            setError(errorText(cause)); });
        return () => { disposed = true; invalidateActions(); quoteRequest.current++; current.current = null; setSession(null); };
    }, [id, reload]);
    useEffect(() => {
        setMicrophoneCheckExpired(false);
        if (!id || !connected || session?.state.phase !== "preparing" || preparation?.code !== "mock_microphone_checking")
            return;
        const timer = setTimeout(() => setMicrophoneCheckExpired(true), 30000);
        return () => clearTimeout(timer);
    }, [id, connected, session?.state.phase, preparation?.code]);
    useEffect(() => () => {
        clearTimeout(recheckTimer.current);
        recheckLocked.current = false;
        setRechecking(false);
        setBindingNotice("");
        setPreparation(null);
    }, [id, reconnect]);
    const needsConnection = Boolean(id && session && session.sessionId === id && session.state.phase !== "completed");
    useEffect(() => {
        if (!id || !needsConnection)
            return;
        const auth = authClient.readStoredSession();
        if (!auth) {
            setError("请先重新登录。");
            return;
        }
        let disposed = false;
        let stateReceived = false;
        let heartbeat;
        const connection = new WebSocket(mockSocketUrl(id));
        socket.current = connection;
        connection.onopen = () => {
            if (disposed || socket.current !== connection)
                return;
            connection.send(JSON.stringify({ accessToken: auth.accessToken }));
            heartbeat = setInterval(() => {
                if (!disposed && socket.current === connection && connection.readyState === WebSocket.OPEN)
                    connection.send(JSON.stringify({ action: "heartbeat" }));
            }, 5000);
        };
        connection.onmessage = event => {
            if (disposed)
                return;
            try {
                const message = JSON.parse(String(event.data));
                if (message.type === "state") {
                    const previousPhase = current.current?.state.phase;
                    const previousQuestion = current.current?.state.rounds.at(-1)?.question_id;
                    microphoneReady.current = (message.microphoneConnected ?? message.desktopConnected) === true;
                    desktopReady.current = message.desktopConnected === true && message.preparation?.ready !== false;
                    setPreparation(message.preparation ?? null);
                    setBindingNotice("");
                    if (message.preparation?.ready === true && readinessError.current) {
                        const stale = readinessError.current;
                        readinessError.current = null;
                        setError(previous => previous === stale ? "" : previous);
                    }
                    setConnected(true);
                    setDesktopConnected(message.desktopConnected === true);
                    update(message.session);
                    if (pendingListen.current && microphoneReady.current)
                        beginListening(pendingListen.current);
                    if (message.session.state.phase === "speaking" && (!stateReceived || previousPhase !== "speaking" || previousQuestion !== message.session.state.rounds.at(-1)?.question_id)) {
                        voice.current.stop();
                        playbackAcknowledged.current = false;
                        playingQuestion.current = message.session.state.rounds.at(-1)?.question_id ?? null;
                        requestPlayback("speak", false);
                    }
                    stateReceived = true;
                }
                else if (message.type === "transcript") {
                    if (!edited.current && message.epoch === current.current?.state.capture_epoch) {
                        draftText.current = [capturePrefix.current, String(message.text)].filter(Boolean).join(" ").slice(0, 8000);
                        setDraft(draftText.current);
                    }
                }
                else if (message.type === "audio" && message.questionId === playingQuestion.current) {
                    voice.current.append(message.pcm);
                    if (!playbackAcknowledged.current) {
                        playbackAcknowledged.current = true;
                        command("playback_started");
                    }
                    setPlaying(true);
                }
                else if (message.type === "audio_end" && message.questionId === playingQuestion.current) {
                    voice.current.finish(() => {
                        setPlaying(false);
                        if (!disposed)
                            prepareListening(message.questionId);
                    });
                }
                else if (message.type === "error" || message.type === "speech_unavailable") {
                    readinessError.current = ["mock_microphone_checking", "mock_microphone_required"].includes(message.code) ? message.message : null;
                    setError(message.message);
                    setBusy(false);
                    if (message.type === "speech_unavailable") {
                        cancelPlaybackIntent();
                        voice.current.stop();
                        setPlaying(false);
                        playingQuestion.current = null;
                    }
                    else if (current.current?.state.phase === "speaking")
                        setPlaying(false);
                }
            }
            catch (cause) {
                voice.current.stop();
                setPlaying(false);
                playingQuestion.current = null;
                command("pause");
                if (cause instanceof MockPlaybackError) {
                    playbackRecoveryNeeded.current = true;
                    setPlaybackNotice(playbackRecoveryMessage(current.current?.state.phase ?? "speaking"));
                }
                else
                    setError(errorText(cause));
            }
        };
        connection.onclose = () => {
            if (disposed)
                return;
            invalidateActions();
            clearInterval(heartbeat);
            clearTimeout(settleTimer.current);
            voice.current.close();
            setSettlingAudio(false);
            microphoneReady.current = false;
            pendingListen.current = null;
            setWaitingForMicrophone(false);
            desktopReady.current = false;
            cancelPlaybackIntent();
            setPlaybackNotice("");
            playbackRecoveryNeeded.current = false;
            readinessError.current = null;
            clearTimeout(recheckTimer.current);
            recheckLocked.current = false;
            setRechecking(false);
            setBindingNotice("");
            if (!disposed) {
                setConnected(false);
                setPlaying(false);
                setError("面试连接已断开，收音已暂停。请重新连接；本场结束时间保持不变。");
            }
        };
        return () => { disposed = true; invalidateActions(); cancelPlaybackIntent(); cancelListeningIntent(); playbackRecoveryNeeded.current = false; setPlaybackNotice(""); clearInterval(heartbeat); voice.current.close(); connection.close(); socket.current = null; microphoneReady.current = false; desktopReady.current = false; setConnected(false); };
    }, [id, needsConnection, reconnect]);
    const action = async (run) => {
        const generation = actionGeneration.current;
        const connection = socket.current;
        const isCurrent = () => generation === actionGeneration.current && socket.current === connection;
        setBusy(true);
        setError("");
        readinessError.current = null;
        try {
            await run(isCurrent);
        }
        catch (cause) {
            if (isCurrent())
                setError(errorText(cause));
        }
        finally {
            if (isCurrent())
                setBusy(false);
        }
    };
    const selectResume = (documentId) => action(async (isCurrent) => {
        const row = current.current;
        const doc = resumes.find(item => item.documentId === documentId);
        if (!row || row.state.phase !== "preparing" || !doc)
            return;
        const selected = await mockRequest(`/mock-interviews/${row.sessionId}/resume`, {
            version: row.state.version, documentId: doc.documentId, documentVersionId: doc.documentVersionId,
        });
        const latest = current.current;
        if (!isCurrent() || latest?.sessionId !== row.sessionId || latest.state.phase !== "preparing"
            || selected.sessionId !== row.sessionId || selected.state.phase !== "preparing"
            || selected.state.version < latest.state.version)
            return;
        update(selected);
    });
    const recheckMicrophone = () => {
        if (recheckLocked.current || current.current?.state.phase !== "preparing" || socket.current?.readyState !== WebSocket.OPEN)
            return;
        recheckLocked.current = true;
        setRechecking(true);
        setBindingNotice("正在重新检查麦克风…");
        socket.current.send(JSON.stringify({ action: "heartbeat" }));
        recheckTimer.current = setTimeout(() => {
            recheckLocked.current = false;
            setRechecking(false);
            setBindingNotice(previous => previous === "正在重新检查麦克风…" ? "" : previous);
        }, 2000);
    };
    const bindDevice = () => action(async (isCurrent) => {
        cancelPlaybackIntent();
        setBindingNotice("");
        const row = current.current;
        if (!row || row.state.phase !== "preparing")
            return;
        const auth = authClient.readStoredSession();
        if (!auth)
            throw new Error("请重新登录");
        await mockRequest(`/realtime-speech/sessions/${id}/desktop-binding`, { userId: auth.account.id, manualCode: machineCode });
        if (!isCurrent() || current.current?.sessionId !== row.sessionId || current.current.state.phase !== "preparing")
            return;
        setBindingNotice("机器码已绑定，正在检查助手状态…");
        if (socket.current?.readyState === WebSocket.OPEN)
            socket.current.send(JSON.stringify({ action: "heartbeat" }));
    });
    const create = () => action(async (isCurrent) => {
        if (!quote)
            return;
        if (quote.entryPoints && !window.confirm(`本场一次性扣 ${quote.entryPoints} 积分，开始后 ${quote.durationLimitMinutes} 分钟自动结束。确认创建？`))
            return;
        createKey.current ?? (createKey.current = crypto.randomUUID());
        let row;
        try {
            row = await mockRequest("/mock-interviews", { idempotencyKey: createKey.current,
                title: target.trim() ? `${target.trim()} · 模拟面试` : "模拟面试", targetRole: target,
                expectedBillingClass: quote.billingClass });
        }
        catch (cause) {
            try {
                if (isCurrent())
                    await reload();
            }
            catch { }
            throw cause;
        }
        if (!isCurrent())
            return;
        createKey.current = null;
        navigate(`/app/mock-interviews/${row.sessionId}`);
    });
    if (enabled === false)
        return __cnJsx("main", { className: "app-page mock-page" },
            __cnJsx("h1", null, "\u6A21\u62DF\u9762\u8BD5\u5C1A\u672A\u5F00\u653E"),
            __cnJsx("p", null, "\u6B63\u5F0F\u5F00\u653E\u524D\uFF0C\u539F\u6709\u9762\u8BD5\u529F\u80FD\u4E0D\u53D7\u5F71\u54CD\u3002"),
            __cnJsx(Link, { to: "/app" }, "\u8FD4\u56DE\u9762\u8BD5\u6A21\u5F0F"));
    if (!id)
        return __cnJsx("main", { className: "app-page mock-page" },
            __cnJsx("header", { className: "mock-page-heading" },
                __cnJsx("div", null,
                    __cnJsx("span", { className: "eyebrow" }, "AI PRACTICE"),
                    __cnJsx("h1", null, "\u628A\u4E0B\u4E00\u6B21\u9762\u8BD5\uFF0C\u63D0\u524D\u7EC3\u4E00\u904D\u3002"),
                    __cnJsx("p", null, "\u56F4\u7ED5\u4F60\u7684\u7B80\u5386\u5C55\u5F00\uFF0C\u6700\u591A 10 \u9053\u95EE\u9898\u3002\u6309\u81EA\u5DF1\u7684\u8282\u594F\u56DE\u7B54\uFF0C\u7ED3\u675F\u540E\u83B7\u5F97\u53CD\u9988\u3002")),
                __cnJsx("span", { className: "mock-pill" },
                    "\u5DF2\u4FDD\u5B58 ",
                    quote?.savedCount ?? "—",
                    " / 2")),
            error && __cnJsx("p", { role: "alert", className: "mock-alert" }, error),
            __cnJsx("section", { className: "mock-create-grid" },
                __cnJsx("div", { className: "mock-portrait" },
                    __cnJsx("img", { src: "/assets/mock-interview/interviewer-v1.png", alt: "\u539F\u521B\u865A\u62DF AI \u9762\u8BD5\u5B98\u5F62\u8C61" }),
                    __cnJsx("div", null,
                        __cnJsx("span", { className: "mock-pill" }, "AI \u6A21\u62DF\u9762\u8BD5\u5B98"),
                        __cnJsx("h2", null, "\u4E00\u6B21\u5BF9\u8BDD\uFF0C\u4E00\u6B21\u66F4\u5145\u5206\u7684\u51C6\u5907\u3002"))),
                __cnJsx("div", { className: "mock-panel" },
                    __cnJsx("span", { className: "eyebrow" }, "\u5F00\u59CB\u7EC3\u4E60"),
                    __cnJsx("h2", null, "\u8FD9\u6B21\uFF0C\u60F3\u51C6\u5907\u4EC0\u4E48\u5C97\u4F4D\uFF1F"),
                    __cnJsx("label", null,
                        "\u76EE\u6807\u5C97\u4F4D ",
                        __cnJsx("span", null, "\u9009\u586B"),
                        __cnJsx("input", { value: target, maxLength: 80, disabled: busy, onChange: e => { setTarget(e.target.value); createKey.current = null; }, placeholder: "\u4F8B\u5982\uFF1A\u540E\u7AEF\u5F00\u53D1\u5DE5\u7A0B\u5E08" })),
                    __cnJsx("div", { className: "mock-price" },
                        __cnJsx("strong", null, quote?.entryPoints === 0 ? "本场免费" : "100 积分 / 场"),
                        __cnJsx("p", null, quote?.entryPoints === 0 ? `有效会员今日剩余 ${quote.dailyFreeRemaining} 场免费模拟面试。` : "每场一次性扣 100 积分，朗读、回答和报告不额外收费。")),
                    __cnJsx("ul", { className: "mock-notes" },
                        __cnJsx("li", null, "\u521B\u5EFA\u540E\u9009\u62E9\u4E00\u4EFD\u5DF2\u89E3\u6790\u7B80\u5386\uFF0C\u8FDE\u63A5\u73B0\u6709\u6B63\u5F0F\u7248\u684C\u9762\u52A9\u624B\uFF0C\u65E0\u9700\u4E3A\u6B64\u5347\u7EA7\u52A9\u624B\u3002"),
                        __cnJsx("li", null,
                            "\u6240\u6709\u6709\u6548\u4F1A\u5458\u6BCF\u5929\u514D\u8D39 ",
                            quote?.dailyFreeLimit ?? 1,
                            " \u573A\uFF0C\u5317\u4EAC\u65F6\u95F4 00:00 \u66F4\u65B0\uFF1B\u5F53\u5929\u514D\u8D39\u6B21\u6570\u7528\u5B8C\u540E\uFF0C100 \u79EF\u5206 / \u573A\u3002"),
                        __cnJsx("li", null,
                            "\u5F00\u59CB\u540E ",
                            quote?.durationLimitMinutes ?? 60,
                            " \u5206\u949F\u81EA\u52A8\u7ED3\u675F\uFF1B\u51C6\u5907\u9636\u6BB5\u4E0D\u8BA1\u65F6\uFF0C\u6682\u505C\u3001\u51FA\u9898\u7B49\u5F85\u548C\u65AD\u7EBF\u4E0D\u5EF6\u957F\u7ED3\u675F\u65F6\u95F4\u3002"),
                        __cnJsx("li", null, "\u7ED3\u675F\u81EA\u52A8\u4FDD\u5B58\u95EE\u7B54\u548C\u62A5\u544A\uFF0C\u6700\u591A 2 \u573A\uFF1B\u4E0D\u4FDD\u5B58\u539F\u59CB\u97F3\u9891\u3002\u4E0D\u81EA\u52A8\u8986\u76D6\u65E7\u8BB0\u5F55\u3002"),
                        __cnJsx("li", null, "\u4E3B\u52A8\u53D6\u6D88\u4E0D\u9000\u521B\u5EFA\u8D39\uFF1B\u7CFB\u7EDF\u6545\u969C\u5BFC\u81F4\u4E00\u9898\u90FD\u65E0\u6CD5\u5B8C\u6210\u65F6\uFF0C\u9000\u672C\u573A\u79EF\u5206\u6216\u6062\u590D\u514D\u8D39\u6B21\u6570\u3002")),
                    __cnJsx("button", { className: "button primary", disabled: busy || !quote || quote.savedCount >= 2, onClick: () => void create() }, busy ? "正在创建…" : quote && quote.savedCount >= 2 ? "请先手动删除旧记录" : "创建模拟面试 →"))),
            __cnJsx("section", { className: "mock-history" },
                __cnJsx("h2", null, "\u6211\u7684\u6A21\u62DF\u9762\u8BD5"),
                sessions.length === 0 && __cnJsx("p", null, "\u4F60\u7684\u6BCF\u4E00\u6B21\u7EC3\u4E60\uFF0C\u90FD\u4F1A\u4ECE\u8FD9\u91CC\u5F00\u59CB\u3002"),
                sessions.map(row => __cnJsx("article", { key: row.sessionId, className: "mock-panel" },
                    __cnJsx("div", null,
                        __cnJsx("h3", null, row.title),
                        __cnJsx("p", null,
                            mockPhaseLabel[row.state.phase],
                            " \u00B7 ",
                            new Date(row.createdAtMs).toLocaleString("zh-CN"))),
                    __cnJsx(Link, { className: "button", to: `/app/mock-interviews/${row.sessionId}` }, row.state.phase === "completed" ? "查看报告" : "继续面试"),
                    row.state.phase === "completed" && __cnJsx("button", { className: "button", disabled: busy, onClick: () => void action(async (isCurrent) => { if (!window.confirm("删除本场问答和报告？不会退还已使用积分或免费次数。"))
                            return; await mockRequest(`/mock-interviews/${row.sessionId}`, undefined, "DELETE"); if (isCurrent())
                            await reload(); }) }, "\u5220\u9664")))));
    if (!session)
        return __cnJsx("main", { className: "app-page mock-page" },
            __cnJsx("h1", null, "\u6B63\u5728\u6062\u590D\u9762\u8BD5\u2026"),
            error && __cnJsx("p", { role: "alert" }, error));
    const phase = session.state.phase;
    const question = session.state.rounds.at(-1);
    return __cnJsx("main", { className: "app-page mock-page" },
        __cnJsx("header", { className: "mock-page-heading" },
            __cnJsx("div", null,
                __cnJsx(Link, { to: "/app/mock-interviews" }, "\u2190 \u6211\u7684\u6A21\u62DF\u9762\u8BD5"),
                __cnJsx("h1", null, session.title),
                __cnJsx("p", null,
                    session.billingClass === "daily_pass_free" ? "本场全程免费" : "创建费用 100 积分",
                    session.refunded ? " · 本场已退还" : ""),
                __cnJsx("p", null, session.deadlineAtMs ? __cnJsx(__cnFragment, null,
                    "\u672C\u573A\u7ED3\u675F\u65F6\u95F4\uFF1A",
                    new Date(session.deadlineAtMs).toLocaleString("zh-CN", { timeZone: "Asia/Shanghai", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hour12: false }),
                    "\uFF08\u5317\u4EAC\u65F6\u95F4\uFF09 \u00B7 \u6682\u505C\u3001\u7B49\u5F85\u548C\u91CD\u8FDE\u4E0D\u5EF6\u957F") : __cnJsx(__cnFragment, null,
                    "\u5F00\u59CB\u540E ",
                    session.durationLimitMinutes ?? 60,
                    " \u5206\u949F\u81EA\u52A8\u7ED3\u675F\uFF0C\u51C6\u5907\u9636\u6BB5\u4E0D\u8BA1\u65F6\u3002"))),
            __cnJsx("span", { className: "mock-pill" }, mockPhaseLabel[phase])),
        error && __cnJsx("p", { role: "alert", className: "mock-alert" }, error),
        playbackNotice && __cnJsx("p", { role: "status", "aria-label": "\u7F51\u9875\u58F0\u97F3\u72B6\u6001", className: "mock-alert" }, playbackNotice),
        phase !== "completed" && !connected && __cnJsx("button", { className: "button", onClick: () => setReconnect(n => n + 1) }, "\u91CD\u65B0\u8FDE\u63A5"),
        session.endReason === "time_limit" && __cnJsx("p", { role: "status", className: "mock-alert" },
            "\u5DF2\u8FBE\u5230\u672C\u573A ",
            session.durationLimitMinutes ?? 60,
            " \u5206\u949F\u65F6\u9650\uFF0C\u6A21\u62DF\u9762\u8BD5\u5DF2\u81EA\u52A8\u7ED3\u675F\u3002\u5DF2\u63D0\u4EA4\u7684\u56DE\u7B54\u5C06\u4FDD\u5B58\u5728\u62A5\u544A\u4E2D\u3002"),
        phase === "completed" ? __cnJsx(MockReportView, { session: session }) : __cnJsx("div", { className: "mock-workbench" },
            __cnJsx("aside", { className: `mock-portrait ${playing ? "is-speaking" : ""}` },
                __cnJsx("img", { src: "/assets/mock-interview/interviewer-v1.png", alt: "AI \u6A21\u62DF\u9762\u8BD5\u5B98" }),
                __cnJsx("div", null,
                    __cnJsx("span", { className: "mock-pill" }, "AI \u6A21\u62DF\u9762\u8BD5\u5B98 \u00B7 \u975E\u771F\u4EBA"),
                    __cnJsx("h2", null, mockPhaseLabel[phase]),
                    __cnJsx(MockPlaybackIndicator, { player: voice.current, phase: phase }))),
            __cnJsx("section", { className: "mock-panel mock-conversation" },
                phase === "preparing" ? __cnJsx(__cnFragment, null,
                    __cnJsx("span", { className: "eyebrow" }, "\u5F00\u59CB\u524D\u68C0\u67E5"),
                    __cnJsx("h2", null, "\u8BA9\u8FD9\u573A\u9762\u8BD5\u56F4\u7ED5\u4F60\u5C55\u5F00"),
                    __cnJsx("label", null,
                        "\u9009\u62E9\u5DF2\u89E3\u6790\u7684\u7B80\u5386",
                        __cnJsx("select", { "aria-label": "\u9009\u62E9\u7B80\u5386", value: session.resumeId ?? "", disabled: busy || !connected, onChange: e => void selectResume(e.target.value) },
                            __cnJsx("option", { value: "" }, "\u8BF7\u9009\u62E9\u7B80\u5386"),
                            resumes.map(doc => __cnJsx("option", { key: doc.documentId, value: doc.documentId }, doc.displayName)))),
                    resumes.length === 0 && __cnJsx("p", null,
                        __cnJsx(Link, { to: "/app/library" }, "\u5148\u53BB\u8D44\u6599\u9875\u4E0A\u4F20\u5E76\u89E3\u6790\u7B80\u5386")),
                    __cnJsx("label", null,
                        "\u684C\u9762\u52A9\u624B\u673A\u5668\u7801",
                        __cnJsx("input", { inputMode: "numeric", maxLength: 6, value: machineCode, onChange: e => setMachineCode(e.target.value.replace(/\D/g, "")), placeholder: "6 \u4F4D\u673A\u5668\u7801" })),
                    __cnJsx("button", { className: "button", disabled: busy || !connected || machineCode.length !== 6, onClick: () => void bindDevice() }, "\u9A8C\u8BC1\u5E76\u8FDE\u63A5"),
                    __cnJsx("p", { role: "status", "aria-label": "\u52A9\u624B\u8FDE\u63A5\u72B6\u6001" }, !connected ? "页面连接未就绪，请重新连接。" : bindingNotice || (preparation?.code === "mock_microphone_checking" && microphoneCheckExpired ? "麦克风状态尚未确认，请重新检查。" : preparation?.message) || (desktopConnected ? "● 助手已连接，开始后连接收音通道" : "请打开桌面助手，输入机器码后验证并连接。")),
                    ["mock_microphone_checking", "mock_microphone_required"].includes(preparation?.code ?? "") && __cnJsx("button", { className: "button", disabled: !connected || rechecking || busy, onClick: recheckMicrophone }, rechecking ? "正在重新检查…" : "重新检查麦克风"),
                    __cnJsx("button", { className: "button primary", disabled: !connected || !desktopConnected || preparation?.ready === false || !session.resumeId || busy || playbackUnlocking === "manual", onClick: () => requestPlayback("start", true) }, "\u5F00\u59CB\u6A21\u62DF\u9762\u8BD5 \u2192"),
                    __cnJsx("details", { className: "mock-instructions mock-muted" },
                        __cnJsx("summary", null, "\u4F7F\u7528\u8BF4\u660E"),
                        __cnJsx("p", null, "\u73B0\u6709\u6B63\u5F0F\u7248\u52A9\u624B\u5373\u53EF\uFF0C\u4EC5\u4F7F\u7528\u9EA6\u514B\u98CE\uFF0C\u5EFA\u8BAE\u4F69\u6234\u8033\u673A\u3002\u539F\u59CB\u97F3\u9891\u4E0D\u4FDD\u5B58\uFF0C\u975E\u56DE\u7B54\u65F6\u6BB5\u7684\u97F3\u9891\u4E0D\u8F6C\u5199\u3002\u65E7\u7248\u52A9\u624B\u53EF\u80FD\u5728\u63D0\u95EE\u65F6\u7EE7\u7EED\u91C7\u96C6\u4E0A\u4F20\uFF0C\u670D\u52A1\u5668\u4F1A\u4E22\u5F03\u975E\u56DE\u7B54\u65F6\u6BB5\u7684\u97F3\u9891\u3002"))) : __cnJsx(__cnFragment, null,
                    __cnJsx("div", { className: "mock-question-meta" },
                        __cnJsx("span", null,
                            "\u95EE\u9898 ",
                            session.state.rounds.length,
                            " / 10"),
                        __cnJsx("span", null, desktopConnected ? "麦克风助手在线" : "助手未连接")),
                    question && __cnJsx("h2", { className: "mock-question" }, question.question),
                    (phase === "generating_question" || phase === "generating_report") && __cnJsx("div", { role: "status", className: "mock-wait" },
                        __cnJsx("span", { className: "mock-spinner" }),
                        mockPhaseLabel[phase],
                        __cnJsx("small", null, "\u8BF7\u7A0D\u5019\uFF0C\u4E0D\u989D\u5916\u6536\u8D39\uFF0C\u65E0\u9700\u91CD\u590D\u521B\u5EFA\u3002")),
                    session.error === "generation_unavailable" && __cnJsx("button", { className: "button", disabled: !connected, onClick: () => command("retry") }, "\u91CD\u8BD5\u751F\u6210"),
                    waitingForMicrophone && phase === "speaking" && __cnJsx("p", { role: "status", className: "mock-wait" }, "\u6B63\u5728\u7B49\u5F85\u52A9\u624B\u6536\u97F3\u901A\u9053\u8FDE\u63A5\u3002\u8BF7\u4FDD\u6301\u52A9\u624B\u8FD0\u884C\uFF0C\u663E\u793A\u201C\u8F6E\u5230\u4F60\u56DE\u7B54\u201D\u540E\u518D\u5F00\u53E3\u3002"),
                    settlingAudio && phase === "speaking" && __cnJsx("p", { role: "status", className: "mock-wait" }, "\u6B63\u5728\u51C6\u5907\u6536\u97F3\uFF0C\u8BF7\u7A0D\u5019\u7247\u523B\uFF0C\u663E\u793A\u201C\u8F6E\u5230\u4F60\u56DE\u7B54\u201D\u540E\u518D\u5F00\u53E3\u3002"),
                    phase === "speaking" && __cnJsx("div", { className: "mock-actions" },
                        __cnJsx("button", { className: "button primary", disabled: !connected || playing || playbackUnlocking === "manual" || waitingForMicrophone || settlingAudio, onClick: () => requestPlayback("speak", true) }, "\u6717\u8BFB\u95EE\u9898"),
                        __cnJsx("button", { className: "button", disabled: !connected || waitingForMicrophone || settlingAudio, onClick: () => { cancelPlaybackIntent(); playbackRecoveryNeeded.current = false; setPlaybackNotice(""); voice.current.stop(); setPlaying(false); playingQuestion.current = null; if (question)
                                prepareListening(question.question_id); } }, "\u6211\u5DF2\u8BFB\u5B8C\uFF0C\u5F00\u59CB\u56DE\u7B54")),
                    (phase === "listening" || phase === "paused") && __cnJsx(__cnFragment, null,
                        __cnJsx("label", null,
                            "\u4F60\u7684\u56DE\u7B54",
                            __cnJsx("textarea", { "aria-label": "\u4F60\u7684\u56DE\u7B54", rows: 8, value: draft, maxLength: 8000, onChange: e => { edited.current = true; setEditing(true); draftText.current = e.target.value; setDraft(e.target.value); }, placeholder: "\u8BF7\u5BF9\u7740\u9EA6\u514B\u98CE\u56DE\u7B54\uFF0C\u4E5F\u53EF\u5728\u8FD9\u91CC\u6821\u6B63\u8F6C\u5199\u3002" })),
                        __cnJsx("p", { className: "mock-muted" }, editing ? "已进入文字校正，新的转写不会覆盖你的修改。" : "思考和停顿不会自动进入下一题。确认回答后再提交。")),
                    __cnJsx("div", { className: "mock-actions" },
                        phase === "listening" && __cnJsx(__cnFragment, null,
                            __cnJsx("button", { className: "button primary", disabled: !connected || !draft.trim(), onClick: () => { answerId.current ?? (answerId.current = crypto.randomUUID()); command("submit", { answer: draft.trim(), submissionId: answerId.current }); } }, "\u56DE\u7B54\u5B8C\u6210 \u2192"),
                            __cnJsx("button", { className: "button", onClick: () => command("pause"), disabled: !connected }, "\u6682\u505C"),
                            __cnJsx("button", { className: "button", onClick: () => command("replay"), disabled: !connected }, "\u91CD\u65B0\u542C\u9898")),
                        phase === "paused" && __cnJsx("button", { className: "button primary", disabled: !connected || !desktopConnected, onClick: () => command("resume") }, "\u7EE7\u7EED\u672C\u9898"))),
                __cnJsx("footer", { className: "mock-end" },
                    __cnJsx("p", null, "\u7ED3\u675F\u540E\u81EA\u52A8\u4FDD\u5B58\u62A5\u544A\u3002\u4E0D\u8DB3 10 \u9898\u5C06\u6807\u6CE8\u4E3A\u90E8\u5206\u7EC3\u4E60\u3002"),
                    __cnJsx("button", { className: "button", disabled: !connected || phase === "generating_report", onClick: () => { if (window.confirm("结束本场练习并生成报告？主动结束不退创建费。")) {
                            cancelPlaybackIntent();
                            playbackRecoveryNeeded.current = false;
                            setPlaybackNotice("");
                            voice.current.stop();
                            setPlaying(false);
                            playingQuestion.current = null;
                            command("end");
                        } } }, "\u7ED3\u675F\u9762\u8BD5")))));
}
function ae({ session: e }) {
	let t = e.report, [r, i] = d(!1), [a, o] = d(null), s = f(!1), c = async () => {
		if (!(s.current || e.state.phase !== "completed" || !t)) {
			s.current = !0, i(!0), o(null);
			try {
				let { downloadMockInterviewWord: t } = await import("./mock-interview-word-export-BOxeSAD1.js");
				await t(e);
			} catch {
				o("Word 下载失败，请重试。在线报告不受影响。");
			} finally {
				s.current = !1, i(!1);
			}
		}
	};
	return /* @__PURE__ */ m("section", {
		className: "mock-report",
		children: [
			e.state.phase === "completed" && t && /* @__PURE__ */ m("div", {
				className: "mock-report-actions",
				children: [/* @__PURE__ */ p("button", {
					className: "button primary",
					disabled: r,
					"aria-busy": r,
					onClick: () => void c(),
					children: r ? "正在生成 Word…" : "下载 Word"
				}), /* @__PURE__ */ p("span", {
					className: "mock-muted",
					children: "包含评分、逐题问答与改进建议 · 下载不额外扣费"
				})]
			}),
			a && /* @__PURE__ */ p("p", {
				role: "alert",
				className: "mock-alert",
				children: a
			}),
			/* @__PURE__ */ m("div", {
				className: "mock-panel mock-report-summary",
				children: [/* @__PURE__ */ m("div", {
					className: "mock-score",
					children: [(t == null ? void 0 : t.overall_score) ?? "—", /* @__PURE__ */ p("small", { children: (t == null ? void 0 : t.overall_score) == null ? "有效回答不足，不评分" : "/ 100" })]
				}), /* @__PURE__ */ m("div", { children: [
					/* @__PURE__ */ p("span", {
						className: "eyebrow",
						children: e.partial ? "部分练习报告" : "面试练习报告"
					}),
					/* @__PURE__ */ p("h2", { children: "复盘，让下一次更好。" }),
					/* @__PURE__ */ p("p", { children: t == null ? void 0 : t.summary }),
					/* @__PURE__ */ p("p", {
						className: "mock-muted",
						children: l
					})
				] })]
			}),
			(t == null ? void 0 : t.dimensions) && /* @__PURE__ */ p("div", {
				className: "mock-dimensions",
				children: Object.entries(t.dimensions).map(([e, t]) => /* @__PURE__ */ m("div", {
					className: "mock-panel",
					children: [
						/* @__PURE__ */ p("span", { children: ee[e] ?? e }),
						/* @__PURE__ */ p("strong", { children: t }),
						/* @__PURE__ */ p("meter", {
							min: 0,
							max: 100,
							value: t,
							"aria-label": ee[e] ?? e
						})
					]
				}, e))
			}),
			e.state.rounds.map((e, n) => {
				let r = t == null ? void 0 : t.feedback.find((t) => t.question_id === e.question_id);
				return /* @__PURE__ */ m("article", {
					className: "mock-panel",
					children: [
						/* @__PURE__ */ m("span", {
							className: "eyebrow",
							children: ["问题 ", n + 1]
						}),
						/* @__PURE__ */ p("h3", { children: e.question }),
						/* @__PURE__ */ p("p", {
							className: "mock-answer",
							children: e.answer ?? "本题未提交回答，不计分。"
						}),
						r && /* @__PURE__ */ m(h, { children: [
							/* @__PURE__ */ p("h4", { children: "回答中的证据" }),
							/* @__PURE__ */ p("blockquote", { children: r.answer_quote }),
							/* @__PURE__ */ p("h4", { children: "做得好的地方" }),
							/* @__PURE__ */ p("p", { children: r.strength }),
							/* @__PURE__ */ p("h4", { children: "可以提升" }),
							/* @__PURE__ */ p("p", { children: r.improvement }),
							/* @__PURE__ */ p("h4", { children: "回答建议" }),
							/* @__PURE__ */ p("p", { children: r.suggestion })
						] })
					]
				}, e.question_id);
			}),
			!!(t != null && t.practice_priorities.length) && /* @__PURE__ */ m("section", {
				className: "mock-panel",
				children: [/* @__PURE__ */ p("h3", { children: "下一次练习重点" }), /* @__PURE__ */ p("ul", { children: t.practice_priorities.map((e, t) => /* @__PURE__ */ p("li", { children: e }, t)) })]
			}),
			/* @__PURE__ */ p(n, {
				className: "button",
				to: "/app/mock-interviews",
				children: "返回我的模拟面试"
			})
		]
	});
}
//#endregion
export { ie as MockInterviewPage, ae as MockReportView, _ as mockPhaseLabel };
