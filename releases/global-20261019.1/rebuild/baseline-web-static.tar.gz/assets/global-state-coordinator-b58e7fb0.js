const WEB_STATE_CACHE_TTL_MS = 1500;
const cloneWebState = (state) => structuredClone(state);
const abortError = () => new DOMException("Aborted", "AbortError");
const awaitWithAbort = (promise, signal) => {
    if (!signal)
        return promise;
    if (signal.aborted)
        return Promise.reject(abortError());
    return new Promise((resolve, reject) => {
        const onAbort = () => {
            cleanup();
            reject(abortError());
        };
        const cleanup = () => signal.removeEventListener("abort", onAbort);
        signal.addEventListener("abort", onAbort, { once: true });
        promise.then(value => {
            cleanup();
            resolve(value);
        }, error => {
            cleanup();
            reject(error);
        });
    });
};
export async function coordinatedLoadState(signal, options, getAuthHeaders) {
    var _a, _b, _c;
    (_a = this.webStateCache) !== null && _a !== void 0 ? _a : (this.webStateCache = new Map());
    (_b = this.webStateRequests) !== null && _b !== void 0 ? _b : (this.webStateRequests = new Map());
    const key = (options === null || options === void 0 ? void 0 : options.auth) === false ? "public" : "authenticated";
    if (signal === null || signal === void 0 ? void 0 : signal.aborted)
        return Promise.reject(abortError());
    const headers = key === "public" ? {} : getAuthHeaders();
    if (key === "authenticated") {
        const identity = (_c = new Headers(headers).get("Authorization")) !== null && _c !== void 0 ? _c : "";
        if (identity !== this.webStateAuthIdentity) {
            this.webStateAuthIdentity = identity;
            this.webStateCache.delete(key);
            this.webStateRequests.delete(key);
        }
    }
    const now = Date.now();
    const cached = this.webStateCache.get(key);
    if (!(options === null || options === void 0 ? void 0 : options.force) && cached && now - cached.cachedAtMs < WEB_STATE_CACHE_TTL_MS) {
        return cloneWebState(cached.state);
    }
    let request = (options === null || options === void 0 ? void 0 : options.force) ? undefined : this.webStateRequests.get(key);
    if (!request) {
        const controller = new AbortController();
        request = this.client.request("/api/v1/web/state", { headers }, controller.signal)
            .then(state => {
            if (this.webStateRequests.get(key) === request) {
                this.webStateCache.set(key, { state: cloneWebState(state), cachedAtMs: Date.now() });
            }
            return state;
        })
            .finally(() => {
            if (this.webStateRequests.get(key) === request)
                this.webStateRequests.delete(key);
        });
        this.webStateRequests.set(key, request);
    }
    return awaitWithAbort(request, signal).then(cloneWebState);
}
