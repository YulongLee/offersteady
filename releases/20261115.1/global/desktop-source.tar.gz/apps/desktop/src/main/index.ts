import { app, BrowserWindow, Menu, Tray, desktopCapturer, globalShortcut, ipcMain, nativeImage, powerMonitor, powerSaveBlocker, safeStorage, session, shell, systemPreferences } from "electron";
import { execFile, spawn, type ChildProcess } from "node:child_process";
import { existsSync, readFileSync } from "node:fs";
import path from "node:path";
import { floatingInterviewPage, initializeFloatingInterview, openFloatingInterview, requestWindowCaptureProtection } from "./floating-interview";
import { captureMacPreviewSources } from "./floating-screen-capture";
import type { CaptureState } from "@offersteady/protocol" with { "resolution-mode": "import" };
import { DeviceCredentialVault } from "./credential-vault";
import { DevicePairingIdentityStore } from "./device-pairing";
import { DEFAULT_SCREENSHOT_SHORTCUT, SCREENSHOT_SHORTCUT_OPTIONS, ScreenshotShortcutStore, isSupportedScreenshotShortcut } from "./screenshot-shortcut";
import { desktopPollDelayMs } from "./polling-policy";
import {
  screenshotBindingKey,
  screenshotBindingTransition,
  screenshotStreamAdmissionAction,
  screenshotStreamEligible,
  screenshotStreamSuspensionTransition,
  screenshotStreamTransition,
} from "./screenshot-stream-policy";
import { ScreenshotCaptureLock } from "./screenshot-capture-lock";
import { DesktopCaptureEventParser } from "./capture-event-stream";
import { decideRendererRecovery } from "./renderer-recovery-policy";
import { RealtimeTransportDiagnosticsLog } from "./realtime-transport-diagnostics-log";
import { canAcquireDisplaySources, resolveDisplayMediaSource, type ScreenPermissionStatus } from "./display-media-access";
import { globalStableUserDataDirectory, legacyUserDataDirectories, migrateLegacyCompanionState, stableUserDataDirectory } from "./user-data-bootstrap";
import { resolveDesktopProductEdition } from "./product-edition";
import { loadLocalTestRuntime, localTestUserDataDirectory } from "./local-test-runtime";
import { DesktopCapabilitySnapshot } from "./desktop-capability-snapshot";
import { MicrophonePermissionController } from "./microphone-permission";
import { CompanionWindowVisibility, RESTORE_WINDOW_SHORTCUT } from "./window-visibility";
import { companionTrayImages, CompanionTrayPresentation } from "./tray-presentation";
import { DesktopConnectionRecovery, type DesktopRegistrationContext } from "./desktop-connection-recovery";
import { WrittenScreenshotProcessor, type WrittenScreenshotJob } from "./written-screenshot-processor";
import { WrittenSessionAwakeGuard } from "./written-session-awake";
import { screenshotFailureMessage } from "./global-screenshot-failure-copy";

const localTestRuntime = loadLocalTestRuntime(app.isPackaged, process.resourcesPath);

const packagedGlobalRuntimeConfigPath = () => path.join(process.resourcesPath, "global-runtime-config.json");
const isGlobalRelease = () => resolveDesktopProductEdition({
  explicitEdition: process.env.OFFERSTEADY_PRODUCT_EDITION,
  hasPackagedGlobalRuntimeConfig: app.isPackaged && existsSync(packagedGlobalRuntimeConfigPath()),
  applicationName: app.getName(),
}) === "global";
const floatingPreviewBuild = app.isPackaged && isGlobalRelease() && existsSync(floatingInterviewPage);
const desktopCopy = (domestic: string, global: string) => isGlobalRelease() ? global : domestic;

const originalUserDataDirectory = app.getPath("userData");
const stableCompanionUserDataDirectory = localTestRuntime ? localTestUserDataDirectory(app.getPath("appData")) : isGlobalRelease()
  ? globalStableUserDataDirectory(app.getPath("appData"))
  : stableUserDataDirectory(app.getPath("appData"));
const companionLegacyUserDataDirectories = localTestRuntime || isGlobalRelease() ? [] : legacyUserDataDirectories(app.getPath("appData"), originalUserDataDirectory);
app.setPath("userData", stableCompanionUserDataDirectory);

// Local ad-hoc builds cannot reliably retain Apple's separate Audio Capture
// grant across rebuilds. Reuse the Screen & System Audio Recording grant,
// which is also required by screenshot capture and is stable for this app.
if (process.platform === "darwin") {
  app.commandLine.appendSwitch("disable-features", "MacCatapLoopbackAudioForScreenShare");
}

let mainWindow: BrowserWindow | null = null;
let tray: Tray | null = null;
let trayPresentation: CompanionTrayPresentation | null = null;
let captureState: CaptureState = "not-connected";
let isQuitting = false;
let credentialVault: DeviceCredentialVault | null = null;
let pairingIdentityStore: DevicePairingIdentityStore | null = null;
let screenshotShortcutStore: ScreenshotShortcutStore | null = null;
let realtimeTransportDiagnosticsLog: RealtimeTransportDiagnosticsLog | null = null;
let activeScreenshotShortcut = "";
let screenshotShortcutRegistration = {
  ok: false,
  accelerator: "",
  message: "截屏回答快捷键尚未注册。",
};
let screenshotShortcutTriggerInFlight = false;
const screenshotCaptureLock = new ScreenshotCaptureLock();
let lastScreenshotShortcutTriggerAt = 0;
let screenshotSessionMode: string | null = null;
let writtenScreenshotGeneration = 0;
let writtenPendingProbeScheduled = false;
const writtenCaptureOwners = new Map<string, number>();
let writtenNativeSourceReadInFlight = false;
const writtenAwake = new WrittenSessionAwakeGuard({
  start: () => powerSaveBlocker.start("prevent-app-suspension"),
  stop: id => { powerSaveBlocker.stop(id); },
});
let screenshotRequestTimer: NodeJS.Timeout | null = null;
let realtimeAudioInterval: NodeJS.Timeout | null = null;
let preferredScreenSourceId: string | null = null;
let hasRegisteredThisRun = false;
const desktopCapabilitySnapshot = new DesktopCapabilitySnapshot();
const microphonePermission = new MicrophonePermissionController({
  platform: process.platform,
  readStatus: () => systemPreferences.getMediaAccessStatus("microphone"),
  requestAccess: () => systemPreferences.askForMediaAccess("microphone"),
});
let restoreShortcutRegistered = false;
let processingRemoteScreenshotRequestId: string | null = null;
const nativeAudioProcesses = new Map<string, ChildProcess>();
let mainRealtimeBindingKey: string | null = null;
let mainRealtimeBinding: {
  sessionId: string;
  ownerUserId: string;
  deviceId: string;
  manualCode: string;
  displayName?: string;
} | null = null;
let mainRealtimePublisherTokens = new Map<"microphone" | "system", { token: string; sourceId: string }>();
let mainRealtimePublisherPromises = new Map<"microphone" | "system", Promise<{ token: string; sourceId: string } | null>>();
let mainRealtimeSequences = new Map<"microphone" | "system", number>();
let mainRealtimeEnsureInFlight = false;
let mainRealtimeOwnsNativeAudio = false;
let rendererOwnsNativeAudio = false;
let remoteScreenshotPollOwner: number | null = null;
let remoteScreenshotPollFailureCount = 0;
let remoteScreenshotStreamController: AbortController | null = null;
let remoteScreenshotLoopGeneration = 0;
let remoteScreenshotSuspended = false;
let remoteScreenshotBindingKey: string | null = null;
let displayMediaFailureBackoffUntil = 0;
let rendererRecoveryAttempts: readonly number[] = [];
let rendererRecoveryResetTimer: NodeJS.Timeout | null = null;
interface RendererReliabilityHeartbeat {
  readonly sentAtMs: number;
  readonly sessionId: string | null;
  readonly sessionStatus: string | null;
  readonly desiredCapture: boolean;
  readonly captureStartedAtMs: number | null;
  readonly renderCount: number;
  readonly reactRenderRate: number;
  readonly jsHeapUsed: number | null;
  readonly jsHeapTotal: number | null;
  readonly jsHeapLimit: number | null;
  readonly jsExternal: number | null;
  readonly arrayBuffers: number | null;
  readonly audioWorkletCallbackRate: number;
  readonly workletPostMessageRate: number;
  readonly audioBytesPerSecond: number;
  readonly publisher: Record<string, unknown> | null;
}

interface RendererReliabilitySample extends RendererReliabilityHeartbeat {
  readonly milestoneMinutes: number;
  readonly rendererPid: number;
  readonly rendererRss: number | null;
  readonly rendererPrivateMemory: number | null;
  readonly rendererCpu: number | null;
}

interface RendererRecoveryContext {
  readonly crashAtMs: number;
  readonly reason: string;
  readonly exitCode: number;
  readonly sessionId: string | null;
  readonly desiredCapture: boolean;
  readonly recoveryAttempt: number;
}

let latestRendererHeartbeat: RendererReliabilityHeartbeat | null = null;
let latestRendererProcessMetrics: ReturnType<typeof currentRendererProcessMetrics> | null = null;
let rendererReliabilitySessionId: string | null = null;
let rendererReliabilitySamples: RendererReliabilitySample[] = [];
let rendererRecoveryContext: RendererRecoveryContext | null = null;
const RENDERER_RELIABILITY_MILESTONES_MINUTES = [0, 5, 10, 20, 30, 60, 120] as const;
const activeDesktopRequestControllers = new Set<AbortController>();
const desktopApiRequestsInFlight = new Map<string, Promise<DesktopApiRequestResult>>();
const SCREENSHOT_VISION_MAX_LONG_EDGE = 1600;
const SCREENSHOT_VISION_JPEG_QUALITY = 72;
const DESKTOP_CONTROL_REQUEST_TIMEOUT_MS = 8_000;
const DESKTOP_AUDIO_REQUEST_TIMEOUT_MS = 12_000;
const DESKTOP_UPLOAD_REQUEST_TIMEOUT_MS = 30_000;

interface DesktopApiRequestResult {
  readonly ok: boolean;
  readonly status: number;
  readonly statusText: string;
  readonly headers: Record<string, string>;
  readonly bodyText: string;
}

const fetchWithTimeout = async (
  input: string | URL,
  init: RequestInit = {},
  timeoutMs = DESKTOP_CONTROL_REQUEST_TIMEOUT_MS,
) => {
  const controller = new AbortController();
  const callerSignal = init.signal;
  const abortFromCaller = () => controller.abort(callerSignal?.reason);
  if (callerSignal?.aborted) abortFromCaller();
  else callerSignal?.addEventListener("abort", abortFromCaller, { once: true });
  activeDesktopRequestControllers.add(controller);
  const timeout = setTimeout(() => controller.abort(new Error("desktop_request_timeout")), timeoutMs);
  try {
    return await fetch(input, { ...init, signal: controller.signal });
  } finally {
    clearTimeout(timeout);
    callerSignal?.removeEventListener("abort", abortFromCaller);
    activeDesktopRequestControllers.delete(controller);
  }
};

const abortPendingDesktopRequests = () => {
  for (const controller of activeDesktopRequestControllers) controller.abort(new Error("desktop_app_quitting"));
  activeDesktopRequestControllers.clear();
  desktopApiRequestsInFlight.clear();
};

const currentRendererProcessMetrics = (window: BrowserWindow) => {
  const rendererPid = window.webContents.getOSProcessId();
  const metric = app.getAppMetrics().find((entry) => entry.pid === rendererPid);
  return {
    rendererPid,
    rendererRss: metric?.memory?.workingSetSize ?? null,
    rendererPrivateMemory: metric?.memory?.privateBytes ?? null,
    rendererCpu: metric?.cpu?.percentCPUUsage ?? null,
  };
};

const recordRendererReliabilityMilestone = (window: BrowserWindow, heartbeat: RendererReliabilityHeartbeat) => {
  if (!heartbeat.sessionId || !heartbeat.desiredCapture || heartbeat.captureStartedAtMs === null) return;
  if (rendererReliabilitySessionId !== heartbeat.sessionId) {
    rendererReliabilitySessionId = heartbeat.sessionId;
    rendererReliabilitySamples = [];
  }
  const elapsedMinutes = Math.max(0, (heartbeat.sentAtMs - heartbeat.captureStartedAtMs) / 60_000);
  const milestone = RENDERER_RELIABILITY_MILESTONES_MINUTES.find((candidate) => (
    elapsedMinutes >= candidate
    && !rendererReliabilitySamples.some((sample) => sample.milestoneMinutes === candidate)
  ));
  if (milestone === undefined) return;
  const sample: RendererReliabilitySample = {
    ...heartbeat,
    ...currentRendererProcessMetrics(window),
    milestoneMinutes: milestone,
  };
  rendererReliabilitySamples = [...rendererReliabilitySamples, sample].slice(-RENDERER_RELIABILITY_MILESTONES_MINUTES.length);
  console.info("[desktop-reliability] resource milestone", sample);
};

const emitNativeAudioEvent = (event: Record<string, unknown>) => {
  mainWindow?.webContents.send("desktop:native-audio-event", event);
};

const stopNativeAudioStreams = () => {
  for (const child of nativeAudioProcesses.values()) {
    child.kill("SIGTERM");
  }
  nativeAudioProcesses.clear();
};

const stateLabels: Record<CaptureState, string> = {
  "not-connected": desktopCopy("未连接", "Not connected"),
  "permission-required": desktopCopy("需要权限", "Permission required"),
  ready: desktopCopy("收音已就绪", "Audio ready"),
  capturing: desktopCopy("正在收音", "Listening"),
  paused: desktopCopy("已暂停", "Paused"),
  reconnecting: desktopCopy("正在重连", "Reconnecting"),
  error: desktopCopy("连接异常", "Connection issue"),
};

const isBetaRelease = () => process.env.OFFERSTEADY_RELEASE_CHANNEL === "beta" || /\bbeta\b/i.test(app.getName());
const packagedGlobalConfig = () => {
  if (!isGlobalRelease() || !app.isPackaged) return null;
  try {
    const parsed = JSON.parse(readFileSync(packagedGlobalRuntimeConfigPath(), "utf8")) as { webWorkspaceUrl?: string; apiBaseUrl?: string };
    return parsed.webWorkspaceUrl && parsed.apiBaseUrl ? parsed : null;
  } catch {
    return null;
  }
};
const defaultWebWorkspaceUrl = () => {
  if (localTestRuntime) return localTestRuntime.webWorkspaceUrl;
  if (isGlobalRelease()) return process.env.OFFERSTEADY_GLOBAL_WEB_URL || packagedGlobalConfig()?.webWorkspaceUrl || "";
  return isBetaRelease() ? "https://beta.mianshiwen.cn/app" : "https://mianshiwen.cn/app";
};
const defaultApiBaseUrl = () => {
  if (localTestRuntime) return localTestRuntime.apiBaseUrl;
  if (isGlobalRelease()) return process.env.OFFERSTEADY_GLOBAL_API_BASE_URL || packagedGlobalConfig()?.apiBaseUrl || "";
  return isBetaRelease() ? "https://beta.mianshiwen.cn/api/v1" : "https://mianshiwen.cn/api/v1";
};

const desktopConfig = () => ({
  appVersion: app.getVersion(),
  platform: process.platform === "darwin" ? "macos" : process.platform === "win32" ? "windows" : "unsupported",
  architecture: process.arch === "arm64" ? "arm64" : process.arch === "x64" ? "x64" : "unknown",
  platformVersion: process.getSystemVersion(),
  protocolVersion: "2.0",
  captureRuntime: "electron-single-owner",
  releaseChannel: localTestRuntime ? "local-test" : isGlobalRelease() ? "global" : isBetaRelease() ? "beta" : "production",
  webWorkspaceUrl: localTestRuntime ? localTestRuntime.webWorkspaceUrl : isGlobalRelease()
    ? defaultWebWorkspaceUrl()
    : process.env.OFFERSTEADY_DESKTOP_WEB_URL || defaultWebWorkspaceUrl(),
  apiBaseUrl: localTestRuntime ? localTestRuntime.apiBaseUrl : isGlobalRelease()
    ? defaultApiBaseUrl()
    : process.env.OFFERSTEADY_API_BASE_URL || defaultApiBaseUrl(),
  realtimeEndpointing: {
    mode: process.env.OFFERSTEADY_REALTIME_ENDPOINTING_MODE === "legacy-threshold"
      ? "legacy-threshold"
      : "commercial-adaptive",
  },
});

const nativeRuntimePath = () => {
  const packagedPath = path.join(process.resourcesPath, "app/native/macos-capture/OfferSteadyCaptureRuntime");
  if (existsSync(packagedPath)) return packagedPath;
  return path.resolve(__dirname, "../native/macos-capture/OfferSteadyCaptureRuntime");
};

const getNativeRuntimeHealth = async () => {
  if (process.platform === "win32") {
    return {
      available: true,
      ready: true,
      runtime: "electron-wasapi-loopback",
      version: "2.0",
      microphonePermission: "managed-by-windows",
      screenPermission: "managed-by-windows",
      screenCaptureKitAvailable: false,
      computerOutputCapturePath: "electron-display-loopback",
      message: "Windows 由主助手统一负责麦克风、电脑输出和屏幕采集。",
      errors: [],
    };
  }
  if (process.platform !== "darwin") {
    return { available: false, ready: false, errorCode: "unsupported-platform", message: "当前系统暂不支持桌面采集。" };
  }
  const screenPermission = systemPreferences.getMediaAccessStatus("screen");
  return {
    available: true,
    ready: screenPermission === "granted",
    runtime: "electron-single-owner",
    version: "2.0",
    microphonePermission: systemPreferences.getMediaAccessStatus("microphone"),
    screenPermission,
    screenCaptureKitAvailable: true,
    computerOutputCapturePath: "electron-display-loopback",
    message: screenPermission === "granted"
      ? "Electron 主助手统一负责麦克风、电脑输出和屏幕采集。"
      : "请向面试稳伴随程序授予屏幕与系统音频录制权限。",
    errors: [],
  };
};

const requestElectronScreenCaptureAccess = async () => {
  if (process.platform !== "darwin") return true;
  return systemPreferences.getMediaAccessStatus("screen") === "granted";
};

const optimizeScreenshotForVision = (image: Electron.NativeImage) => {
  const size = image.getSize();
  const longest = Math.max(size.width, size.height);
  const ratio = longest > SCREENSHOT_VISION_MAX_LONG_EDGE ? SCREENSHOT_VISION_MAX_LONG_EDGE / longest : 1;
  const optimized = ratio < 1
    ? image.resize({
      width: Math.max(1, Math.round(size.width * ratio)),
      height: Math.max(1, Math.round(size.height * ratio)),
      quality: "best",
    })
    : image;
  const optimizedSize = optimized.getSize();
  const jpeg = optimized.toJPEG(SCREENSHOT_VISION_JPEG_QUALITY);
  return {
    dataUrl: `data:image/jpeg;base64,${jpeg.toString("base64")}`,
    width: optimizedSize.width,
    height: optimizedSize.height,
    byteLength: jpeg.length,
    contentType: "image/jpeg",
    extension: "jpg",
  };
};

const startNativeAudioProcess = (sourceKind: "microphone" | "system", sourceId: string) => {
  if (process.platform !== "darwin") {
    emitNativeAudioEvent({
      type: "status",
      sourceKind,
      sourceId,
      errorCode: "unsupported-platform",
      message: "当前原生实时采集仅支持 macOS。",
    });
    return false;
  }
  const helper = nativeRuntimePath();
  if (!existsSync(helper)) {
    emitNativeAudioEvent({
      type: "status",
      sourceKind,
      sourceId,
      errorCode: "native-runtime-missing",
      message: "缺少 macOS 原生采集运行时，请重新打包安装伴随程序。",
    });
    return false;
  }
  const command = sourceKind === "microphone" ? "stream-microphone" : "stream-system";
  const child = spawn(helper, [command, sourceId], { stdio: ["ignore", "pipe", "pipe"] });
  nativeAudioProcesses.set(sourceKind, child);
  let stdoutBuffer = "";
  child.stdout.setEncoding("utf8");
  child.stdout.on("data", (chunk) => {
    stdoutBuffer += chunk;
    let newlineIndex = stdoutBuffer.indexOf("\n");
    while (newlineIndex >= 0) {
      const line = stdoutBuffer.slice(0, newlineIndex).trim();
      stdoutBuffer = stdoutBuffer.slice(newlineIndex + 1);
      if (line) {
        try {
          const event = JSON.parse(line);
          emitNativeAudioEvent(event);
          void publishNativeAudioEventFromMain(event).catch((error) => {
            console.warn("[main-realtime-audio] frame publish failed", error);
          });
        } catch {
          emitNativeAudioEvent({
            type: "status",
            sourceKind,
            sourceId,
            errorCode: "native-runtime-invalid-event",
            message: "原生采集运行时返回了无法解析的事件。",
          });
        }
      }
      newlineIndex = stdoutBuffer.indexOf("\n");
    }
  });
  child.stderr.setEncoding("utf8");
  child.stderr.on("data", (chunk) => {
    const message = String(chunk).trim();
    if (!message) return;
    emitNativeAudioEvent({
      type: "status",
      sourceKind,
      sourceId,
      errorCode: "native-runtime-stderr",
      message,
    });
  });
  child.on("exit", (code, signal) => {
    if (nativeAudioProcesses.get(sourceKind) === child) nativeAudioProcesses.delete(sourceKind);
    if (signal === "SIGTERM") return;
    emitNativeAudioEvent({
      type: "status",
      sourceKind,
      sourceId,
      errorCode: code === 0 ? null : "native-runtime-exited",
      message: code === 0 ? "原生采集流已结束。" : `原生采集流异常退出：${code ?? "unknown"}`,
    });
  });
  child.on("error", (error) => {
    if (nativeAudioProcesses.get(sourceKind) === child) nativeAudioProcesses.delete(sourceKind);
    emitNativeAudioEvent({
      type: "status",
      sourceKind,
      sourceId,
      errorCode: "native-runtime-spawn-failed",
      message: error.message,
    });
  });
  return true;
};

const createMainRealtimePublisher = async (
  binding: { sessionId: string; ownerUserId: string; displayName?: string },
  sourceKind: "microphone" | "system",
) => {
  const response = await fetchWithTimeout(desktopApiUrl("/realtime-speech/publishers"), {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      userId: binding.ownerUserId,
      sessionId: binding.sessionId,
      sourceKind,
      clientName: `${binding.displayName || app.getName()} · main-${sourceKind}`,
    }),
  });
  if (!response.ok) throw new Error(`main_publisher_create_failed_${sourceKind}_${response.status}`);
  const envelope = await response.json() as { data?: { token?: string } };
  const token = envelope.data?.token;
  if (!token) throw new Error(`main_publisher_token_missing_${sourceKind}`);
  return token;
};

const stopMainRealtimeAudioPublishing = () => {
  if (mainRealtimeOwnsNativeAudio) stopNativeAudioStreams();
  mainRealtimeOwnsNativeAudio = false;
  mainRealtimeBindingKey = null;
  mainRealtimeBinding = null;
  mainRealtimePublisherTokens.clear();
  mainRealtimePublisherPromises.clear();
  mainRealtimeSequences.clear();
  mainRealtimeEnsureInFlight = false;
};

const ensureMainRealtimePublisher = async (sourceKind: "microphone" | "system", sourceId: string) => {
  const existing = mainRealtimePublisherTokens.get(sourceKind);
  if (existing) return existing;
  if (!mainRealtimeBinding || rendererOwnsNativeAudio) return null;
  const pending = mainRealtimePublisherPromises.get(sourceKind);
  if (pending) return pending;
  const promise = createMainRealtimePublisher(mainRealtimeBinding, sourceKind)
    .then((token) => {
      const tokenInfo = { token, sourceId };
      mainRealtimePublisherTokens.set(sourceKind, tokenInfo);
      return tokenInfo;
    })
    .catch((error) => {
      console.warn(`[main-realtime-audio] ${sourceKind} publisher failed`, error);
      return null;
    })
    .finally(() => {
      mainRealtimePublisherPromises.delete(sourceKind);
    });
  mainRealtimePublisherPromises.set(sourceKind, promise);
  return promise;
};

const getLiveDesktopBinding = async () => {
  if (!pairingIdentityStore) return null;
  const identity = await pairingIdentityStore.loadOrCreate(`${app.getName()} · ${process.platform === "darwin" ? "Mac" : "Desktop"}`);
  const response = await fetchWithTimeout(desktopApiUrl(`/realtime-speech/desktop-devices/pairing-status?manualCode=${encodeURIComponent(identity.manualCode)}&deviceId=${encodeURIComponent(identity.deviceId)}`));
  if (!response.ok) return null;
  const envelope = await response.json() as {
    data?: {
      registered?: boolean;
      bound?: boolean;
      sessionStatus?: string;
      binding?: {
        bindingId?: string;
        bindingGeneration?: number;
        sessionId: string;
        ownerUserId: string;
        deviceId: string;
        manualCode: string;
        displayName?: string;
      };
    };
  };
  if (!envelope.data?.registered || envelope.data.sessionStatus !== "live" || !envelope.data.binding) return null;
  return envelope.data.binding;
};

const getDesktopScreenshotPollingState = async () => {
  const liveBindingState = screenshotStreamEligible(captureState);
  if (!pairingIdentityStore || !liveBindingState) return { live: false as const, identity: null };
  const startedAt = Date.now();
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    const identity = await Promise.race([
      pairingIdentityStore.loadOrCreate(`${app.getName()} · ${process.platform === "darwin" ? "Mac" : "Desktop"}`),
      new Promise<never>((_, reject) => { timer = setTimeout(() => reject(new Error("screenshot_identity_timeout")), 5_000); }),
    ]);
    if (Date.now() - startedAt >= 5_000) throw new Error("screenshot_identity_timeout");
    return { live: true as const, identity };
  } finally { clearTimeout(timer); }
};

const ensureMainRealtimeAudioPublishing = async () => {
  if (process.platform !== "darwin") {
    if (mainRealtimeBindingKey || mainRealtimePublisherTokens.size > 0) stopMainRealtimeAudioPublishing();
    return;
  }
  if (mainRealtimeEnsureInFlight) return;
  mainRealtimeEnsureInFlight = true;
  try {
    if (rendererOwnsNativeAudio) {
      if (mainRealtimeBindingKey || mainRealtimePublisherTokens.size > 0) stopMainRealtimeAudioPublishing();
      return;
    }
    const binding = await getLiveDesktopBinding();
    if (!binding) {
      if (mainRealtimeBindingKey) stopMainRealtimeAudioPublishing();
      return;
    }
    const bindingKey = `${binding.sessionId}:${binding.ownerUserId}:${binding.deviceId}:${binding.manualCode}:${binding.bindingId ?? ""}:${binding.bindingGeneration ?? 1}`;
    if (mainRealtimeBindingKey !== bindingKey) {
      stopMainRealtimeAudioPublishing();
      mainRealtimeEnsureInFlight = true;
      mainRealtimeBindingKey = bindingKey;
      mainRealtimeBinding = binding;
    }
    const microphoneStarted = nativeAudioProcesses.has("microphone")
      || startNativeAudioProcess("microphone", "native-microphone");
    const systemStarted = nativeAudioProcesses.has("system")
      || startNativeAudioProcess("system", "native-system-output");
    mainRealtimeOwnsNativeAudio = microphoneStarted || systemStarted;
  } finally {
    mainRealtimeEnsureInFlight = false;
  }
};

const publishNativeAudioEventFromMain = async (event: Record<string, unknown>) => {
  if (event.type !== "frame") return;
  if (event.sourceKind !== "microphone" && event.sourceKind !== "system") return;
  if (rendererOwnsNativeAudio) return;
  const sourceKind = event.sourceKind;
  if (typeof event.audioBase64 !== "string" || !event.audioBase64) return;
  const eventSourceId = typeof event.sourceId === "string"
    ? event.sourceId
    : sourceKind === "microphone" ? "native-microphone" : "native-system-output";
  const tokenInfo = await ensureMainRealtimePublisher(sourceKind, eventSourceId);
  if (!tokenInfo) return;
  const sequence = (mainRealtimeSequences.get(sourceKind) ?? 0) + 1;
  mainRealtimeSequences.set(sourceKind, sequence);
  const capturedAtMs = typeof event.capturedAtMs === "number" ? event.capturedAtMs : Date.now();
  const durationMs = typeof event.durationMs === "number" ? event.durationMs : 20;
  const sampleRateHz = typeof event.sampleRateHz === "number" ? event.sampleRateHz : 16_000;
  const channels = event.channels === 2 ? 2 : 1;
  const response = await fetchWithTimeout(desktopApiUrl("/realtime-speech/frames"), {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      type: "audio-frame",
      token: tokenInfo.token,
      deviceId: (await pairingIdentityStore?.loadOrCreate(`${app.getName()} · ${process.platform === "darwin" ? "Mac" : "Desktop"}`))?.deviceId || "",
      sourceId: typeof event.sourceId === "string" ? event.sourceId : tokenInfo.sourceId,
      sourceKind,
      sequence,
      segmentId: `${sourceKind}-main-${sequence}`,
      revision: 1,
      capturedAtMs,
      startedAtMs: capturedAtMs - durationMs,
      endedAtMs: capturedAtMs,
      durationMs,
      codec: "pcm-s16le",
      sampleRateHz,
      channels,
      isFinal: true,
      traceId: `${sourceKind}:main:${sequence}`,
      sentAtMs: Date.now(),
      audioBase64: event.audioBase64,
    }),
  }, DESKTOP_AUDIO_REQUEST_TIMEOUT_MS);
  if (!response.ok) {
    const message = await response.text().catch(() => "");
    throw new Error(`main_frame_publish_failed_${response.status}:${message.slice(0, 200)}`);
  }
};

const startMainRealtimeAudioLoop = () => {
  // Electron renderer is the only production capture and transport owner.
  // The legacy main-process publisher remains permanently disabled.
  if (realtimeAudioInterval) clearInterval(realtimeAudioInterval);
  realtimeAudioInterval = null;
};

const probeWebUrl = async (url: string) => {
  try {
    const response = await fetchWithTimeout(url, { method: "GET", redirect: "manual" }, 5_000);
    return response.status >= 200 && response.status < 500;
  } catch {
    return false;
  }
};

const apiBaseParts = () => {
  const base = new URL(desktopConfig().apiBaseUrl);
  return {
    origin: base.origin,
    pathname: base.pathname.replace(/\/+$/, ""),
  };
};

const assertOfferSteadyApiUrl = (url: string) => {
  const base = apiBaseParts();
  const requested = new URL(url, desktopConfig().apiBaseUrl);
  const normalizedPath = requested.pathname.replace(/\/+$/, "");
  if (requested.origin !== base.origin || (base.pathname && !normalizedPath.startsWith(base.pathname))) {
    throw new Error("desktop_api_url_not_allowed");
  }
  return requested.toString();
};

const desktopCapabilities = (deviceId: string) => {
  const config = desktopConfig();
  const permission = microphonePermission.snapshot();
  return desktopCapabilitySnapshot.forDevice(deviceId, {
    protocolVersion: config.protocolVersion,
    appVersion: config.appVersion,
    platform: config.platform,
    architecture: config.architecture,
    platformVersion: config.platformVersion,
  }, permission.source === "os" && (process.platform === "darwin" || permission.permission !== "unknown")
    ? permission.permission : undefined);
};

const syncDesktopRegistration = async (context: DesktopRegistrationContext) => {
  if (!pairingIdentityStore || !context.isCurrent()) return false;
  const identity = await pairingIdentityStore.loadOrCreate(`${app.getName()} · ${process.platform === "darwin" ? "Mac" : "Desktop"}`);
  if (!context.isCurrent()) return false;
  const config = desktopConfig();
  const endpoint = hasRegisteredThisRun
    ? `${config.apiBaseUrl}/realtime-speech/desktop-devices/${encodeURIComponent(identity.deviceId)}/heartbeat`
    : `${config.apiBaseUrl}/realtime-speech/desktop-devices/register`;
  const response = await fetch(endpoint, {
    method: "POST", signal: context.signal,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ...(hasRegisteredThisRun ? {} : { deviceId: identity.deviceId }),
      manualCode: identity.manualCode, displayName: identity.displayName,
      capabilities: desktopCapabilities(identity.deviceId) }),
  });
  await response.text();
  if (!context.isCurrent()) return false;
  if (!response.ok) {
    if (hasRegisteredThisRun && response.status === 404) hasRegisteredThisRun = false;
    return false;
  }
  hasRegisteredThisRun = true;
  return true;
};

const desktopConnectionRecovery = new DesktopConnectionRecovery({
  register: syncDesktopRegistration,
  onSuccess: context => {
    if (screenshotSessionMode === "written" && remoteScreenshotBindingKey
      && (remoteScreenshotSuspended || context.reason !== "heartbeat" && context.reason !== "startup")) {
      void recoverWrittenScreenshotConnection(context);
    }
  },
  onDiagnostic: diagnostic => {
    if (diagnostic.event === "failed" || diagnostic.event === "succeeded" && diagnostic.failures > 0) {
      console.info("[desktop-connection]", diagnostic);
    }
    if (!diagnostic.online) writtenAwake.refresh(false);
  },
});
const startDesktopRegistrationLoop = () => desktopConnectionRecovery.start();

const desktopApiUrl = (pathName: string) => {
  const config = desktopConfig();
  return `${config.apiBaseUrl.replace(/\/+$/, "")}/${pathName.replace(/^\/+/, "")}`;
};

const allowedRuntimePermissions = new Set(["media", "display-capture"]);

const permissionSettingsUrl = (kind: "microphone" | "screen" | "camera" | "audio") => {
  if (kind === "microphone" || kind === "audio") return "x-apple.systempreferences:com.apple.preference.security?Privacy_Microphone";
  if (kind === "camera") return "x-apple.systempreferences:com.apple.preference.security?Privacy_Camera";
  return "x-apple.systempreferences:com.apple.preference.security?Privacy_ScreenCapture";
};

const updateTray = () => {
  if (!tray || !trayPresentation) return;
  tray.setToolTip(`${desktopCopy("面试稳伴随程序", "OfferSteady Companion")} · ${stateLabels[captureState]}`);
  trayPresentation.update(Menu.buildFromTemplate([
    { label: stateLabels[captureState], enabled: false },
    { type: "separator" },
    { label: desktopCopy("打开伴随程序", "Open companion"), click: () => windowVisibility.restore() },
    { label: desktopCopy("隐藏助手", "Hide companion"), click: () => windowVisibility.hide() },
    ...(floatingPreviewBuild ? [{ label: "Floating window", click: openFloatingInterview }] : []),
    {
      label: desktopCopy("停止并退出", "Stop and quit"),
      click: () => {
        captureState = "not-connected";
        app.quit();
      },
    },
  ]));
};

const ensureTray = () => {
  if (!tray || tray.isDestroyed()) {
    const images = companionTrayImages(isGlobalRelease());
    tray = new Tray(images.normal);
    trayPresentation = new CompanionTrayPresentation(tray, {
      platform: process.platform, images,
      isHidden: () => windowVisibility.isHidden(),
      restore: () => windowVisibility.restore(),
      showMenu: menu => {
        if (!mainWindow || mainWindow.isDestroyed()) createWindow();
        if (!mainWindow || mainWindow.isDestroyed() || !tray || tray.isDestroyed()) return;
        // An explicit hidden host avoids focus-dependent popup and the Tray
        // popup API's synthetic left-click path on macOS.
        menu.popup({ window: mainWindow });
      },
    });
  }
  updateTray();
};

const windowVisibility = new CompanionWindowVisibility({
  hideWindow: () => { if (mainWindow && !mainWindow.isDestroyed()) mainWindow.hide(); },
  showWindow: () => {
    if (!mainWindow || mainWindow.isDestroyed()) { createWindow(); return; }
    if (mainWindow.isMinimized()) mainWindow.restore();
    mainWindow.show();
    mainWindow.focus();
  },
  skipTaskbar: skip => { if (process.platform === "win32" && mainWindow && !mainWindow.isDestroyed()) mainWindow.setSkipTaskbar(skip); },
  setTrayTransparent: () => { ensureTray(); trayPresentation?.refresh(); },
  ...(process.platform === "darwin" ? {
    hideDock: () => app.dock?.hide(),
    showDock: () => app.dock?.show(),
  } : {}),
});

const publishScreenshotCaptureLock = () => {
  const state = screenshotCaptureLock.state();
  mainWindow?.webContents.send("desktop:screenshot-capture-lock-changed", state);
  return state;
};

interface DesktopScreenCaptureResult {
  readonly name: string;
  readonly width?: number;
  readonly height?: number;
  readonly dataUrl?: string;
  readonly contentType?: string;
  readonly byteLength?: number;
  readonly originalWidth?: number;
  readonly originalHeight?: number;
  readonly extension?: string;
  readonly errorMessage?: string;
}

const releaseScreenshotCaptureLock = (expectedOwner?: number | null) => {
  screenshotCaptureLock.release(expectedOwner);
  const state = publishScreenshotCaptureLock();
  queueMicrotask(() => writtenScreenshotProcessor.resume());
  return state;
};

const captureCurrentScreen = async (
  screenSourceId: string | null,
  lockAlreadyHeld = false,
  releaseAfterCapture = false,
  lifecycle?: { signal: AbortSignal; ownerToken: number },
): Promise<DesktopScreenCaptureResult> => {
  if (!lockAlreadyHeld && !screenshotCaptureLock.tryAcquire()) {
    return { name: "共享屏幕截取", errorMessage: screenshotCaptureLock.state().message };
  }
  if (!lockAlreadyHeld) publishScreenshotCaptureLock();
  const ownerToken = lifecycle?.ownerToken ?? screenshotCaptureLock.ownerToken();
  const failed = (result: DesktopScreenCaptureResult) => {
    releaseScreenshotCaptureLock(ownerToken);
    return result;
  };
  if (lifecycle && writtenNativeSourceReadInFlight) {
    return failed({ name: "共享屏幕截取", errorMessage: "屏幕截取仍在恢复，请重新打开助手后重试。" });
  }
  const requestedScreenSourceId = screenSourceId || preferredScreenSourceId;
  const useFilteredCapture = floatingPreviewBuild && process.platform === "darwin";
  let sources;
  let ownsNativeRead = false;
  try {
    if (lifecycle) { writtenNativeSourceReadInFlight = true; ownsNativeRead = true; }
    sources = useFilteredCapture
      ? await captureMacPreviewSources(requestedScreenSourceId, lifecycle?.signal)
      : await desktopCapturer.getSources({ types: ["screen"], thumbnailSize: { width: 1920, height: 1080 } });
  } catch (error) {
    return failed({
      name: "共享屏幕截取",
      errorMessage: error instanceof Error
        ? useFilteredCapture
          ? error.message
          : `获取屏幕源失败：${error.message}。请在系统设置中允许面试稳伴随程序录制屏幕后重启应用。`
        : "获取屏幕源失败，请在系统设置中允许面试稳伴随程序录制屏幕后重启应用。",
    });
  } finally {
    // getSources has no abort API. A timed-out native read must not multiply
    // into more native reads on each explicit retry while its result is fenced.
    if (ownsNativeRead) writtenNativeSourceReadInFlight = false;
  }
  if (lifecycle?.signal.aborted || screenshotCaptureLock.ownerToken() !== ownerToken) throw new Error("screenshot_operation_obsolete");
  const selectedScreen = useFilteredCapture || !requestedScreenSourceId
    ? sources[0]
    : sources.find((source) => source.id === requestedScreenSourceId);
  if (requestedScreenSourceId && !selectedScreen) {
    return failed({
      name: "共享屏幕截取",
      errorMessage: "当前选择的屏幕源已经不可用，请在本地助手中重新选择显示器后再试。",
    });
  }
  if (!selectedScreen) {
    return failed({ name: "共享屏幕截取", errorMessage: "没有找到可截取的屏幕，请检查屏幕录制权限。" });
  }
  const thumbnail = selectedScreen.thumbnail;
  const size = thumbnail.getSize();
  if (thumbnail.isEmpty()) {
    return failed({
      name: selectedScreen.name || "共享屏幕截取",
      width: size.width,
      height: size.height,
      errorMessage: "屏幕缩略图为空，请在系统设置中允许面试稳伴随程序录制屏幕后重启应用。",
    });
  }
  const optimized = optimizeScreenshotForVision(thumbnail);
  const result = {
    name: selectedScreen.name || "共享屏幕截取",
    width: optimized.width,
    height: optimized.height,
    dataUrl: optimized.dataUrl,
    contentType: optimized.contentType,
    byteLength: optimized.byteLength,
    originalWidth: size.width,
    originalHeight: size.height,
    extension: optimized.extension,
  };
  if (releaseAfterCapture) releaseScreenshotCaptureLock(ownerToken);
  return result;
};

const uploadScreenshotCapture = async (request: {
  url: string;
  deviceId: string;
  manualCode: string;
  dataUrl: string;
  filename: string;
  signal?: AbortSignal;
}) => {
  const url = assertOfferSteadyApiUrl(request.url);
  const [meta, payload] = request.dataUrl.split(",", 2);
  if (!meta || !payload) throw new Error("invalid_screenshot_data_url");
  const mimeType = meta.match(/^data:(.*?);base64$/)?.[1] || "image/png";
  const binary = Buffer.from(payload, "base64");
  const form = new FormData();
  form.append("deviceId", request.deviceId);
  form.append("manualCode", request.manualCode);
  form.append("screenshot", new Blob([binary], { type: mimeType }), request.filename);
  const response = request.signal
    ? await fetch(url, { method: "POST", body: form, signal: request.signal })
    : await fetchWithTimeout(url, { method: "POST", body: form }, DESKTOP_UPLOAD_REQUEST_TIMEOUT_MS);
  return {
    ok: response.ok,
    status: response.status,
    statusText: response.statusText,
    headers: Object.fromEntries(response.headers.entries()),
    bodyText: await response.text(),
  };
};

const reportRemoteScreenshotFailure = async (identity: { deviceId: string; manualCode: string }, requestId: string, message: string, stage = "capture-failed") => {
  try {
    await fetchWithTimeout(desktopApiUrl(`/screenshot-answer/capture-requests/${encodeURIComponent(requestId)}/desktop-fail`), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        deviceId: identity.deviceId,
        manualCode: identity.manualCode,
        message: screenshotFailureMessage(isGlobalRelease(), message),
        stage,
      }),
    });
  } catch (error) {
    console.warn("[remote-screenshot] failed to report capture failure", error);
  }
};

interface WrittenBinding {
  sessionId: string; bindingId: string; ownerUserId: string; deviceId: string; manualCode: string;
}
const isCurrentWrittenJob = (job: WrittenScreenshotJob) => !isQuitting
  && screenshotSessionMode === "written" && screenshotStreamEligible(captureState)
  && job.bindingKey === remoteScreenshotBindingKey && job.generation === writtenScreenshotGeneration;

const readWrittenBinding = async (identity: { deviceId: string; manualCode: string }, signal: AbortSignal): Promise<WrittenBinding | null> => {
  const response = await fetch(desktopApiUrl(`/realtime-speech/desktop-devices/pairing-status?manualCode=${encodeURIComponent(identity.manualCode)}&deviceId=${encodeURIComponent(identity.deviceId)}`), { signal });
  if (!response.ok) { await response.body?.cancel(); return null; }
  const envelope = await response.json() as { data?: { registered?: boolean; bound?: boolean; sessionStatus?: string; sessionMode?: string; binding?: WrittenBinding } };
  const value = envelope.data;
  return value?.registered && value.bound && value.sessionStatus === "live" && value.sessionMode === "written"
    && value.binding?.deviceId === identity.deviceId && value.binding.manualCode === identity.manualCode
    && Boolean(value.binding.ownerUserId) ? value.binding : null;
};

let writtenRecoveryCheckInFlight = false;
const recoverWrittenScreenshotConnection = async (context: DesktopRegistrationContext) => {
  if (writtenRecoveryCheckInFlight) return;
  const expectedKey = remoteScreenshotBindingKey;
  const expectedGeneration = writtenScreenshotGeneration;
  const controller = new AbortController();
  const startedAt = Date.now();
  let deadline: ReturnType<typeof setTimeout> | undefined;
  const current = () => Date.now() - startedAt < 5_000 && context.isCurrent() && !controller.signal.aborted
    && expectedKey === remoteScreenshotBindingKey && expectedGeneration === writtenScreenshotGeneration;
  try {
    if (!expectedKey || !pairingIdentityStore || !current()) return;
    writtenRecoveryCheckInFlight = true;
    const timeout = new Promise<never>((_, reject) => {
      deadline = setTimeout(() => { controller.abort(); reject(new Error("written_recovery_timeout")); }, 5_000);
    });
    const verify = async () => {
      const identity = await pairingIdentityStore!.loadOrCreate(app.getName());
      if (!current()) return;
      const binding = await readWrittenBinding(identity, AbortSignal.any([context.signal, controller.signal]));
      if (!current()) return;
      const valid = screenshotSessionMode === "written" && screenshotStreamEligible(captureState)
        && binding !== null && screenshotBindingKey(binding) === expectedKey;
      writtenAwake.refresh(valid);
      if (valid && remoteScreenshotSuspended) startRemoteScreenshotRequestLoop();
    };
    await Promise.race([verify(), timeout]);
  } catch {
    if (current()) writtenAwake.refresh(false);
  } finally {
    clearTimeout(deadline);
    controller.abort();
    writtenRecoveryCheckInFlight = false;
  }
};

interface DeviceScreenshotRequest {
  requestId: string; sessionId: string; ownerUserId: string; deviceId: string; manualCode: string; status: string; createdAtMs?: number;
}
const screenshotRequestMatchesBinding = (request: DeviceScreenshotRequest, binding: WrittenBinding, identity: { deviceId: string; manualCode: string }) =>
  request.sessionId === binding.sessionId && request.ownerUserId === binding.ownerUserId
  && request.deviceId === identity.deviceId && request.manualCode === identity.manualCode;
const readWrittenRequest = async (identity: { deviceId: string; manualCode: string }, binding: WrittenBinding, signal: AbortSignal, requestId?: string) => {
  const query = new URLSearchParams({ manualCode: identity.manualCode, sessionId: binding.sessionId,
    ...(requestId ? { requestId } : {}) });
  const response = await fetch(desktopApiUrl(`/screenshot-answer/desktop-devices/${encodeURIComponent(identity.deviceId)}/capture-requests/next?${query}`), { signal });
  if (!response.ok) { await response.body?.cancel(); throw new Error("written_capture_connection_unavailable"); }
  const envelope = await response.json() as { data?: DeviceScreenshotRequest | null; timestamp?: string };
  const request = envelope.data;
  if (request && !screenshotRequestMatchesBinding(request, binding, identity)) throw new Error("written_capture_scope_mismatch");
  // Use the server envelope clock when available; do not re-photograph an old
  // explicit request merely because a stream reconnected or recent-ID cache rotated.
  const serverNow = envelope.timestamp ? Date.parse(envelope.timestamp) : Date.now();
  if (request?.status === "requested" && typeof request.createdAtMs === "number"
    && Number.isFinite(serverNow) && serverNow - request.createdAtMs >= 60_000) {
    return { ...request, status: "expired" };
  }
  return request ?? null;
};

const releaseWrittenOwner = (requestId: string, token: number) => () => {
  if (writtenCaptureOwners.get(requestId) === token) writtenCaptureOwners.delete(requestId);
  releaseScreenshotCaptureLock(token);
};

const scheduleWrittenPendingProbe = (excludedRequestId: string) => {
  if (writtenPendingProbeScheduled || isQuitting || screenshotSessionMode !== "written" || !remoteScreenshotBindingKey) return;
  writtenPendingProbeScheduled = true;
  setTimeout(() => {
    writtenPendingProbeScheduled = false;
    if (isQuitting || screenshotSessionMode !== "written" || !remoteScreenshotBindingKey
      || !screenshotStreamEligible(captureState) || writtenScreenshotProcessor.snapshot().pendingCount > 0
      || writtenScreenshotProcessor.snapshot().activeRequestId) return;
    // One canonical read after explicit work; no extra continuous polling loop.
    void pollRemoteScreenshotRequest(false, excludedRequestId).catch(() => undefined);
  }, 0);
};

const writtenScreenshotProcessor = new WrittenScreenshotProcessor<DesktopScreenCaptureResult>({
  inspect: async (job, signal) => {
    if (!isCurrentWrittenJob(job)) return { current: false, requested: false };
    const binding = await readWrittenBinding(job.identity, signal);
    if (signal.aborted || !isCurrentWrittenJob(job) || !binding || screenshotBindingKey(binding) !== job.bindingKey) {
      return { current: false, requested: false };
    }
    const request = await readWrittenRequest(job.identity, binding, signal, job.requestId);
    return { current: !signal.aborted && isCurrentWrittenJob(job), requested: request?.requestId === job.requestId && request.status === "requested" };
  },
  acquire: job => {
    if (!isCurrentWrittenJob(job) || !screenshotCaptureLock.tryAcquire()) return null;
    const owner = screenshotCaptureLock.ownerToken()!;
    writtenCaptureOwners.set(job.requestId, owner);
    publishScreenshotCaptureLock();
    return releaseWrittenOwner(job.requestId, owner);
  },
  capture: async (job, signal) => {
    const owner = writtenCaptureOwners.get(job.requestId);
    if (!isCurrentWrittenJob(job) || owner === undefined || signal.aborted) throw new Error("written_capture_obsolete");
    const capture = await captureCurrentScreen(null, true, false, { signal, ownerToken: owner });
    if (capture.errorMessage || !capture.dataUrl) throw new Error("written_capture_unavailable");
    return capture;
  },
  upload: async (job, capture, signal) => {
    if (!isCurrentWrittenJob(job) || signal.aborted || !capture.dataUrl) throw new Error("written_capture_obsolete");
    const extension = capture.extension || "jpg";
    const result = await uploadScreenshotCapture({
      url: desktopApiUrl(`/screenshot-answer/capture-requests/${encodeURIComponent(job.requestId)}/desktop-upload`),
      deviceId: job.identity.deviceId, manualCode: job.identity.manualCode,
      dataUrl: capture.dataUrl, filename: `screen.${extension}`, signal,
    });
    if (!result.ok) throw new Error(`written_upload_${result.status}`);
  },
  report: async (job, failure, signal) => {
    if (!isCurrentWrittenJob(job) || signal.aborted) return;
    const response = await fetch(desktopApiUrl(`/screenshot-answer/capture-requests/${encodeURIComponent(job.requestId)}/desktop-fail`), {
      method: "POST", signal, headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ deviceId: job.identity.deviceId, manualCode: job.identity.manualCode,
        message: screenshotFailureMessage(isGlobalRelease(), failure.message), stage: failure.stage === "upload" ? "upload-failed" : "capture-failed" }),
    });
    await response.body?.cancel();
    // A cancelled request's terminal 409 is not a new screenshot failure.
  },
  notice: (job, message) => {
    if (isCurrentWrittenJob(job)) mainWindow?.webContents.send("desktop:remote-screenshot-notice", message);
  },
  settled: (job, outcome) => {
    console.info("[written-screenshot]", { outcome: outcome.status, errorCode: outcome.failure?.code ?? null });
    if (isCurrentWrittenJob(job) && outcome.status !== "unconfirmed") scheduleWrittenPendingProbe(job.requestId);
  },
});

const enqueueWrittenScreenshot = (identity: { deviceId: string; manualCode: string }, requestId: string, lockAlreadyHeld: boolean) => {
  // A queued shortcut must not hold the physical lock ahead of earlier FIFO jobs.
  if (lockAlreadyHeld) releaseScreenshotCaptureLock(screenshotCaptureLock.ownerToken());
  const job: WrittenScreenshotJob = { requestId, identity, bindingKey: remoteScreenshotBindingKey!, generation: writtenScreenshotGeneration };
  const result = writtenScreenshotProcessor.enqueue(job);
  if (result.status === "full") {
    void reportRemoteScreenshotFailure(identity, requestId, "截图请求较多，请稍候重试。", "capture-failed");
  }
  return result.completion.then(() => true);
};

const processRemoteScreenshotRequest = async (
  identity: { deviceId: string; manualCode: string },
  requestId: string,
  lockAlreadyHeld = false,
) => {
  if (requestId && screenshotSessionMode === "written" && remoteScreenshotBindingKey) {
    return enqueueWrittenScreenshot(identity, requestId, lockAlreadyHeld);
  }
  if (!requestId || processingRemoteScreenshotRequestId === requestId) return true;
  if (processingRemoteScreenshotRequestId) return true;
  if (!lockAlreadyHeld && !screenshotCaptureLock.tryAcquire()) return true;
  if (!lockAlreadyHeld) publishScreenshotCaptureLock();
  processingRemoteScreenshotRequestId = requestId;
  const owner = screenshotCaptureLock.ownerToken();
  try {
    mainWindow?.webContents.send("desktop:remote-screenshot-notice", "网页端已请求截图回答，本地助手正在截取当前屏幕。");
    const capture = await captureCurrentScreen(null, true);
    if (capture.errorMessage) throw new Error(capture.errorMessage);
    if (!capture.dataUrl) throw new Error("本地助手未获取到有效共享屏幕画面，请检查屏幕捕捉权限。");
    const extension = capture.extension || (capture.contentType === "image/jpeg" ? "jpg" : capture.contentType === "image/webp" ? "webp" : "png");
    const filename = `${(capture.name || "current-screen").replace(/[\\/:*?"<>|]+/g, "-")}.${extension}`;
    const upload = await uploadScreenshotCapture({
      url: desktopApiUrl(`/screenshot-answer/capture-requests/${encodeURIComponent(requestId)}/desktop-upload`),
      deviceId: identity.deviceId,
      manualCode: identity.manualCode,
      dataUrl: capture.dataUrl,
      filename,
    });
    if (!upload.ok) throw new Error(upload.bodyText || `截图上传失败：${upload.status}`);
    mainWindow?.webContents.send("desktop:remote-screenshot-notice", "本地助手已完成截图并回传后端。");
  } catch (error) {
    const message = error instanceof Error ? error.message : "本地助手执行截图回答失败";
    await reportRemoteScreenshotFailure(identity, requestId, message, message.includes("上传") ? "upload-failed" : "capture-failed");
    mainWindow?.webContents.send("desktop:remote-screenshot-notice", `截图失败：${message}`);
  } finally {
    processingRemoteScreenshotRequestId = null;
    if (screenshotCaptureLock.state().locked) releaseScreenshotCaptureLock(owner);
  }
  return true;
};

const pollRemoteScreenshotRequest = async (lockAlreadyHeld = false, excludedRequestId?: string) => {
  const owner = lockAlreadyHeld ? screenshotCaptureLock.ownerToken() : null;
  const expectedKey = remoteScreenshotBindingKey;
  const generation = writtenScreenshotGeneration;
  const wasWritten = screenshotSessionMode === "written";
  if (!pairingIdentityStore || !wasWritten && processingRemoteScreenshotRequestId) return;
  const pollingState = await getDesktopScreenshotPollingState();
  if (!pollingState.live || !pollingState.identity || isQuitting) return false;
  if (wasWritten && (expectedKey !== remoteScreenshotBindingKey || generation !== writtenScreenshotGeneration)) return false;
  if (screenshotCaptureLock.state().locked && !lockAlreadyHeld) return true;
  const identity = pollingState.identity;
  if (wasWritten) {
    const signal = AbortSignal.timeout(5_000);
    const binding = await readWrittenBinding(identity, signal);
    if (!binding || screenshotBindingKey(binding) !== expectedKey) return false;
    const request = await readWrittenRequest(identity, binding, signal);
    if (isQuitting || expectedKey !== remoteScreenshotBindingKey || generation !== writtenScreenshotGeneration) return false;
    if (!request || request.status !== "requested" || request.requestId === excludedRequestId) {
      if (lockAlreadyHeld) releaseScreenshotCaptureLock(owner);
      return true;
    }
    return processRemoteScreenshotRequest(identity, request.requestId, lockAlreadyHeld);
  }
  const response = await fetchWithTimeout(desktopApiUrl(`/screenshot-answer/desktop-devices/${encodeURIComponent(identity.deviceId)}/capture-requests/next?manualCode=${encodeURIComponent(identity.manualCode)}`));
  if (!response.ok) throw new RemoteScreenshotAdmissionError("poll", response.status);
  const envelope = await response.json() as { data?: { requestId: string; status: string } | null };
  const request = envelope.data;
  if (!request || request.status !== "requested") {
    if (lockAlreadyHeld) releaseScreenshotCaptureLock(owner);
    return true;
  }
  return processRemoteScreenshotRequest(identity, request.requestId, lockAlreadyHeld);
};

class RemoteScreenshotAdmissionError extends Error {
  constructor(readonly channel: "stream" | "poll", readonly status: number) {
    super(`remote_screenshot_${channel}_${status}`);
    this.name = "RemoteScreenshotAdmissionError";
  }
}

const shortcutNotice = (message: string) => {
  mainWindow?.webContents.send("desktop:screenshot-shortcut-notice", message);
};

const triggerScreenshotShortcut = async () => {
  const now = Date.now();
  if (screenshotShortcutTriggerInFlight || now - lastScreenshotShortcutTriggerAt < 1500) {
    shortcutNotice("上一笔快捷键截屏仍在处理中，请稍候。");
    return;
  }
  let shortcutOwner: number | null = null;
  screenshotShortcutTriggerInFlight = true;
  lastScreenshotShortcutTriggerAt = now;
  try {
    if (!pairingIdentityStore) throw new Error("助手设备身份尚未初始化。");
    const identity = await pairingIdentityStore.loadOrCreate(`${app.getName()} · ${process.platform === "darwin" ? "Mac" : "Desktop"}`);
    const binding = await getLiveDesktopBinding();
    if (!binding) {
      shortcutNotice("当前没有已连接且正在进行的面试，本次没有截取屏幕。");
      return;
    }
    if (!screenshotCaptureLock.tryAcquire()) {
      shortcutNotice(screenshotCaptureLock.state().message);
      return;
    }
    shortcutOwner = screenshotCaptureLock.ownerToken();
    publishScreenshotCaptureLock();
    const response = await fetchWithTimeout(desktopApiUrl(`/screenshot-answer/desktop-devices/${encodeURIComponent(identity.deviceId)}/shortcut-capture-requests`), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        deviceId: identity.deviceId,
        manualCode: identity.manualCode,
      }),
    });
    if (!response.ok) {
      let message = `快捷键截屏请求失败：${response.status}`;
      try {
        const payload = await response.json() as { error?: { message?: string } };
        if (payload.error?.message) message = payload.error.message;
      } catch {
        // Keep the status-based fallback.
      }
      releaseScreenshotCaptureLock(shortcutOwner);
      throw new Error(message);
    }
    shortcutNotice("快捷键已触发，正在截取当前选择的屏幕。");
    const payload = await response.json() as { data?: { requestId?: string } };
    const requestId = payload.data?.requestId;
    if (!requestId) {
      releaseScreenshotCaptureLock(shortcutOwner);
      throw new Error("快捷键截屏请求缺少任务标识，请稍后重试。");
    }
    await processRemoteScreenshotRequest(identity, requestId, true);
  } catch (error) {
    if (screenshotCaptureLock.state().locked && !processingRemoteScreenshotRequestId) releaseScreenshotCaptureLock(shortcutOwner);
    shortcutNotice(error instanceof Error ? error.message : "快捷键截屏失败，请稍后重试。");
  } finally {
    screenshotShortcutTriggerInFlight = false;
  }
};

const registerScreenshotShortcut = async (accelerator: string) => {
  if (!isSupportedScreenshotShortcut(accelerator)) {
    screenshotShortcutRegistration = { ok: false, accelerator: activeScreenshotShortcut, message: "不支持该快捷键组合，请选择列表中的预设。" };
    return screenshotShortcutRegistration;
  }
  const previous = activeScreenshotShortcut;
  if (previous === accelerator && (!accelerator || globalShortcut.isRegistered(accelerator))) {
    screenshotShortcutRegistration = { ok: true, accelerator, message: accelerator ? "快捷键已在系统中生效。" : "截屏回答快捷键已关闭。" };
    return screenshotShortcutRegistration;
  }
  if (previous) globalShortcut.unregister(previous);
  if (accelerator && !globalShortcut.register(accelerator, () => { void triggerScreenshotShortcut(); })) {
    if (previous) globalShortcut.register(previous, () => { void triggerScreenshotShortcut(); });
    screenshotShortcutRegistration = { ok: false, accelerator: previous, message: "快捷键未生效：该组合已被系统或其他应用占用，请选择其他组合。" };
    return screenshotShortcutRegistration;
  }
  activeScreenshotShortcut = accelerator;
  await screenshotShortcutStore?.save(accelerator);
  screenshotShortcutRegistration = { ok: true, accelerator, message: accelerator ? "快捷键已在系统中生效。" : "截屏回答快捷键已关闭。" };
  return screenshotShortcutRegistration;
};

const consumeRemoteScreenshotEventStream = async (
  identity: { deviceId: string; manualCode: string },
  signal: AbortSignal,
) => {
  const url = desktopApiUrl(`/screenshot-answer/desktop-devices/${encodeURIComponent(identity.deviceId)}/capture-requests/stream?manualCode=${encodeURIComponent(identity.manualCode)}`);
  const response = await fetch(url, { headers: { Accept: "text/event-stream" }, signal });
  if (!response.ok) throw new RemoteScreenshotAdmissionError("stream", response.status);
  if (!response.body) throw new Error("remote_screenshot_stream_body_missing");
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  const parser = new DesktopCaptureEventParser();
  while (!signal.aborted) {
    const { done, value } = await reader.read();
    if (signal.aborted) return;
    if (done) break;
    for (const captureRequest of parser.push(decoder.decode(value, { stream: true }))) {
      void processRemoteScreenshotRequest(identity, captureRequest.requestId);
    }
  }
  if (!signal.aborted) throw new Error("remote_screenshot_stream_closed");
};

const startRemoteScreenshotRequestLoop = () => {
  const generation = ++remoteScreenshotLoopGeneration;
  if (screenshotRequestTimer) clearTimeout(screenshotRequestTimer);
  remoteScreenshotStreamController?.abort();
  remoteScreenshotStreamController = null;
  remoteScreenshotPollFailureCount = 0;
  remoteScreenshotSuspended = false;
  const schedule = (delayMs: number) => {
    if (generation !== remoteScreenshotLoopGeneration || isQuitting) return;
    screenshotRequestTimer = setTimeout(() => void run(), delayMs);
  };
  const run = async () => {
    if (generation !== remoteScreenshotLoopGeneration || isQuitting) return;
    if (remoteScreenshotPollOwner === generation) {
      schedule(50);
      return;
    }
    remoteScreenshotPollOwner = generation;
    let streamController: AbortController | null = null;
    try {
      const state = await getDesktopScreenshotPollingState();
      if (generation !== remoteScreenshotLoopGeneration || isQuitting) return;
      if (!state.live || !state.identity) {
        remoteScreenshotPollFailureCount = 0;
        schedule(desktopPollDelayMs("idle"));
        return;
      }
      streamController = new AbortController();
      remoteScreenshotStreamController = streamController;
      remoteScreenshotPollFailureCount = 0;
      await consumeRemoteScreenshotEventStream(state.identity, streamController.signal);
    } catch (error) {
      if (isQuitting || generation !== remoteScreenshotLoopGeneration) return;
      if (streamController?.signal.aborted) {
        schedule(0);
        return;
      }
      if (screenshotStreamAdmissionAction(error instanceof RemoteScreenshotAdmissionError ? error.status : null) === "suspend") {
        remoteScreenshotSuspended = true;
        console.info("[remote-screenshot] suspended until binding eligibility changes", {
          status: error instanceof RemoteScreenshotAdmissionError ? error.status : null,
        });
        return;
      }
      console.warn("[remote-screenshot] poll failed", error);
      remoteScreenshotPollFailureCount += 1;
      try {
        await pollRemoteScreenshotRequest();
      } catch (fallbackError) {
        if (generation !== remoteScreenshotLoopGeneration || isQuitting) return;
        if (screenshotStreamAdmissionAction(fallbackError instanceof RemoteScreenshotAdmissionError ? fallbackError.status : null) === "suspend") {
          remoteScreenshotSuspended = true;
          console.info("[remote-screenshot] fallback suspended until binding eligibility changes", {
            status: fallbackError instanceof RemoteScreenshotAdmissionError ? fallbackError.status : null,
          });
          return;
        }
        console.warn("[remote-screenshot] fallback poll failed", fallbackError);
      }
      schedule(desktopPollDelayMs("failure", remoteScreenshotPollFailureCount));
    } finally {
      if (remoteScreenshotStreamController === streamController) remoteScreenshotStreamController = null;
      if (remoteScreenshotPollOwner === generation) remoteScreenshotPollOwner = null;
    }
  };
  void run();
};

const stopRemoteScreenshotRequestLoop = () => {
  remoteScreenshotLoopGeneration += 1;
  if (screenshotRequestTimer) {
    clearTimeout(screenshotRequestTimer);
    screenshotRequestTimer = null;
  }
  remoteScreenshotStreamController?.abort();
  remoteScreenshotStreamController = null;
  remoteScreenshotPollFailureCount = 0;
  remoteScreenshotSuspended = false;
};

const createWindow = () => {
  const window = new BrowserWindow({
    width: 780,
    height: 540,
    minWidth: 700,
    minHeight: 500,
    title: desktopCopy("面试稳伴随程序", "OfferSteady Companion"),
    backgroundColor: "#080d18",
    show: false,
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      // The companion is normally behind the interview browser. Realtime
      // binding polls and audio callbacks must not be clamped to background
      // renderer timer intervals when this window loses focus.
      backgroundThrottling: false,
    },
  });
  if (floatingPreviewBuild && process.platform === "darwin") requestWindowCaptureProtection(window);
  mainWindow = window;
  window.on("focus", () => desktopConnectionRecovery.recover("focus"));

  window.removeMenu();
  void window.loadFile(path.join(__dirname, "../renderer/index.html"));
  window.once("ready-to-show", () => {
    if (rendererRecoveryResetTimer) clearTimeout(rendererRecoveryResetTimer);
    rendererRecoveryResetTimer = setTimeout(() => {
      rendererRecoveryAttempts = [];
      rendererRecoveryResetTimer = null;
    }, 60_000);
    if (mainWindow === window && !window.isDestroyed()) {
      windowVisibility.showOnReady(() => window.show());
      if (windowVisibility.isHidden() && process.platform === "win32") window.setSkipTaskbar(true);
    }
  });
  window.webContents.on("did-finish-load", () => {
    if (rendererRecoveryContext && !window.isDestroyed()) {
      window.webContents.send("desktop:renderer-recovery-requested", rendererRecoveryContext);
    }
  });
  window.on("close", (event) => {
    if (!isQuitting) {
      event.preventDefault();
      window.hide();
    }
  });
  window.on("closed", () => {
    if (mainWindow === window) mainWindow = null;
  });
  window.webContents.on("render-process-gone", (_event, details) => {
    if (isQuitting || details.reason === "clean-exit") return;
    if (rendererRecoveryResetTimer) {
      clearTimeout(rendererRecoveryResetTimer);
      rendererRecoveryResetTimer = null;
    }
    const decision = decideRendererRecovery(rendererRecoveryAttempts, Date.now());
    rendererRecoveryAttempts = decision.attempts;
    console.error("[desktop-renderer] renderer process exited", {
      reason: details.reason,
      exitCode: details.exitCode,
      recoveryAllowed: decision.allowed,
      recoveryAttemptCount: decision.attempts.length,
      sessionId: latestRendererHeartbeat?.sessionId ?? null,
      memory: latestRendererProcessMetrics,
      reliability: latestRendererHeartbeat,
    });
    rendererRecoveryContext = {
      crashAtMs: Date.now(),
      reason: details.reason,
      exitCode: details.exitCode,
      sessionId: latestRendererHeartbeat?.sessionId ?? null,
      desiredCapture: latestRendererHeartbeat?.desiredCapture === true,
      recoveryAttempt: decision.attempts.length,
    };
    if (mainWindow === window) mainWindow = null;
    if (!window.isDestroyed()) window.destroy();
    if (!decision.allowed) {
      console.error("[desktop-renderer] recovery limit reached; automatic recreation stopped");
      return;
    }
    setTimeout(() => {
      if (!isQuitting && !mainWindow) createWindow();
    }, 250);
  });
};

const ownsCompanionInstance = app.requestSingleInstanceLock({
  productEdition: isGlobalRelease() ? "global" : "domestic",
  userDataDirectory: stableCompanionUserDataDirectory,
});

if (!ownsCompanionInstance) app.quit();
else {
  app.on("second-instance", () => {
    if (!isQuitting && app.isReady()) windowVisibility.restore();
  });

  void app.whenReady().then(async () => {
  try {
    const migration = await migrateLegacyCompanionState({
      stableDirectory: stableCompanionUserDataDirectory,
      legacyDirectories: companionLegacyUserDataDirectories,
    });
    if (migration.copiedFiles.length > 0) {
      console.info("[desktop-user-data] migrated allowlisted local state", {
        copiedFiles: migration.copiedFiles,
      });
    }
  } catch (error) {
    console.warn("[desktop-user-data] legacy state migration failed; stable directory remains active", error);
  }
  powerMonitor.on("resume", () => desktopConnectionRecovery.recover("resume"));
  powerMonitor.on("suspend", () => writtenAwake.refresh(false));
  captureState = "not-connected";
  credentialVault = new DeviceCredentialVault(app.getPath("userData"), safeStorage);
  pairingIdentityStore = new DevicePairingIdentityStore(app.getPath("userData"));
  screenshotShortcutStore = new ScreenshotShortcutStore(app.getPath("userData"));
  realtimeTransportDiagnosticsLog = new RealtimeTransportDiagnosticsLog(app.getPath("userData"));
  session.defaultSession.setPermissionRequestHandler((_webContents, permission, callback) => {
    callback(allowedRuntimePermissions.has(permission));
  });
  session.defaultSession.setPermissionCheckHandler((_webContents, permission) => allowedRuntimePermissions.has(permission));
  session.defaultSession.setDisplayMediaRequestHandler((request, callback) => {
    const rejectDisplayRequest = (reason: string) => {
      try {
        callback({});
      } catch (error) {
        console.warn("[desktop-capture] display media request rejected", { reason, error });
      }
    };
    if (Date.now() < displayMediaFailureBackoffUntil) {
      rejectDisplayRequest("source-backoff");
      return;
    }
    const permissionStatus = process.platform === "darwin"
      ? systemPreferences.getMediaAccessStatus("screen") as ScreenPermissionStatus
      : "granted";
    void resolveDisplayMediaSource({
      platform: process.platform,
      permissionStatus,
      getSources: () => desktopCapturer.getSources({
          types: ["screen"],
          thumbnailSize: { width: 0, height: 0 },
      }),
      preferredSourceId: preferredScreenSourceId,
      sourceId: source => source.id,
    }).then((resolution) => {
      if (resolution.kind === "permission-required") {
        displayMediaFailureBackoffUntil = Number.POSITIVE_INFINITY;
        rejectDisplayRequest("screen-capture-permission-required");
        return;
      }
      if (resolution.kind === "unavailable") {
        displayMediaFailureBackoffUntil = Date.now() + 5_000;
        console.warn("[desktop-capture] display media source unavailable", resolution.error);
        rejectDisplayRequest("display-source-unavailable");
        return;
      }
      try {
        const selectedScreen = resolution.source;
        callback({
          ...(request.videoRequested ? { video: selectedScreen } : {}),
          ...(request.audioRequested ? { audio: "loopback" } : {}),
        });
      } catch (error) {
        console.warn("[desktop-capture] display media callback failed", error);
      }
    }).catch((error) => {
      displayMediaFailureBackoffUntil = Date.now() + 5_000;
      console.warn("[desktop-capture] unexpected display media resolution failure", error);
      rejectDisplayRequest("unexpected-display-source-failure");
    });
  }, { useSystemPicker: false });
  if (floatingPreviewBuild) {
    initializeFloatingInterview(undefined, async () => (await pairingIdentityStore?.load())?.manualCode ?? null);
  }
  ensureTray();
  createWindow();
  try {
    restoreShortcutRegistered = globalShortcut.register(RESTORE_WINDOW_SHORTCUT, () => windowVisibility.restore());
  } catch {
    restoreShortcutRegistered = false;
  }
  startDesktopRegistrationLoop();
  startRemoteScreenshotRequestLoop();
  void screenshotShortcutStore.load()
    .then(accelerator => registerScreenshotShortcut(accelerator))
    .then(result => shortcutNotice(result.message));

  app.on("activate", () => {
    if (!isQuitting) windowVisibility.restore();
    if (screenshotSessionMode === "written") desktopConnectionRecovery.recover("focus");
    else if (remoteScreenshotSuspended && screenshotStreamEligible(captureState)) startRemoteScreenshotRequestLoop();
  });
  });
}

ipcMain.on("capture:set-state", (event, state: CaptureState) => {
  if (event.sender !== mainWindow?.webContents) return;
  const previousState = captureState;
  captureState = state;
  updateTray();
  const transition = screenshotStreamTransition(previousState, state);
  const suspendedTransition = remoteScreenshotSuspended
    ? screenshotStreamSuspensionTransition(previousState, state)
    : "preserve";
  if (transition === "stop") {
    ++writtenScreenshotGeneration;
    writtenScreenshotProcessor.cancelAll();
    writtenAwake.refresh(false);
  }
  if (transition === "start" || suspendedTransition === "resume") startRemoteScreenshotRequestLoop();
  else if (transition === "stop") stopRemoteScreenshotRequestLoop();
});

ipcMain.on("desktop:screenshot-binding", (event, binding: { sessionId?: unknown; bindingId?: unknown; sessionMode?: unknown } | null) => {
  if (event.sender !== mainWindow?.webContents) return;
  const normalizedBinding = binding
    && typeof binding.sessionId === "string"
    && typeof binding.bindingId === "string"
    ? { sessionId: binding.sessionId, bindingId: binding.bindingId }
    : null;
  const nextBindingKey = screenshotBindingKey(normalizedBinding);
  const transition = screenshotBindingTransition(remoteScreenshotBindingKey, nextBindingKey, remoteScreenshotSuspended);
  const nextMode = normalizedBinding && typeof binding?.sessionMode === "string" ? binding.sessionMode : null;
  if (nextBindingKey !== remoteScreenshotBindingKey || nextMode !== screenshotSessionMode) {
    ++writtenScreenshotGeneration;
    writtenScreenshotProcessor.cancelAll();
  }
  screenshotSessionMode = nextMode;
  remoteScreenshotBindingKey = nextBindingKey;
  writtenAwake.refresh(screenshotSessionMode === "written" && Boolean(nextBindingKey)
    && screenshotStreamEligible(captureState) && desktopConnectionRecovery.snapshot().online);
  if (transition === "stop") stopRemoteScreenshotRequestLoop();
  else if (transition === "restart" && screenshotStreamEligible(captureState)) startRemoteScreenshotRequestLoop();
});

ipcMain.on("desktop:connection-recovery", (event) => {
  if (event.sender === mainWindow?.webContents) desktopConnectionRecovery.recover("online");
});

ipcMain.on("desktop:renderer-reliability-heartbeat", (event, heartbeat: RendererReliabilityHeartbeat) => {
  latestRendererHeartbeat = heartbeat;
  const ownerWindow = BrowserWindow.fromWebContents(event.sender);
  if (ownerWindow && !ownerWindow.isDestroyed()) {
    latestRendererProcessMetrics = currentRendererProcessMetrics(ownerWindow);
    recordRendererReliabilityMilestone(ownerWindow, heartbeat);
  }
});

ipcMain.on("desktop:realtime-transport-diagnostics", (_event, snapshot: Record<string, unknown>) => {
  console.info("[realtime-audio-transport-diagnostics]", snapshot);
  realtimeTransportDiagnosticsLog?.append(snapshot);
});

ipcMain.handle("desktop:get-realtime-transport-diagnostics-path", async () => realtimeTransportDiagnosticsLog?.path ?? null);

ipcMain.handle("desktop:get-renderer-recovery-context", async () => rendererRecoveryContext);
ipcMain.handle("desktop:get-renderer-reliability-diagnostics", async () => ({
  latest: latestRendererHeartbeat,
  samples: rendererReliabilitySamples,
  recovery: rendererRecoveryContext,
}));
ipcMain.on("desktop:renderer-recovery-complete", (_event, input: { readonly sessionId: string; readonly ackAtMs: number }) => {
  if (!rendererRecoveryContext || rendererRecoveryContext.sessionId !== input.sessionId || input.ackAtMs < rendererRecoveryContext.crashAtMs) return;
  console.info("[desktop-renderer] realtime recovery confirmed by fresh frame acknowledgement", {
    sessionId: input.sessionId,
    recoveryMs: input.ackAtMs - rendererRecoveryContext.crashAtMs,
  });
  rendererRecoveryContext = null;
});

ipcMain.on("app:close", () => {
  captureState = "not-connected";
  stopNativeAudioStreams();
  app.quit();
});

ipcMain.handle("credential:save", async (_event, credential: string) => {
  await credentialVault?.save(credential);
});

ipcMain.handle("credential:clear", async () => {
  await credentialVault?.clear();
});

ipcMain.handle("desktop:get-config", async () => desktopConfig());
ipcMain.handle("desktop:get-window-visibility", () => ({
  hidden: windowVisibility.isHidden(),
  restoreShortcut: restoreShortcutRegistered ? RESTORE_WINDOW_SHORTCUT : null,
}));
ipcMain.handle("desktop:hide-window", event => {
  if (event.sender !== mainWindow?.webContents || isQuitting) return { hidden: false, restoreShortcut: null };
  try {
    windowVisibility.hide();
  } catch {
    windowVisibility.restore();
  }
  return { hidden: windowVisibility.isHidden(), restoreShortcut: restoreShortcutRegistered ? RESTORE_WINDOW_SHORTCUT : null };
});
ipcMain.handle("desktop:get-native-runtime-health", async () => getNativeRuntimeHealth());
ipcMain.handle("desktop:get-screenshot-shortcut", async () => {
  const configuredAccelerator = activeScreenshotShortcut || await screenshotShortcutStore?.load() || DEFAULT_SCREENSHOT_SHORTCUT;
  const registration = await registerScreenshotShortcut(configuredAccelerator);
  return {
    accelerator: registration.accelerator,
    options: SCREENSHOT_SHORTCUT_OPTIONS,
    registered: registration.ok && Boolean(registration.accelerator) && globalShortcut.isRegistered(registration.accelerator),
    message: registration.message,
  };
});
ipcMain.handle("desktop:set-screenshot-shortcut", async (_event, accelerator: string) => registerScreenshotShortcut(accelerator));
ipcMain.handle("desktop:get-screenshot-capture-lock", async () => screenshotCaptureLock.state());

ipcMain.handle("desktop:get-pairing-identity", async () => {
  if (!pairingIdentityStore) pairingIdentityStore = new DevicePairingIdentityStore(app.getPath("userData"));
  return pairingIdentityStore.loadOrCreate(`${app.getName()} · ${process.platform === "darwin" ? "Mac" : process.platform === "win32" ? "Windows" : "Desktop"}`);
});

ipcMain.handle("desktop:reset-pairing-identity", async () => {
  if (!pairingIdentityStore) pairingIdentityStore = new DevicePairingIdentityStore(app.getPath("userData"));
  await pairingIdentityStore.reset();
  hasRegisteredThisRun = false;
  return true;
});

ipcMain.handle("desktop:list-screens", async () => {
  const permissionStatus = process.platform === "darwin"
    ? systemPreferences.getMediaAccessStatus("screen") as ScreenPermissionStatus
    : "granted";
  if (!canAcquireDisplaySources(process.platform, permissionStatus)) return [];
  try {
    const sources = await desktopCapturer.getSources({
      types: ["screen"],
      thumbnailSize: floatingPreviewBuild && process.platform === "darwin" ? { width: 0, height: 0 } : { width: 1280, height: 720 },
    });
    return sources.map((source, index) => ({
      id: source.id,
      label: source.name || `显示器 ${index + 1}`,
      thumbnailDataUrl: source.thumbnail.isEmpty() ? null : source.thumbnail.toDataURL(),
    }));
  } catch {
    return [];
  }
});

ipcMain.handle("desktop:set-preferred-screen", async (_event, screenSourceId: string | null) => {
  preferredScreenSourceId = screenSourceId;
  return { ok: true };
});

ipcMain.handle("desktop:capture-current-screen", async (_event, screenSourceId: string | null) => {
  return captureCurrentScreen(screenSourceId, false, true);
});

ipcMain.handle("desktop:upload-screenshot-capture", async (_event, request: {
  url: string;
  deviceId: string;
  manualCode: string;
  dataUrl: string;
  filename: string;
}) => {
  return uploadScreenshotCapture(request);
});

ipcMain.handle("desktop:open-external", async (_event, url: string) => {
  await shell.openExternal(url);
});

ipcMain.handle("desktop:probe-web-url", async (_event, url: string) => probeWebUrl(url));

ipcMain.handle("desktop:api-request", async (_event, request: { url: string; method?: string; headers?: Record<string, string>; body?: string | null }) => {
  const url = assertOfferSteadyApiUrl(request.url);
  const method = (request.method ?? "GET").toUpperCase();
  const isAudioFrame = new URL(url).pathname.endsWith("/realtime-speech/frames");
  const canCoalesce = !isAudioFrame && (method === "GET"
    || url.includes("/desktop-devices/register")
    || url.includes("/desktop-devices/") && url.includes("/heartbeat")
    || url.includes("/device-status"));
  const requestKey = canCoalesce ? `${method}:${url}:${request.body ?? ""}` : null;
  if (requestKey) {
    const pending = desktopApiRequestsInFlight.get(requestKey);
    if (pending) return pending;
  }
  const execute = async (): Promise<DesktopApiRequestResult> => {
    const response = await fetchWithTimeout(url, {
      method,
      headers: request.headers,
      body: request.body ?? undefined,
    }, isAudioFrame ? DESKTOP_AUDIO_REQUEST_TIMEOUT_MS : DESKTOP_CONTROL_REQUEST_TIMEOUT_MS);
    if (response.ok && method === "POST" && request.body
      && (new URL(url).pathname.endsWith("/desktop-devices/register") || new URL(url).pathname.endsWith("/device-status"))) {
      try {
        const report = JSON.parse(request.body) as { deviceId?: unknown; capabilities?: unknown };
        if (typeof report.deviceId === "string" && report.capabilities && typeof report.capabilities === "object" && !Array.isArray(report.capabilities)) {
          desktopCapabilitySnapshot.remember(report.deviceId, report.capabilities as Record<string, unknown>);
        }
      } catch {
        // A malformed body cannot change the last successful capability snapshot.
      }
    }
    return {
      ok: response.ok,
      status: response.status,
      statusText: response.statusText,
      headers: Object.fromEntries(response.headers.entries()),
      bodyText: await response.text(),
    };
  };
  const promise = execute();
  if (!requestKey) return promise;
  desktopApiRequestsInFlight.set(requestKey, promise);
  try {
    return await promise;
  } finally {
    if (desktopApiRequestsInFlight.get(requestKey) === promise) desktopApiRequestsInFlight.delete(requestKey);
  }
});

ipcMain.handle("desktop:get-microphone-permission", () => microphonePermission.snapshot());
ipcMain.handle("desktop:request-microphone-permission", () => microphonePermission.request());
ipcMain.handle("desktop:request-microphone-access", async () => (await microphonePermission.request()).permission === "granted");

ipcMain.handle("desktop:request-screen-capture-access", async () => requestElectronScreenCaptureAccess());

ipcMain.handle("desktop:open-permission-settings", async (_event, kind: "microphone" | "screen" | "camera" | "audio") => {
  await shell.openExternal(permissionSettingsUrl(kind));
});

app.on("window-all-closed", () => {
  // The tray remains the persistent, visible control surface.
});

app.on("before-quit", () => {
  isQuitting = true;
  windowVisibility.dispose();
  rendererRecoveryContext = null;
  if (rendererRecoveryResetTimer) {
    clearTimeout(rendererRecoveryResetTimer);
    rendererRecoveryResetTimer = null;
  }
  captureState = "not-connected";
  screenshotCaptureLock.release();
  desktopConnectionRecovery.dispose();
  writtenAwake.dispose();
  writtenScreenshotProcessor.cancelAll();
  if (screenshotRequestTimer) {
    clearTimeout(screenshotRequestTimer);
    screenshotRequestTimer = null;
  }
  remoteScreenshotStreamController?.abort();
  remoteScreenshotStreamController = null;
  if (realtimeAudioInterval) {
    clearInterval(realtimeAudioInterval);
    realtimeAudioInterval = null;
  }
  abortPendingDesktopRequests();
  stopMainRealtimeAudioPublishing();
  globalShortcut.unregisterAll();
});
