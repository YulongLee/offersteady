import "./window-api";
import "./online-shell.css";
import type { FloatingWindowState } from "./window-api";

const transparency = document.querySelector<HTMLInputElement>("#transparency")!;
const transparencyValue = document.querySelector<HTMLOutputElement>("#transparency-value")!;
const retry = document.querySelector<HTMLButtonElement>("#retry")!;
const tuckAway = document.querySelector<HTMLButtonElement>("#tuck-away")!;
const title = document.querySelector<HTMLElement>("#status-title")!;
const detail = document.querySelector<HTMLElement>("#status-detail")!;
const protection = document.querySelector<HTMLElement>("#protection")!;
const host = document.querySelector<HTMLElement>("#host")!;

const protectionLabels: Record<FloatingWindowState["protection"], string> = {
  requested: "Capture protection requested. Verify on a receiving device.",
  unavailable: "Capture protection unavailable.",
  unsupported: "Full-screen sharing may include this window.",
};

function render(state: FloatingWindowState) {
  transparency.value = String(state.transparency);
  transparencyValue.value = `${state.transparency}%`;
  transparency.disabled = false;
  host.textContent = state.host;
  tuckAway.hidden = !state.canTuckAway;
  protection.textContent = protectionLabels[state.protection];
  const failed = state.status === "failed";
  title.textContent = failed ? "Could not open OfferSteady" : "Connecting to OfferSteady";
  detail.textContent = failed ? "Check your connection and try again." : "Sign in to open your interview in this window.";
  retry.hidden = !failed;
}

const unsubscribe = window.floatingPreview.onStatus(render);
window.addEventListener("pagehide", unsubscribe, { once: true });
void window.floatingPreview.state().then(render).catch(() => {
  title.textContent = "Could not read the window status";
});

transparency.addEventListener("input", () => {
  transparencyValue.value = `${transparency.value}%`;
});

transparency.addEventListener("change", async () => {
  const percentage = transparency.valueAsNumber;
  transparency.disabled = true;
  try {
    render(await window.floatingPreview.setTransparency(percentage));
  } catch {
    const state = await window.floatingPreview.state().catch(() => undefined);
    if (state) render(state);
    protection.textContent = "Could not adjust transparency. Try again.";
    transparency.disabled = false;
  }
});

retry.addEventListener("click", () => {
  void window.floatingPreview.retry().catch(() => {
    detail.textContent = "Could not reconnect. Close the window and try again.";
  });
});

tuckAway.addEventListener("click", () => {
  void window.floatingPreview.tuckAway().catch(() => {
    protection.textContent = "Could not hide the window. Try again.";
  });
});
