import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
import { cpSync, existsSync, mkdirSync, mkdtempSync, readFileSync, readdirSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { basename, join, resolve } from "node:path";
import * as asar from "@electron/asar";
import * as resedit from "resedit";

const desktop = resolve(import.meta.dirname, "..");
const repo = resolve(desktop, "../..");
const version = JSON.parse(readFileSync(join(desktop, "package.json"))).version;
const [source, sevenZip] = process.argv.slice(2).map(value => resolve(value));
const manifest = JSON.parse(readFileSync(join(repo, "docs/releases/global-performance-companion-1.3.6-20261102/desktop-release-manifest.json")));
const baseline = manifest.entries.find(entry => entry.fileName === basename(source));
const sha = bytes => createHash("sha256").update(bytes).digest("hex");
assert.ok(baseline && sha(readFileSync(source)) === baseline.sha256, "Global source must match the released installer");
assert.equal(version, "2.0.0");

const output = join(desktop, "release/global");
const mac = baseline.platform === "macos";
const macArtifact = join(output, `OfferSteady-Companion-Global-${version}-macOS-${baseline.architecture}.dmg`);
if (mac) assert.ok(!existsSync(macArtifact), "A Global DMG already exists for this architecture");
const scratch = mkdtempSync(join(tmpdir(), "offersteady-global-floating-"));
const globalId = "com.offersteady.companion.global";
const identity = "Developer ID Application: Yulong li (8Y5FAR3TF3)";
const product = "OfferSteady Companion Global";
const command = (program, args, options = {}) => {
  const result = spawnSync(program, args, { encoding: "utf8", cwd: desktop, ...options });
  if (result.status !== 0) throw new Error(`${program} failed: ${result.stderr || result.stdout || result.error}`);
  return result.stdout?.trim() ?? "";
};

function runtime(resources) {
  const configuration = JSON.parse(readFileSync(join(resources, "global-runtime-config.json")));
  assert.equal(configuration.productEdition, "global");
  assert.equal(configuration.releaseChannel, "global");
  assert.equal(configuration.apiBaseUrl, "https://offersteady.com/api/v1");
  assert.equal(configuration.webWorkspaceUrl, "https://offersteady.com/app");
  assert.ok(!existsSync(join(resources, "local-test-runtime.json")));
}

async function updateResources(resources) {
  runtime(resources);
  const archive = join(resources, "app.asar");
  const app = join(scratch, "app-input");
  assert.ok(asar.listPackage(archive, { isPack: true }).every(entry => !entry.startsWith("unpack")));
  asar.extractAll(archive, app);
  const changes = new Set(["dist/main/index.js", "package.json"]);
  const originals = new Map();
  for (const entry of readdirSync(app, { withFileTypes: true, recursive: true })) {
    if (!entry.isFile()) continue;
    const absolute = join(entry.parentPath, entry.name);
    const relative = absolute.slice(app.length + 1);
    if (!changes.has(relative)) originals.set(relative, sha(readFileSync(absolute)));
  }
  const main = join(app, "dist/main/index.js");
  assert.equal(sha(readFileSync(main)), "2b1e666f9b05b8669f82e1521f4728b86e326b3401596893a10ef56208661d3d");
  const metadataFile = join(app, "package.json");
  const metadata = JSON.parse(readFileSync(metadataFile));
  assert.equal(metadata.version, "1.3.6");
  assert.equal(metadata.main, "dist/main/index.js");
  writeFileSync(metadataFile, JSON.stringify({ ...metadata, version }, null, 2) + "\n");

  const dist = join(desktop, "dist");
  for (const name of ["index", "floating-interview", "floating-preview-preload", "floating-screen-capture"]) {
    cpSync(join(dist, "main", name + ".js"), join(app, "dist/main", name + ".js"));
  }
  cpSync(join(dist, "floating-preview"), join(app, "dist/floating-preview"), { recursive: true });
  await asar.createPackage(app, archive);
  asar.uncache(archive);
  for (const [name, hash] of originals) assert.equal(sha(asar.extractFile(archive, name)), hash, name);
  console.log(`Preserved ${originals.size} Global app files byte-for-byte`);
}

function notarize(file, stapleTarget) {
  const args = ["notarytool", "submit", file, "--keychain-profile", "OfferSteady-Notary", "--wait", "--timeout", "15m", "--output-format", "json"];
  let result = spawnSync("xcrun", args, { encoding: "utf8" });
  if (result.status !== 0 && /abortedUpload.*connectTimeout/s.test(result.stderr ?? "")) {
    result = spawnSync("xcrun", [...args, "--no-s3-acceleration"], { encoding: "utf8" });
  }
  assert.equal(result.status, 0, `Apple notarization could not finish for ${basename(file)}`);
  const proof = JSON.parse(result.stdout);
  assert.equal(proof.status, "Accepted", `Apple notarization ${proof.id}`);
  command("xcrun", ["stapler", "staple", stapleTarget]);
  console.log(`Apple notarization accepted ${basename(file)} (${proof.id})`);
}

function requirement(app) {
  const result = spawnSync("codesign", ["-d", "-r-", app], { encoding: "utf8" });
  assert.equal(result.status, 0);
  const value = (result.stdout + result.stderr).match(/^designated => (.+)$/m)?.[1];
  assert.ok(value);
  return value;
}

function windowsVersion(file) {
  const executable = resedit.NtExecutable.from(readFileSync(file));
  const resources = resedit.NtExecutableResource.from(executable);
  const versions = resedit.Resource.VersionInfo.fromEntries(resources.entries);
  assert.equal(versions.length, 1);
  const info = versions[0];
  const [major, minor, patch] = version.split(".").map(Number);
  info.setFileVersion(major, minor, patch, 0, 1033);
  info.setProductVersion(major, minor, patch, 0, 1033);
  info.outputToResourceEntries(resources.entries);
  resources.outputResource(executable);
  writeFileSync(file, Buffer.from(executable.generate()));
}

try {
  mkdirSync(output, { recursive: true });
  if (mac) {
    const root = join(scratch, "dmg-root");
    const mount = join(scratch, "source");
    mkdirSync(root);
    mkdirSync(mount);
    const app = join(root, `${product}.app`);
    command("hdiutil", ["attach", source, "-readonly", "-nobrowse", "-mountpoint", mount]);
    try {
      command("ditto", [join(mount, basename(app)), app]);
    } finally {
      command("hdiutil", ["detach", mount]);
    }
    const resources = join(app, "Contents/Resources");
    const plist = join(app, "Contents/Info.plist");
    const oldRequirement = requirement(app);
    assert.equal(command("plutil", ["-extract", "CFBundleIdentifier", "raw", "-o", "-", plist]), globalId);
    for (const key of ["CFBundleShortVersionString", "CFBundleVersion"]) {
      command("/usr/libexec/PlistBuddy", ["-c", `Set :${key} ${version}`, plist]);
    }
    await updateResources(resources);
    const arch = baseline.architecture === "x64" ? "x86_64" : "arm64";
    const helper = join(resources, "app/native/macos-capture/OfferSteadyFilteredScreenshot");
    command("swiftc", [join(desktop, "native/macos-capture/OfferSteadyFilteredScreenshot.swift"), "-target",
      `${arch}-apple-macos14.2`, "-parse-as-library", "-O", "-o", helper]);
    assert.equal(command("lipo", ["-archs", helper]), arch);
    command("codesign", ["--force", "--sign", identity, "--timestamp", "--options", "runtime", "--identifier", `${globalId}.filtered-screenshot`, helper]);
    command("codesign", ["--force", "--sign", identity, "--timestamp", "--options", "runtime", "--preserve-metadata=identifier,requirements,entitlements", app]);
    assert.equal(requirement(app), oldRequirement);
    command("codesign", ["--verify", "--deep", "--strict", app]);
    const submission = join(scratch, `OfferSteady-Global-${baseline.architecture}.zip`);
    command("ditto", ["-c", "-k", "--keepParent", app, submission]);
    notarize(submission, app);
    rmSync(submission);
    const file = macArtifact;
    assert.ok(!existsSync(file));
    command("hdiutil", ["create", "-srcfolder", root, "-volname", `${product} ${version}`, "-format", "UDZO", file]);
    command("codesign", ["--force", "--sign", identity, "--timestamp", file]);
    notarize(file, file);
    command(process.execPath, [join(desktop, "scripts/generate-global-release-metadata.mjs"), "macos", baseline.architecture, file, app], { stdio: "inherit" });
  } else {
    const root = join(scratch, "win-unpacked");
    command(sevenZip, ["e", "-y", `-o${scratch}`, source, "$PLUGINSDIR/app-64.7z"]);
    const payload = join(scratch, "app-64.7z");
    command(sevenZip, ["x", "-y", `-o${root}`, payload]);
    rmSync(payload);
    await updateResources(join(root, "resources"));
    windowsVersion(join(root, "OfferSteadyGlobal.exe"));
    const file = join(output, `OfferSteady-Companion-Global-Setup-${version}-Windows-x64.exe`);
    assert.ok(!existsSync(file));
    command(process.execPath, [join(repo, "node_modules/electron-builder/out/cli/cli.js"), "--prepackaged", root, "--win", "nsis", "--x64",
      "--config", "electron-builder.global.yml", "--config.win.signAndEditExecutable=false"], {
      env: { ...process.env, CSC_IDENTITY_AUTO_DISCOVERY: "false" }, stdio: "inherit",
    });
    const unpacked = join(scratch, "verified-win");
    command(sevenZip, ["e", "-y", `-o${scratch}`, file, "$PLUGINSDIR/app-64.7z"]);
    command(sevenZip, ["x", "-y", `-o${unpacked}`, payload]);
    for (const entry of readdirSync(root, { withFileTypes: true, recursive: true })) {
      if (!entry.isFile()) continue;
      const sourceFile = join(entry.parentPath, entry.name);
      assert.equal(sha(readFileSync(sourceFile)), sha(readFileSync(join(unpacked, sourceFile.slice(root.length + 1)))));
    }
    const executable = readFileSync(join(unpacked, "OfferSteadyGlobal.exe"));
    const pe = executable.readUInt32LE(0x3c);
    assert.equal(executable.readUInt16LE(pe + 4), 0x8664);
    command(process.execPath, [join(desktop, "scripts/generate-global-release-metadata.mjs"), "windows", "x64", file], { stdio: "inherit" });
  }
} finally {
  rmSync(scratch, { recursive: true, force: true });
}
