import { cpSync, existsSync, mkdirSync, rmSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const scriptDir = dirname(fileURLToPath(import.meta.url));
const desktopDir = resolve(scriptDir, "..");
const targetArch = process.argv[2] || process.arch;
const source = join(desktopDir, "native/macos-capture/OfferSteadyCaptureRuntime.swift");
const infoPlist = join(desktopDir, process.env.OFFERSTEADY_PRODUCT_EDITION === "global"
  ? "native/macos-capture/Info.global.plist"
  : "native/macos-capture/Info.plist");
const buildDir = join(desktopDir, "native/macos-capture/build");
const output = join(buildDir, "OfferSteadyCaptureRuntime");
const distDir = join(desktopDir, "dist/native/macos-capture");
const minimumSystemVersion = process.env.OFFERSTEADY_MACOS_MIN_VERSION?.trim() || "14.2";

if (!/^\d+\.\d+(?:\.\d+)?$/.test(minimumSystemVersion)) {
  throw new Error(`Invalid OFFERSTEADY_MACOS_MIN_VERSION: ${minimumSystemVersion}`);
}

if (process.platform !== "darwin") {
  console.log("Skipping macOS native capture runtime build on non-macOS host.");
  process.exit(0);
}

if (targetArch !== "arm64" && targetArch !== "x64") {
  throw new Error(`Unsupported macOS native runtime architecture: ${targetArch}`);
}

if (!existsSync(source)) {
  throw new Error(`Native runtime source not found: ${source}`);
}
if (!existsSync(infoPlist)) {
  throw new Error(`Native runtime Info.plist not found: ${infoPlist}`);
}

rmSync(buildDir, { recursive: true, force: true });
mkdirSync(buildDir, { recursive: true });

const result = spawnSync("swiftc", [
  source,
  "-target", `${targetArch === "x64" ? "x86_64" : "arm64"}-apple-macos${minimumSystemVersion}`,
  "-O",
  "-framework", "AVFoundation",
  "-framework", "CoreGraphics",
  "-framework", "ScreenCaptureKit",
  "-Xlinker", "-sectcreate",
  "-Xlinker", "__TEXT",
  "-Xlinker", "__info_plist",
  "-Xlinker", infoPlist,
  "-o", output,
], { encoding: "utf8" });

if (result.status !== 0) {
  throw new Error(`Failed to build macOS native capture runtime:\n${result.stderr || result.stdout}`);
}

rmSync(distDir, { recursive: true, force: true });
mkdirSync(distDir, { recursive: true });
cpSync(output, join(distDir, "OfferSteadyCaptureRuntime"));

console.log(`Built ${targetArch} native capture runtime for macOS ${minimumSystemVersion}: ${output}`);
