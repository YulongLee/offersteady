面试稳 · 官网宣传片交付包

36秒，1920×1080。

先打开 web/index.html 可预览静音网页版。
offersteady-commercial.mp4：60fps高清配乐成片。
offersteady-commercial-nobgm.mp4：60fps，仅保留音效。
web/offersteady-web.mp4：1080p / 30fps，约3.25MB，推荐官网使用。
web/offersteady-web-720.mp4：720p / 30fps，约1.36MB。
web/poster.jpg：封面。

将web目录视频和封面上传到自己网站后，使用：
<video controls muted playsinline preload="metadata" poster="/videos/offersteady/poster.jpg" width="1920" height="1080" style="display:block;width:100%;height:auto;border-radius:20px;background:#080c13">
  <source src="/videos/offersteady/offersteady-web.mp4" type="video/mp4">
</video>

需要首屏自动循环可增加autoplay loop；保留muted playsinline。详情文字建议全屏阅读。此交付未修改或发布产品网站。

画面来自面试稳真实前端和合成示例；参考竞品素材未进入本片。
来源说明见 audio-ATTRIBUTION.md。
